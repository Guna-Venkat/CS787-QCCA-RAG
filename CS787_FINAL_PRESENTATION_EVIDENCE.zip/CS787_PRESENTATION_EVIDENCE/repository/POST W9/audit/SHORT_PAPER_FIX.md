# POST-W9 short-paper retrieval fix — 4 November 2026

The crash was caused by a real source constraint: paper `1607.01759` yields **8** nodes under the original `SentenceSplitter(chunk_size=256)` and default overlap. The experiment assumes exactly 10 genuine source chunks (4 full + 6 latent, six promotion candidates). Padding, shrinking n, changing the splitter, or manufacturing passages would change that experiment.

## Handling and cohort accounting

A CPU-only eligibility audit now reads paper source columns only, excluding question/answer columns. It records every paper's canonical chunk count, source hash, query membership and any technical exclusion. The original split manifest remains byte-identical; no membership is resampled. The same eligibility applies across every baseline, learned system and oracle. Empty sources remain fatal rather than being quietly excluded.

| Role | Original queries | Eligible queries | Technical exclusions | Excluded papers |
|---|---:|---:|---:|---:|
| TRAIN_FIT | 2,067 | 2,054 | 13 | 7 |
| TRAIN_DEV | 526 | 521 | 5 | 3 |

Scores will describe the **technically eligible subset**, not the complete original cohort. Eligibility is consumed consistently by answer generation, controller training, analysis completeness checks, freeze and reporting. Individual exclusions and denominators are persisted under `manifests/eligibility/`. The source-only rule is fixed before FINAL_TEST execution. FINAL_TEST source text, questions, labels, predictions and outcomes were not inspected in this fix.

## Resume without discarding previous work

The source-code patch changes the strict protocol identity, so bypassing existing identity checks or rewriting old identities would be unsafe. Instead:

- Original `results/retrieval/` is preserved.
- Current caches live under `results/retrieval_short_paper_v2/`.
- `manifests/retrieval_cache_compatibility_short_paper_v2.json` binds the exact reviewed old/new code identities and unchanged models, configuration, checkpoints, package versions and latent-weight metadata.
- Legacy shards are reused only after checking identity, envelope checksum, exact ten distinct passages, source text hashes, rank order, vector/source alignment, vector shape and file hash.
- Each imported row has a separate reuse receipt. Immutable latent files are hard-linked instead of duplicated.
- **91 SFR + 91 BM25 completed query retrievals were certified and reused**, without loading model weights.
- All **367 pre-existing POST-W9 artifact files** were verified byte-identical after the fix, including original splits and retrievals.

`torch_dtype` was also replaced with `dtype` in this SFR loader, preserving BF16 precision. The warning itself was not the fatal error. New metadata preflight receipts use `audit/inputs_short_paper_v2.json`, leaving the existing preflight receipt intact.

## Validation

- `sara_env/bin/python -m pytest 'POST W9/tests' -q -k 'not notebook_defaults_safe'`: **46 passed, 1 deselected**.
- New tests cover 9-vs-10-chunk eligibility, immutable original membership, locked final content, receipt tampering, exact cache reuse, original-file preservation, and rejection of changed model/code identity or vectors.
- The deselected existing test asserts that the saved notebook contains default `RUN_TRAIN = False`. The user's working notebook currently has `RUN_TRAIN = True` and `RUN_SMOKE = False`; those intentional run settings were preserved. An unfiltered test invocation therefore reports that one default-setting assertion failure. Runtime final-label and explicit-full-run guards remain tested.
- Ran the CPU-only TRAIN source eligibility audit and cache-integrity import. No full retrieval, pretrained-model generation, controller training or FINAL_TEST execution was launched.

## Resume instructions

Rerun the existing notebook cell containing `stage('prepare', '--full')`. It will reuse the certified rows and continue with missing eligible queries. The same cell will then proceed to baselines and surface generation as already configured.

Alternatively, from the project root:

```bash
sara_env/bin/python 'POST W9/scripts/run.py' prepare --full
```

Keep `RESUME=True`, `OVERWRITE=False`. FINAL_TEST remains disabled. Re-running the metadata audit now uses its versioned preflight receipt rather than replacing the old one.
