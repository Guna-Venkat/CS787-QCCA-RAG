# POST-W9 implementation and readiness

Implemented on `gagan`, entirely under `POST W9/`. This document reports implementation and smoke verification, **not scientific experiment outcomes**. No full pretrained inference, gate/U2 training or FINAL_TEST evaluation has been launched.

## Delivered

- `configs/dafir_sfr_v1.yaml`: preregistered model revisions, specialist generation, action/system registry, historical U2-A/gain-weighted gate, thresholds, success criteria and statistics.
- `src/dafir_post/`: protocol/storage, official-source data adapter, retrieval/latent alignment, fresh generation, response surface, measured features, controller training, freeze, online routing, evaluation/bootstrap, reporting and CLI.
- `scripts/run.py`: safe explicit stage launcher.
- `notebooks/POST_W9_DAFIR_SFR.ipynb`: one Run All notebook, separate default-off TRAIN and FINAL_TEST switches; resume stays on.
- `manifests/splits.json`: new experiment membership only; historical splits are not regenerated or altered.
- `audit/inputs.json`: local checkpoint/package/source identities and baseline recovery audit.
- `audit/historical_regeneration_check.json`: W9-F primary CSV/config/prompt hashes, actual F0/F1/F2-A/F2-B F1 and EM, and raw-generation availability limitation.
- `figures/architecture.svg`: draft-to-router path explicitly separated from fresh regeneration.
- `tests/`: 41 passing tests, including actual tiny random CPU XMistral continuation generation, not a pretrained QASPER run.
- `README.md`: exact run instructions, output paths, cost scope and limitations.

The actual scientific results report, result CSVs and outcome figures are produced automatically after complete frozen FINAL_TEST. They do not contain invented pending scores.

## Data verification

| Role | Queries | Papers | Original official source |
|---|---:|---:|---|
| TRAIN_FIT | 2,067 | 710 | QASPER TRAIN |
| TRAIN_DEV | 526 | 178 | QASPER TRAIN |
| FINAL_TEST | 1,005 | 281 | QASPER validation |

New split SHA256: `af1017991e59b02160be07a1b52c10408f27407757e2fda8bd847f77279afbeb`.

The older `QASPER_dev.jsonl` contains 231 questions from an internal TRAIN split and was therefore not used as official validation. Native original query IDs and all official TRAIN questions are retained. The operational FINAL_TEST is historically project-exposed validation, not fresh project-wide confirmation. Only metadata/counts were inspected for it during implementation; no FINAL_TEST question, gold answer, prediction or metric was accessed for this new study.

## Models

| Component | ID | Revision |
|---|---|---|
| Retrieval and SARA latents | Salesforce/SFR-Embedding-Mistral | `33a60fe7b5e00b9414981280c571e8a4f9f42f1b` |
| Specialist adapted reader base | mistralai/Mistral-7B-Instruct-v0.2 | `63a8b081895390a26e140280378bc85ec8bce07a` |
| Historical U2-A backbone | cross-encoder/ms-marco-MiniLM-L-6-v2 | `233902d25c440f23af6f7d6e94d2946bac0bee0a` |
| Historical draft-query semantic feature | sentence-transformers/all-MiniLM-L6-v2 | `1110a243fdf4706b3f48f1d95db1a4f5529b4d41` |

All required local weight files are available. SARA LoRA/projector/tokenizer: `Baselines/SARA-main/checkpoints/finetune/sara_qasper_proj_lr5e4_seed42`; full hashes are in the audit. The loader's cached Mistral base ref matches the pinned revision. MiniLM is restricted to historical controller/feature components; DAFiR's retrieval and compressed representations are SFR only.

## Narrow methodological choices

1. The historical globally selected W8 model was U4-A. It is not substituted for U2. The implemented historical U2-A class, top-two-layer adaptation and three-epoch settings are reused; only TRAIN_DEV chooses epoch. The same multitask/ranking loss remains, with candidate inference argmax on predicted delta F1 as required here.
2. All new systems use canonical specialist greedy64/BF16 settings, matching the later paired specialist implementation. Earlier cap128 outputs are not mixed into the new response surface.
3. BM25 uses the same canonical splitter/default overlap and English-stemmed retriever defaults. Its old helper's unrelated disk persistence is omitted so no new file is written outside POST W9. Fewer than ten genuine chunks is a loud error, not a silent pad/substitution.
4. Historical W9-F comparisons exist in primary aggregate CSVs. Their deleted raw generations cannot be rechecked, so the report treats them as contextual evidence, not proof of fresh-regeneration superiority or matched SFR promotion parity.
5. Existing W12 specialist exports are not reused as exact new baseline scores without complete per-query source/latent/prompt/decoding compatibility. No historical official-validation outcomes were inspected during development. New matched baseline execution is implemented for canonical BM25 k5 and SFR k4/k5/k6.
6. Exact K5/P5 identity permits answer reuse, while conceptual generation cost is retained. No other policy is silently substituted.

## Safeguards and resumption

- Row checksums plus immutable input/config/code/checkpoint/split identities.
- Ranked passage IDs/text hashes bind every FULL/latent row and promotion.
- Fresh generation API has no draft argument. No revision instruction, draft answer or editing prompt is passed to regeneration.
- Actual continuation tokens align one-for-one to full-vocabulary scores; no prompt-length slicing or approximate selected-token log probability.
- Inference whitelists exclude golds, F1, evidence labels and counterfactual outcomes.
- Learned routing decisions persist before retrospective oracle evaluation.
- The final freeze includes controller file hashes, threshold, memberships, package versions and model/source identities.
- Explicit full execution, final access and exact freeze acknowledgement are all required for FINAL_TEST.
- Starting FINAL_TEST permanently closes development stages; resuming requires the same freeze.
- Query/action answer files resume individually. U2 training resumes at completed epochs; an interrupted epoch repeats deterministically.
- Analysis rejects missing or extra action/query identities and requires all six policy rows per final query.

## Verification completed

- **41 tests passed** (`audit/tests.log`).
- Default notebook executed end-to-end successfully (`audit/notebook_defaults.log`). It performed metadata audit and synthetic/tiny random CPU tests, printed FINAL_TEST locked, and left all answer/decision/feature counts at zero.
- Complete analysis, paired bootstrap, figures, report generation and identical rerun were tested on synthetic fixtures in temporary directories only.
- Metadata preflight passed; about **37.46 GiB** disk was free when recorded. No cache or historical result was deleted; no model downloaded.
- No development/final scientific result is claimed yet. Baseline F1/EM, adaptive F1, mean k, escalation, CIs, headroom and success classification remain pending real execution.

## Remaining practical limits

TRAIN_DEV is controller-held-out; the reused historical SARA specialist was previously adapted on official TRAIN and may already have seen those papers. This does not make FINAL_TEST a training cohort, and no fresh project-wide holdout claim is made.

No full pretrained GPU qualification was performed in this implementation pass. Large-model runtime, rare short-paper chunk-count failures and actual controller quality remain to be established when TRAIN is manually launched. Such failures stop loudly; they do not change the frozen architecture or replace examples. All four static baselines plus response surfaces across the three cohorts can require up to 32,382 distinct answer generations before further exact reuse. Lower final k does not establish lower compute: promoted queries pay two generations.

## Next action

Open `notebooks/POST_W9_DAFIR_SFR.ipynb`. Default Run All is safe and has passed. To begin the expensive TRAIN phase, change only `RUN_TRAIN=True` and keep `RUN_FINAL_TEST=False`. Review TRAIN_DEV before the separate final freeze acknowledgement. Exact settings and CLI stages are in README.

HISTORICAL QASPER TEST WAS NOT ACCESSED.

FINAL ESCALATION IS IMPLEMENTED AS FRESH REGENERATION; THE DRAFT IS USED FOR ROUTING ONLY.

CANONICAL SARA BM25 K5 IS INCLUDED IN THE EXECUTABLE BASELINE REGISTRY; ITS NEW RESULTS ARE PENDING.

NO FINAL_TEST EVALUATION OR POST-FINAL_TEST METHOD CHANGE HAS OCCURRED.
