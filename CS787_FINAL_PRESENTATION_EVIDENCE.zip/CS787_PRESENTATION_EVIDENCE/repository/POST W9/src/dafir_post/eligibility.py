"""Outcome-blind n=10 feasibility; original split memberships are never rewritten."""
from .protocol import HOME,immutable,read,digest,sha,ROLES
from .data import verify_split,papers,paper_context

POLICY=dict(version='canonical-ten-chunks-v1',minimum_chunks=10,
            splitter='llama_index SentenceSplitter(chunk_size=256), default overlap',
            exclusion='fewer_than_10_canonical_chunks',
            scope='Identical technical eligibility across all systems; no padding, resampling or outcome filtering')

def path(role):return HOME/'manifests/eligibility'/(role+'.json')

def prepare(c,role,allow_final=False):
    if role not in ROLES:raise ValueError('Unknown role')
    if role=='final_test' and not allow_final:raise ValueError('FINAL_TEST content locked')
    from llama_index.core import Document
    from llama_index.core.node_parser import SentenceSplitter
    m=verify_split(c);members=m[role];wanted={r['paper_id'] for r in members}
    immutable(HOME/'manifests/eligibility/policy.json',POLICY)
    if path(role).exists():return receipt(c,role)
    splitter=SentenceSplitter(chunk_size=256);rows=[]
    # Exclude question/answer columns entirely: decisions use source text only.
    for p in papers(c,role).select_columns(['id','title','abstract','full_text']):
        pid=str(p['id'])
        if pid not in wanted:continue
        context=paper_context(p)
        nodes=splitter.get_nodes_from_documents([Document(text=t) for t in context if t.strip()])
        n=len(nodes)
        if not n:raise ValueError('Empty source paper: '+pid)
        rows.append(dict(paper_id=pid,canonical_chunks=n,source_hash=digest(context),
                         eligible=n>=10,reason=None if n>=10 else POLICY['exclusion'],
                         query_ids=sorted(r['query_id'] for r in members if r['paper_id']==pid)))
    if {r['paper_id'] for r in rows}!=wanted:raise ValueError('Incomplete source-text eligibility audit')
    body=dict(policy=POLICY,split_hash=m['split_hash'],role=role,papers=sorted(rows,key=lambda r:r['paper_id']))
    immutable(path(role),dict(body=body,receipt_hash=digest(body)))
    return receipt(c,role)

def receipt(c,role):
    if role not in ROLES:raise ValueError('Unknown role')
    if not path(role).exists():raise ValueError('Run prepare first: eligibility is not complete for '+role)
    r=read(path(role));b=r['body'];m=verify_split(c)
    if r['receipt_hash']!=digest(b) or b['policy']!=POLICY or b['split_hash']!=m['split_hash'] or b['role']!=role:
        raise ValueError('Eligibility identity changed')
    observed=[dict(query_id=q,paper_id=p['paper_id']) for p in b['papers'] for q in p['query_ids']]
    if sorted(observed,key=lambda x:x['query_id'])!=sorted(m[role],key=lambda x:x['query_id']):
        raise ValueError('Eligibility cohort mismatch')
    if len({p['paper_id'] for p in b['papers']})!=len(b['papers']):raise ValueError('Duplicate eligibility papers')
    for p in b['papers']:
        if p['canonical_chunks']<1 or p['eligible']!=(p['canonical_chunks']>=10) or p['reason']!=(None if p['eligible'] else POLICY['exclusion']):
            raise ValueError('Eligibility reason/count mismatch')
    return r

def eligible_membership(c,role):
    b=receipt(c,role)['body'];ok={p['paper_id'] for p in b['papers'] if p['eligible']}
    return [r for r in verify_split(c)[role] if r['paper_id'] in ok]

def summary(c,role):
    r=receipt(c,role);ps=r['body']['papers'];excluded=[p for p in ps if not p['eligible']]
    total=sum(len(p['query_ids']) for p in ps);removed=sum(len(p['query_ids']) for p in excluded)
    return dict(original_queries=total,eligible_queries=total-removed,excluded_queries=removed,
                excluded_papers=len(excluded),exclusions=excluded,receipt_sha256=sha(path(role)))
