"""Same canonical chunker/BM25 defaults; SFR replaces retrieval only."""
import gc,os,time
import numpy as np
from .protocol import HOME,Store,digest,sha,identity,snapshot,immutable,seed
from .data import examples
PREFIX='Instruct: Given a web search query, retrieve relevant passages that answer the query\nQuery: '

def validate_pool(row):
    ps=row['passages']
    if len(ps)!=10 or len({p['passage_id'] for p in ps})!=10: raise ValueError('Ten genuine distinct source chunks required; no padding')
    if [p['rank'] for p in ps]!=list(range(1,11)):raise ValueError('Rank/identity mismatch')
    for p in ps:
        if not p['text'].strip() or p['text_hash']!=digest(p['text']): raise ValueError('Passage content changed')
    if row['retriever']=='SFR' and any(ps[i]['score']<ps[i+1]['score'] for i in range(9)): raise ValueError('SFR scores not descending')

def store(c,role,retriever):
    from .data import verify_split
    from .retrieval_resume import RetrievalStore
    return RetrievalStore(HOME/'results/retrieval_short_paper_v2'/role/retriever,dict(protocol=identity(c),split_hash=verify_split(c)['split_hash'],role=role,retriever=retriever,splitter='llama_index SentenceSplitter(chunk_size=256), default overlap',prefix=PREFIX,latent_normalized=False),HOME/'results/retrieval'/role/retriever)

def prepare(c,role,allow_final=False):
    import torch
    from llama_index.core import Document
    from llama_index.core.node_parser import SentenceSplitter
    from llama_index.retrievers.bm25 import BM25Retriever
    from sentence_transformers import SentenceTransformer
    import Stemmer
    from .protocol import ROOT
    from .eligibility import prepare as prepare_eligibility,summary
    seed();os.environ['HF_HUB_OFFLINE']='1';os.environ['TRANSFORMERS_OFFLINE']='1'
    if c['query_prefix']!=PREFIX: raise ValueError('SFR query instruction changed')
    prepare_eligibility(c,role,allow_final)
    counts=summary(c,role)
    print(f"{role}: {counts['eligible_queries']}/{counts['original_queries']} eligible; {counts['excluded_queries']} queries in {counts['excluded_papers']} short papers logged (no padding)",flush=True)
    xs=examples(c,role,allow_final);stores={r:store(c,role,r) for r in ('SFR','BM25')}
    pending=[e for e in xs if any(stores[r].get(e['query_id']) is None for r in stores)]
    if not pending: print(role+': retrieval already complete',flush=True);return
    encoder=None;current=None;started=time.time()
    try:
        for n,e in enumerate(sorted(pending,key=lambda x:(x['paper_id'],x['query_id'])),1):
            if encoder is None: encoder=SentenceTransformer(str(snapshot(c['models']['SFR'])),device='cuda',local_files_only=True,model_kwargs={'dtype':torch.bfloat16})
            if e['paper_id']!=current:
                current=e['paper_id'];nodes=SentenceSplitter(chunk_size=256).get_nodes_from_documents([Document(text=t) for t in e['context'] if t.strip()])
                texts=[node.text for node in nodes]
                if len(texts)<10:raise ValueError(f'{current}: fewer than 10 canonical chunks; no silent substitute')
                raw=encoder.encode(texts,batch_size=8,convert_to_tensor=True,normalize_embeddings=False,show_progress_bar=False).detach().cpu().float()
                if raw.shape!=(len(texts),4096) or not torch.isfinite(raw).all(): raise ValueError('Invalid SFR latent shape')
                bm=BM25Retriever.from_defaults(nodes=nodes,similarity_top_k=10,stemmer=Stemmer.Stemmer('english'),language='english')
                node_index={node.node_id:i for i,node in enumerate(nodes)}
            q=encoder.encode([PREFIX+e['question']],convert_to_tensor=True,normalize_embeddings=False,show_progress_bar=False).detach().cpu().float()[0]
            scores=(torch.nn.functional.normalize(raw,dim=1)@torch.nn.functional.normalize(q,dim=0)).tolist()
            sf=sorted(range(len(texts)),key=lambda i:(-scores[i],i))[:10]
            bn=bm.retrieve(e['question']);bo=[node_index[v.node_id] for v in bn[:10]]
            for r,order,values in [('SFR',sf,[scores[i] for i in sf]),('BM25',bo,[float(v.score) for v in bn[:10]])]:
                st=stores[r]
                if st.get(e['query_id']) is not None:continue
                ps=[dict(passage_id=current+':'+digest([i,texts[i]]),source_index=i,rank=j+1,score=float(values[j]),text=texts[i],text_hash=digest(texts[i])) for j,i in enumerate(order)]
                vector_path=st.path/(digest(e['query_id'])+'.npy')
                arr=raw[order].numpy().astype(np.float16)
                # np.float16 represents the BF16 encoder values exactly. File hash binds rank order.
                if not np.isfinite(arr).all() or not np.array_equal(arr.astype(np.float32),raw[order].numpy()):raise ValueError('Lossy/nonfinite latent serialization')
                if not vector_path.exists():
                    tmp=vector_path.with_suffix('.npy.pending')
                    with tmp.open('wb') as f:np.save(f,arr);f.flush();os.fsync(f.fileno())
                    os.replace(tmp,vector_path)
                else:
                    if not np.array_equal(np.load(vector_path,allow_pickle=False),arr):raise ValueError('Incompatible orphan vector file')
                row=dict(query_id=e['query_id'],paper_id=current,question=e['question'],retriever=r,passages=ps,source_hash=digest(e['context']),vector_file=vector_path.name,vector_hash=sha(vector_path),vector_passage_ids=[p['passage_id'] for p in ps])
                validate_pool(row);st.put(e['query_id'],row)
            print(f'{role} retrieval {n}/{len(pending)} pending; elapsed={time.time()-started:.0f}s',flush=True)
    finally:
        del encoder;gc.collect();torch.cuda.empty_cache()

def load(c,role,retriever,qid):
    st=store(c,role,retriever);row=st.get(qid)
    if row is None:raise FileNotFoundError('Prepare retrieval first: '+qid)
    validate_pool(row);path=st.path/row['vector_file']
    if sha(path)!=row['vector_hash'] or row['vector_passage_ids']!=[p['passage_id'] for p in row['passages']]:raise ValueError('Latent/source identity mismatch')
    arr=np.load(path,allow_pickle=False)
    if arr.shape!=(10,4096) or not np.isfinite(arr).all(): raise ValueError('Latent shape mismatch')
    return row,arr
