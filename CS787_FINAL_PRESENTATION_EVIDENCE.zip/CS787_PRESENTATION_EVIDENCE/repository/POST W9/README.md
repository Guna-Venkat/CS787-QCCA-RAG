# POST-W9 — DAFiR-SFR

A final, separate SARA/QASPER experiment: does correcting retrieval with SFR make **draft-aware, single-promotion fidelity routing** useful? Retrieval is an upstream confound, not the only possible limitation.

Everything new is contained here. Existing science, QBGF, demo, frozen cohorts and historical outputs are unchanged. Use branch `gagan`.

## What is frozen

- SFR top-10 using the project's pinned `Salesforce/SFR-Embedding-Mistral` revision, canonical SARA 256-token chunking/default splitter overlap.
- Adapted Mistral SARA LoRA/projector/tokenizer checkpoint `Baselines/SARA-main/checkpoints/finetune/sara_qasper_proj_lr5e4_seed42`; BF16, SDPA, greedy 64 new tokens, matching the later paired SARA specialist baseline. No Qwen, no LoRA fine-tuning of the reader.
- Start at **4 FULL + 6 latent**, generate draft, gain-aware logistic STOP/ESCALATE gate, historical **U2-A** draft-conditioned cross-encoder over ranks 5–10, promote at most one source, then **fresh canonical QA** from 5 FULL + 5 latent. The generation API accepts no draft parameter.
- One historical U2 architecture, three epochs, original multitask/ranking loss. TRAIN_DEV chooses epoch by forced-promotion F1. Candidate choice uses the delta-F1 regression head; ties choose lower SFR rank. No U3/U4 or architecture search.
- Gate: measured historical U1–U12, StandardScaler + logistic C=1, max_iter=2000, weight `1 + 5*max(best_delta,0)`. The original gain-weight formula is retained. No guessed log probabilities or zero-filled missing diagnostics.
- Gate threshold is selected on TRAIN_DEV routed F1; ties prefer fewer escalations, then larger threshold. Candidate and gate labels never enter their inference payloads.
- HELP > .01, HURT < −.01; noninferiority margin .01; paper-cluster paired bootstrap 10,000, seed42.

## Data roles — read this first

The historical `QASPER_dev.jsonl` is **not official validation**; it is an internal TRAIN subset. This experiment uses the native pinned Arrow sources instead:

| Role | Source | Queries | Papers | Use |
|---|---|---:|---:|---|
| `train_fit` | official QASPER TRAIN | 2,067 | 710 | response surface, gate/U2 fitting |
| `train_dev` | official QASPER TRAIN | 526 | 178 | threshold/epoch choice, debugging |
| `final_test` | official QASPER validation | 1,005 | 281 | final frozen evaluation |

TRAIN contains 2,593 queries / 888 papers. Sorted paper IDs are shuffled with Python `Random(42)`; the first `floor(.8 * papers)` are TRAIN_FIT. Manifest records every original query ID, paper ID, source SHA and split SHA. No historical split is modified. No paper or query overlap is allowed.

TRAIN_DEV is a holdout for the **new gate and U2 controller**, not a claim that the reused SARA reader has never seen those TRAIN papers during its historical adaptation. The specialist reader remains fixed across all systems.

**FINAL_TEST is historically project-exposed official validation**, held out from this new controller training. It is not an untouched project-wide test or fresh confirmation cohort. Historical QASPER TEST is permanently closed and no path to it is opened. Metadata preflight reads only IDs/counts; final questions, labels and outcomes remain locked until explicit final execution.

## How to run — one notebook

Open [`notebooks/POST_W9_DAFIR_SFR.ipynb`](notebooks/POST_W9_DAFIR_SFR.ipynb) with `sara_env`.

| Step | First-cell settings | Action |
|---|---|---|
| Check plumbing | defaults: `RUN_PREFLIGHT=True`, `RUN_SMOKE=True`, `RUN_TRAIN=False`, `RUN_FINAL_TEST=False` | Run All: metadata audit + synthetic/tiny random CPU smoke only |
| Develop controller | `RUN_TRAIN=True`, `RUN_FINAL_TEST=False` | Run All: prepare both TRAIN roles, static baselines, response surfaces, gate/U2, TRAIN_DEV analysis, freeze |
| Final experiment | `RUN_TRAIN=False`, `RUN_FINAL_TEST=True`, `ALLOW_FINAL_TEST=True`; copy `freeze_hash` into `ACK_FREEZE_SHA256` | Run All: exact frozen final systems, learned decisions, oracle, report |

Keep `RESUME=True`, `OVERWRITE=False`. No parameter changes after FINAL_TEST starts. Re-running resumes the existing exact freeze; it is not a second evaluation. Set RUN_TRAIN=False before final execution. All real model work is disabled by default.

CLI alternative, from repository root:

```bash
sara_env/bin/python 'POST W9/scripts/run.py' audit
sara_env/bin/python 'POST W9/scripts/run.py' split
sara_env/bin/python 'POST W9/scripts/run.py' smoke
sara_env/bin/python 'POST W9/scripts/run.py' status
```

Development stages, deliberately manual (each resumes):

```bash
sara_env/bin/python 'POST W9/scripts/run.py' prepare --full
sara_env/bin/python 'POST W9/scripts/run.py' baselines --full
sara_env/bin/python 'POST W9/scripts/run.py' surface --full
sara_env/bin/python 'POST W9/scripts/run.py' train-gate --full
sara_env/bin/python 'POST W9/scripts/run.py' train-selector --full
sara_env/bin/python 'POST W9/scripts/run.py' calibrate --full
sara_env/bin/python 'POST W9/scripts/run.py' internal --full
sara_env/bin/python 'POST W9/scripts/run.py' freeze
```

The final stage additionally requires `--full --allow-final-test --ack-freeze YOUR_EXACT_FREEZE_HASH`. Do not start it until development and review are complete.

## Systems and exact reuse

The primary FINAL_TEST table contains exactly:

1. `SARA_CANONICAL_BM25_K5_N10`
2. `SARA_SFR_K4_N10`
3. `SARA_SFR_K5_N10`
4. `SARA_SFR_K6_N10`
5. `DAFIR_SFR_K4_TO_K5_REGEN`
6. `ORACLE_SELECTIVE1_SFR` — retrospective, not deployable.

Canonical means **BM25 k5/n10**, not SFR. The same chunker, adapted reader, tokenizer, canonical QA template and decoding are used. Source-order presentation follows ascending retrieved rank, with compressed rows aligned to that same pool. The short-paper fix keeps exactly ten genuine chunks: before loading SFR, a text-only eligibility audit records papers with fewer than ten canonical chunks as technical exclusions, applied identically to every method. No padding, new chunker, resampling or outcome filtering is used. Original split IDs remain unchanged; reports show original/eligible/excluded denominators and scores describe the eligible subset. Empty papers still fail loudly.

After the short-paper error, rerun the same notebook prepare cell (or `sara_env/bin/python 'POST W9/scripts/run.py' prepare --full`). It resumes certified completed retrievals. An optional CPU-only precheck is `sara_env/bin/python 'POST W9/scripts/run.py' eligibility`; this reads TRAIN source text only, not FINAL_TEST content or answers. Eligibility receipts live under `manifests/eligibility/`. They are mandatory before generation/training and are bound into the final freeze.

Patched retrievals use `results/retrieval_short_paper_v2/{role}/{SFR,BM25}`. The original `results/retrieval/` remains untouched. Reviewed exact cache reuse is bound to `manifests/retrieval_cache_compatibility_short_paper_v2.json`; legacy shard identities, content hashes, rank order and latent file hashes are checked before reuse. Reused vector files are hard-linked, avoiding a second copy. Missing or incompatible compatibility metadata fails closed. The old `audit/inputs.json` is preserved; new preflight uses `audit/inputs_short_paper_v2.json`.

Existing baseline exports are audited but not reused as exact POST-W9 results because they lack enough per-query prompt/decoding/source/latent identity to certify the complete new protocol. Scores on official validation are not consulted during development. All required baselines have executable matched implementations.

Static SFR k5 and promotion P5 have exactly identical prompts and compressed rows. Their answer can be reused after source/allocation checks; conceptual one-pass costs remain counted. Other completed query/action shards are reused only with matching code/config/checkpoint/split/source hashes. Incompatible outputs fail, never overwrite. No existing result is deleted.

## Runtime, space and resumption

SFR preparation and SARA generation run as separate notebook subprocesses. Each keeps at most one large model on GPU. U2 inference and MiniLM draft features use CPU alongside SARA. Pinning is local-only/offline; no model download or cache deletion is performed.

The full maximum tested surface is nine distinct physical generations per query after k5/P5 reuse (four static baselines plus six promotion actions with shared base/P5). With all three roles this is at most **32,382 distinct generations** before other existing exact reuse. This is an expensive experiment, not a one-minute controller-only notebook. Actual wall time is hardware-dependent; use printed durable query progress to estimate after starting. No full run was launched during implementation.

Vector caches store source-bound 10×4096 embeddings per query/retriever in FP16 storage only if they exactly preserve the BF16 SFR values; source/raw text and hashes remain attached. Completed query/action results survive interruption. U2 optimizer state is checkpointed each epoch; an interrupted epoch repeats deterministically from its start. There is no claim of step-level training resume.

Preflight records available disk space. Leave space for raw response shards, embeddings and three U2 optimizer checkpoints. No end-to-end latency/compute savings are assumed from lower final k: escalation pays a second answer generation.

## Output map

- `audit/inputs.json`: pinned model/data/canonical/gate/U2 audit.
- `audit/historical_regeneration_check.json`: actual W9-F CSV values/config/hashes, with raw-generation availability limitations; contextual only.
- `manifests/splits.json`: new immutable source-role membership and hash.
- `manifests/dafir_sfr_v1_freeze.json`: created only after all TRAIN development is complete.
- `manifests/final_test_started.json`: permanently closes development stages.
- `results/retrieval/{role}/{SFR,BM25}`: ranked source metadata plus exact latent files.
- `results/answers/{role}`: immutable per-query/action raw answers, measured diagnostics, costs and source identities.
- `results/controller`: TRAIN-only checkpoints, training history and threshold calibration.
- `results/decisions/{role}`: predicted decisions saved before retrospective surface analysis.
- `results/analysis/{role}`: per-query policies, complete response surface, router errors, summaries, distributions, paired CIs and checksums.
- `TRAIN_DEV_DAFIR_RESULTS.md`: generated after complete TRAIN_DEV analysis.
- `POST_W9_DAFIR_RESULTS.md`: generated only after complete frozen FINAL_TEST. No placeholder scores.
- `figures/`: architecture now; quality/fidelity, retriever, headroom and action plots only from completed real results.

The report labels the raw data source and includes source paths for numerical tables. Nominal paired intervals accompany point estimates. Success classifications are preregistered in the YAML; a partial result means positive point improvement over k4 without meeting every strong-result condition. All uncertainty remains visible.
