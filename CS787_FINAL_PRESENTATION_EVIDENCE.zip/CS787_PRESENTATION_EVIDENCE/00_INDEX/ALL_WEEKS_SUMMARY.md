# All weeks — summary and experiment register

Use this as the chronological lookup volume. The full details/tables are in [ALL_WEEKS_COMPLETE_RESULTS.md](ALL_WEEKS_COMPLETE_RESULTS.md); [ALL_EXPERIMENTS_REGISTER.csv](ALL_EXPERIMENTS_REGISTER.csv) contains the 95 registered historical part records with original execution status. A registered part can be a smoke test, a negative result, an audit or incomplete work; the count is not a count of successful independent full experiments.


---

## Week 0

Source: [results/weekly_reports/week_00/WeeklySummaryAnalysis.md](../repository/results/weekly_reports/week_00/WeeklySummaryAnalysis.md)

# Week 0 — Summary Analysis

## Objective

The week probes dataset/evidence characteristics and retrieval-to-reader sensitivity before learning a context allocator. Source code defines dataset analysis, layer analysis and utilization analysis; separately named GPU studies and a later Week3 bridge coexist. The generic layer/utilization tables are deterministic mock outputs and are excluded from empirical model conclusions. The notebook has no executed code outputs; it supplies no Tier-2 outcome evidence.

## Experiments performed

| part                    | question                                                                                                                         | status                  | main_result                                                                                                                                                                                                   |
|:------------------------|:---------------------------------------------------------------------------------------------------------------------------------|:------------------------|:--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| A                       | How much annotated evidence is present in the local QASPER splits, and how often does the existing retrieved pool recover it?    | COMPLETED               | The local dev pool has any-gold recall 0.870130 and all-gold recall 0.800866 at 10; additional context can recover evidence that shallower retrieval misses.                                                  |
| B                       | Do query/passage representations evolve across layers?                                                                           | HISTORICAL / SUPERSEDED | The legacy export exists, but it is deterministic simulation output, not evidence about real model representations.                                                                                           |
| C                       | Does retrieval relevance agree with attention or passage-removal utility?                                                        | HISTORICAL / SUPERSEDED | The deterministic simulation is reproducible. Its 0.9928 ablation/gold Pearson correlation is an artifact of the construction.                                                                                |
| GPU-PILOT               | Do real forward passes exhibit the same attention/ablation behavior as the generic simulated exports?                            | COMPLETED               | 96/100 removal deltas are negative, with mean −0.823364. This differs fundamentally from the generic nonnegative mock ablation export.                                                                        |
| INTERVENTION-VALIDATION | Could removing a passage change prompt structure/length rather than isolate its information content?                             | COMPLETED               | Both pilot interventions mostly have negative deltas; replacement is approximately, not perfectly, length matched.                                                                                            |
| FINAL40                 | Do annotated-evidence categories differ in real replacement sensitivity across a broader, deliberately heterogeneous dev sample? | COMPLETED               | STRONG-match passages have mean replacement delta 0.618710 versus about 0.02 for WEAK/NONE. Overall replacement mean is +0.098325, but 146/400 deltas are negative and 19 are zero. Utility is heterogeneous. |
| RETROSPECTIVE-BRIDGE    | Does the final40 sensitivity profile relate retrospectively to best-tested context budgets?                                      | COMPLETED               | A 40-row retrospective join exists and matches its Week3 sources; mean selected oracle F1 is 0.547600 on this subset.                                                                                         |

Source: per-part primary paths in the source list below.

## Key results

|         k |   any_gold_recall |   all_gold_recall |    queries |
|----------:|------------------:|------------------:|-----------:|
|  2.000000 |          0.515152 |          0.372294 | 231.000000 |
|  4.000000 |          0.701299 |          0.558442 | 231.000000 |
|  6.000000 |          0.809524 |          0.705628 | 231.000000 |
| 10.000000 |          0.870130 |          0.800866 | 231.000000 |

Source: [results/week0/dataset_analysis/retrieval_statistics.csv](../repository/results/week0/dataset_analysis/retrieval_statistics.csv).

| study               |   rows |   queries |   mean_delta |   median_delta |   positive |   negative |   zero |
|:--------------------|-------:|----------:|-------------:|---------------:|-----------:|-----------:|-------:|
| pilot removal       |    100 |        10 |    -0.823364 |      -0.386718 |          4 |         96 |      0 |
| pilot replacement   |    100 |        10 |    -0.820215 |      -0.375000 |          6 |         94 |      0 |
| final40 removal     |    400 |        40 |     0.089741 |       0.003906 |        217 |        170 |     13 |
| final40 replacement |    400 |        40 |     0.098325 |       0.007812 |        235 |        146 |     19 |

Sources: pilot/removal/replacement and final40 intervention CSVs.

| match_category   |   n |   mean_replacement_delta |   median_replacement_delta |   positive_fraction |
|:-----------------|----:|-------------------------:|---------------------------:|--------------------:|
| NONE             | 108 |                 0.018283 |                   0.007812 |            0.629630 |
| PARTIAL          |  47 |                 0.031660 |                   0.007812 |            0.617021 |
| STRONG           |  51 |                 0.618710 |                   0.125000 |            0.784314 |
| WEAK             | 194 |                 0.022233 |                   0.000977 |            0.505155 |

Source: [results/week0/final40/replacement_results.csv](../repository/results/week0/final40/replacement_results.csv).

## Main scientific conclusions

The local split inventory and retrieval recall are reproducible. Real sensitivity studies show substantial heterogeneity, not uniform evidence use. Final40 strong-match passages have higher teacher-forced replacement impact, but that is not generated answer F1 or a latent-versus-text result. Generic layer/utilization tables are not empirical: every tested value matches seeded mock formulas.

Sources: [results/weekly_reports/week_00/PrimaryRecomputationChecks.json](../repository/results/weekly_reports/week_00/PrimaryRecomputationChecks.json), [results/week0/final40/execution_metadata.json](../repository/results/week0/final40/execution_metadata.json), [results/week0/final40/replacement_results.csv](../repository/results/week0/final40/replacement_results.csv).

## What did NOT work?

The mock export cannot support retrieval/attention/utility correlations as a model discovery. Most pilot intervention deltas are negative. The larger study also contains negative and zero effects. No deployable budget controller or generation-quality superiority was evaluated.

## Limitations

Forty selected dev papers at most; known gold-answer teacher forcing; approximate evidence matching and replacement length; nested passage observations; pilot/final40 sample differences. The paper bootstrap interval is a newly reconstructed exploratory calculation, not a surviving original outcome file. No notebook executed outputs were found.

## Decision after this week

Current runner code avoids writing mocks to empirical paths and marks generic GPU work pending; separate pilot/final40 execution exists. An original frozen method-selection decision is not established from available primary artifacts. Exclude generic mock exports from empirical claims. Preserve all source evidence unchanged.

## One-paragraph week takeaway

Week0 supplies reproducible local QASPER split/retrieval descriptions and separate real teacher-forced sensitivity studies. Its generic model tables exactly reproduce mock generators and must be quarantined. Real final40 data associate strong annotation matching with greater positive replacement sensitivity, while preserving negative/null interventions and sampling limitations. The later joined Week3 oracle is retrospective. **EVIDENCE GAP — manual review required** before continuing the sequential reconstruction past this provenance conflict.

# Primary Sources Used

- [configs/week0/week0.yaml](../repository/configs/week0/week0.yaml)
- notebooks/week0/week0_analysis.ipynb (`../../../notebooks/week0/week0_analysis.ipynb`; source dependency not packaged)
- [results/week0/dataset_analysis/dataset_summary.csv](../repository/results/week0/dataset_analysis/dataset_summary.csv)
- [results/week0/dataset_analysis/evidence_statistics.csv](../repository/results/week0/dataset_analysis/evidence_statistics.csv)
- [results/week0/dataset_analysis/paper_level_statistics.csv](../repository/results/week0/dataset_analysis/paper_level_statistics.csv)
- results/week0/dataset_analysis/question_level_statistics.csv (`../../week0/dataset_analysis/question_level_statistics.csv`; source dependency not packaged)
- [results/week0/dataset_analysis/retrieval_statistics.csv](../repository/results/week0/dataset_analysis/retrieval_statistics.csv)
- [results/week0/evidence_analysis/ablation_passage_scores.csv](../repository/results/week0/evidence_analysis/ablation_passage_scores.csv)
- [results/week0/evidence_analysis/attention_passage_scores.csv](../repository/results/week0/evidence_analysis/attention_passage_scores.csv)
- [results/week0/evidence_analysis/signal_correlations.csv](../repository/results/week0/evidence_analysis/signal_correlations.csv)
- [results/week0/figures/retrieval_diagnostics.png](../repository/results/week0/figures/retrieval_diagnostics.png)
- [results/week0/final40/attention_results.csv](../repository/results/week0/final40/attention_results.csv)
- [results/week0/final40/evidence_match_results.csv](../repository/results/week0/final40/evidence_match_results.csv)
- [results/week0/final40/execution_metadata.json](../repository/results/week0/final40/execution_metadata.json)
- [results/week0/final40/figures/delta_replace_by_evidence_category.png](../repository/results/week0/final40/figures/delta_replace_by_evidence_category.png)
- [results/week0/final40/figures/per_query_intervention_heterogeneity.png](../repository/results/week0/final40/figures/per_query_intervention_heterogeneity.png)
- [results/week0/final40/figures/week0_vs_week3_oracle.png](../repository/results/week0/final40/figures/week0_vs_week3_oracle.png)
- [results/week0/final40/layer_results.csv](../repository/results/week0/final40/layer_results.csv)
- results/week0/final40/question_level_features.csv (`../../week0/final40/question_level_features.csv`; source dependency not packaged)
- [results/week0/final40/removal_results.csv](../repository/results/week0/final40/removal_results.csv)
- [results/week0/final40/replacement_results.csv](../repository/results/week0/final40/replacement_results.csv)
- [results/week0/final40/sample_manifest.csv](../repository/results/week0/final40/sample_manifest.csv)
- [results/week0/final40/week3_bridge.csv](../repository/results/week0/final40/week3_bridge.csv)
- [results/week0/gpu_pilot/ablation_results.csv](../repository/results/week0/gpu_pilot/ablation_results.csv)
- [results/week0/gpu_pilot/attention_results.csv](../repository/results/week0/gpu_pilot/attention_results.csv)
- [results/week0/gpu_pilot/execution_metadata.json](../repository/results/week0/gpu_pilot/execution_metadata.json)
- [results/week0/gpu_pilot/figures/attention_vs_intervention.png](../repository/results/week0/gpu_pilot/figures/attention_vs_intervention.png)
- [results/week0/gpu_pilot/intervention_validation/evidence_match_audit.csv](../repository/results/week0/gpu_pilot/intervention_validation/evidence_match_audit.csv)
- [results/week0/gpu_pilot/intervention_validation/figures/removal_vs_replacement_scatter.png](../repository/results/week0/gpu_pilot/intervention_validation/figures/removal_vs_replacement_scatter.png)
- [results/week0/gpu_pilot/intervention_validation/removal_vs_replacement.csv](../repository/results/week0/gpu_pilot/intervention_validation/removal_vs_replacement.csv)
- [results/week0/gpu_pilot/intervention_validation/replacement_results.csv](../repository/results/week0/gpu_pilot/intervention_validation/replacement_results.csv)
- [results/week0/gpu_pilot/layer_results.csv](../repository/results/week0/gpu_pilot/layer_results.csv)
- [results/week0/gpu_pilot/pilot_questions.csv](../repository/results/week0/gpu_pilot/pilot_questions.csv)
- [results/week0/gpu_status.json](../repository/results/week0/gpu_status.json)
- [results/week0/layer_analysis/layer_similarity_long.csv](../repository/results/week0/layer_analysis/layer_similarity_long.csv)
- [results/week3/processed/dev_quality_oracle.csv](../repository/results/week3/processed/dev_quality_oracle.csv)
- [results/week3/processed/epsilon_oracle_all.csv](../repository/results/week3/processed/epsilon_oracle_all.csv)
- [results/weekly_reports/week_00/OfflineBootstrapReconstruction.json](../repository/results/weekly_reports/week_00/OfflineBootstrapReconstruction.json)
- [results/weekly_reports/week_00/PrimaryRecomputationChecks.json](../repository/results/weekly_reports/week_00/PrimaryRecomputationChecks.json)
- scripts/week0/generate_final40_figures_and_report.py (`../../../scripts/week0/generate_final40_figures_and_report.py`; source dependency not packaged)
- scripts/week0/run_final40_study.py (`../../../scripts/week0/run_final40_study.py`; source dependency not packaged)
- scripts/week0/run_gpu_pilot.py (`../../../scripts/week0/run_gpu_pilot.py`; source dependency not packaged)
- scripts/week0/run_intervention_validation.py (`../../../scripts/week0/run_intervention_validation.py`; source dependency not packaged)
- scripts/week0/run_week0_analysis.py (`../../../scripts/week0/run_week0_analysis.py`; source dependency not packaged)
- scripts/week0/select_final40_sample.py (`../../../scripts/week0/select_final40_sample.py`; source dependency not packaged)
- scripts/weekly_reports/check_week0_primary.py (`../../../scripts/weekly_reports/check_week0_primary.py`; source dependency not packaged)
- src/week0/dataset_adapter.py (`../../../src/week0/dataset_adapter.py`; source dependency not packaged)
- src/week0/evidence_utilization.py (`../../../src/week0/evidence_utilization.py`; source dependency not packaged)
- src/week0/layer_analyzer.py (`../../../src/week0/layer_analyzer.py`; source dependency not packaged)

# Existing Markdown Used as Evidence

NONE


---

## Week 1

Source: [results/weekly_reports/week_01/WeeklySummaryAnalysis.md](../repository/results/weekly_reports/week_01/WeeklySummaryAnalysis.md)

# Week 1 — Summary Analysis

## Objective

Reconstruct the baseline implementation, local split, actual SARA/RAG training and checkpoint qualification under Baselines/. User-provided scope resolves the previous missing Week1 mapping; code availability is separated from trained checkpoints and answer-quality evaluation.

## Experiments performed

| Part   | Question                                                                                          | Status       | Main_result                                                                                                                                                                                                                                                                                                       |
|:-------|:--------------------------------------------------------------------------------------------------|:-------------|:------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| A      | Which local examples underpin the reproduced SARA/RAG baselines?                                  | COMPLETED    | The manifest and raw files agree:2088 TRAIN queries/772 papers,231 DEV queries/86 papers, and zero TRAIN/DEV paper overlap. TEST has1309 rows according to metadata only; its questions/outcomes were not loaded for this reconstruction.                                                                         |
| B      | Was a projector-free RAG adapter actually trained rather than merely configured?                  | COMPLETED    | RAG has250 logged optimizer steps and a saved adapter. Executed notebook cell10 reports506 training examples, runtime14988.353 seconds and train_loss5.325839; the final logged step loss2.9502 is a different quantity.                                                                                          |
| C      | Was the text-plus-latent baseline trained, and how does its execution provenance differ from RAG? | COMPLETED    | The SARA checkpoint trainer state records250 optimizer steps and epoch0.501002, with last logged loss5.4034. Saved args use one epoch, unlike current YAML3. Notebook cell11 preserves an OOM-failed training attempt; that specific failure and the separately saved completed checkpoint must both be retained. |
| D      | Can both saved checkpoints load with their intended projector/tokenizer interfaces?               | SMOKE-TESTED | Executed cell13 records RAG/SARA loading in10.23/9.67 seconds, peak GPU13.51/13.58 GiB, compress token32001 and vocabulary32002. RAG is projector-free; SARA prints nonzero projector norm164.                                                                                                                    |
| E      | What do the saved loss trajectories establish about baseline training?                            | COMPLETED    | Both trainer histories contain250 finite logged losses. Their means/final losses are recomputed in the table; differences cannot be interpreted as comparative QA accuracy.                                                                                                                                       |
| F      | Is there a standalone completed Week1 answer-quality comparison in Baselines?                     | IMPLEMENTED  | Evaluation code exists, but no standalone completed local Week1 QA score table or raw evaluation result was located inside Baselines. Week2 outcomes are not copied backward into Week1.                                                                                                                          |
| G      | Which additional evidence-selection/extraction baseline is implemented?                           | IMPLEMENTED  | SANE code/configuration and benchmark interfaces are present. No completed local Week1 SANE quality run was found; current default model/config must not be assumed to be its historical Week1 frozen identity.                                                                                                   |
| H      | Does the RECOMP checkout establish a locally executed baseline comparison?                        | IMPLEMENTED  | RECOMP implementation is present with a3610-row bundled NQ completion CSV. Its local generation provenance is not established, so it is not counted as a completed Week1 experiment or a QASPER result.                                                                                                           |

## Key results

### Manifest counts independently checked against TRAIN/DEV JSONL

| split                                |   queries | papers         | source                                                        |
|:-------------------------------------|----------:|:---------------|:--------------------------------------------------------------|
| TRAIN                                |      2088 | 772            | Baselines/SARA-main/data/reformatted/QASPER_train_split.jsonl |
| DEV                                  |       231 | 86             | Baselines/SARA-main/data/reformatted/QASPER_dev.jsonl         |
| TEST metadata only; no outcomes read |      1309 | Not recomputed | Baselines/SARA-main/data/manifests/qasper_split.json          |

Source: Baselines/SARA-main/data/manifests/qasper_split.json (`../../../Baselines/SARA-main/data/manifests/qasper_split.json`; source dependency not packaged).

### Saved RAG training record

| method   |   global_step |   logged_steps |   recorded_epoch |   saved_num_train_epochs |   saved_num_evidence |   saved_num_additional_evidence |   model_learning_rate |   projector_learning_rate |   batch_size |   gradient_accumulation |   max_train_samples_argument |   mean_logged_training_loss |   last_logged_training_loss |   max_logged_grad_norm | best_metric   |   adapter_weight_bytes |
|:---------|--------------:|---------------:|-----------------:|-------------------------:|---------------------:|--------------------------------:|----------------------:|--------------------------:|-------------:|------------------------:|-----------------------------:|----------------------------:|----------------------------:|-----------------------:|:--------------|-----------------------:|
| RAG      |           250 |            250 |         1.972332 |                        2 |                   10 |                               0 |              0.000020 |                  0.000000 |            1 |                       4 |                         2000 |                    5.325842 |                    2.950200 |            1975.659912 |               |               27280152 |

Source: [Baselines/SARA-main/checkpoints/finetune/rag_qasper_lora_r16_seed42/checkpoint-250/trainer_state.json](../repository/Baselines/SARA-main/checkpoints/finetune/rag_qasper_lora_r16_seed42/checkpoint-250/trainer_state.json).

### Executed RAG notebook training log

|   notebook_cell |   num_examples_logged |   reported_training_runtime_seconds |   reported_training_loss |
|----------------:|----------------------:|------------------------------------:|-------------------------:|
|       10.000000 |            506.000000 |                        14988.353000 |                 5.325839 |

Source: Baselines/SARA-main/notebooks/sara_baseline_checkpoints.ipynb (`../../../Baselines/SARA-main/notebooks/sara_baseline_checkpoints.ipynb`; source dependency not packaged).

### Saved SARA training record

| method   |   global_step |   logged_steps |   recorded_epoch |   saved_num_train_epochs |   saved_num_evidence |   saved_num_additional_evidence |   model_learning_rate |   projector_learning_rate |   batch_size |   gradient_accumulation |   max_train_samples_argument |   mean_logged_training_loss |   last_logged_training_loss |   max_logged_grad_norm | best_metric   |   adapter_weight_bytes |
|:---------|--------------:|---------------:|-----------------:|-------------------------:|---------------------:|--------------------------------:|----------------------:|--------------------------:|-------------:|------------------------:|-----------------------------:|----------------------------:|----------------------------:|-----------------------:|:--------------|-----------------------:|
| SARA     |           250 |            250 |         0.501002 |                        1 |                    5 |                               5 |              0.000020 |                  0.000500 |            1 |                       4 |                         2000 |                    6.936258 |                    5.403400 |            3262.517822 |               |               27280152 |

Source: [Baselines/SARA-main/checkpoints/finetune/sara_qasper_proj_lr5e4_seed42/checkpoint-250/trainer_state.json](../repository/Baselines/SARA-main/checkpoints/finetune/sara_qasper_proj_lr5e4_seed42/checkpoint-250/trainer_state.json).

### Current configuration versus saved-run epoch identity

| method   |   current_yaml_epochs |   saved_run_epochs | source                                                                         |
|:---------|----------------------:|-------------------:|:-------------------------------------------------------------------------------|
| RAG      |                     3 |                  2 | Baselines/SARA-main/config/language_modeling/Finetune_RAG_qasper_pubbase.yaml  |
| SARA     |                     3 |                  1 | Baselines/SARA-main/config/language_modeling/Finetune_SARA_qasper_pubbase.yaml |

Source: [Baselines/SARA-main/config/language_modeling/Finetune_SARA_qasper_pubbase.yaml](../repository/Baselines/SARA-main/config/language_modeling/Finetune_SARA_qasper_pubbase.yaml).

### Executed notebook cell13 checkpoint profiles

| checkpoint                    |   load_seconds |   peak_GPU_GiB |   compress_token_id |   tokenizer_vocab |
|:------------------------------|---------------:|---------------:|--------------------:|------------------:|
| rag_qasper_lora_r16_seed42    |      10.230000 |      13.510000 |               32001 |             32002 |
| sara_qasper_proj_lr5e4_seed42 |       9.670000 |      13.580000 |               32001 |             32002 |

Source: Baselines/SARA-main/notebooks/sara_baseline_checkpoints.ipynb (`../../../Baselines/SARA-main/notebooks/sara_baseline_checkpoints.ipynb`; source dependency not packaged).

### Offline recomputed log summaries

| method   |   logged_steps |   recorded_epoch |   mean_logged_training_loss |   last_logged_training_loss |   max_logged_grad_norm |
|:---------|---------------:|-----------------:|----------------------------:|----------------------------:|-----------------------:|
| RAG      |            250 |         1.972332 |                    5.325842 |                    2.950200 |            1975.659912 |
| SARA     |            250 |         0.501002 |                    6.936258 |                    5.403400 |            3262.517822 |

Source: [results/weekly_reports/week_01/TrainingRecomputation.csv](../repository/results/weekly_reports/week_01/TrainingRecomputation.csv).

### Bundled completion-file inventory; not a locally verified run

|   rows |   question_rows |   prediction_rows | columns                                                        |
|-------:|----------------:|------------------:|:---------------------------------------------------------------|
|   3610 |            3610 |              3610 | Unnamed: 0,few_shot_examples,question,pred_answer,gold_answers |

Source: Baselines/recomp-main/data/completions/flan_ul2_nq_5shot_no_passage.csv (`../../../Baselines/recomp-main/data/completions/flan_ul2_nq_5shot_no_passage.csv`; source dependency not packaged).

## Main scientific conclusions

- The manifest and raw files agree:2088 TRAIN queries/772 papers,231 DEV queries/86 papers, and zero TRAIN/DEV paper overlap. TEST has1309 rows according to metadata only; its questions/outcomes were not loaded for this reconstruction. Source: Baselines/SARA-main/data/manifests/qasper_split.json (`../../../Baselines/SARA-main/data/manifests/qasper_split.json`; source dependency not packaged), Baselines/SARA-main/data/reformatted/QASPER_train_split.jsonl (`../../../Baselines/SARA-main/data/reformatted/QASPER_train_split.jsonl`; source dependency not packaged)
- RAG has250 logged optimizer steps and a saved adapter. Executed notebook cell10 reports506 training examples, runtime14988.353 seconds and train_loss5.325839; the final logged step loss2.9502 is a different quantity. Source: [Baselines/SARA-main/checkpoints/finetune/rag_qasper_lora_r16_seed42/args.json](../repository/Baselines/SARA-main/checkpoints/finetune/rag_qasper_lora_r16_seed42/args.json), [Baselines/SARA-main/checkpoints/finetune/rag_qasper_lora_r16_seed42/checkpoint-250/trainer_state.json](../repository/Baselines/SARA-main/checkpoints/finetune/rag_qasper_lora_r16_seed42/checkpoint-250/trainer_state.json)
- The SARA checkpoint trainer state records250 optimizer steps and epoch0.501002, with last logged loss5.4034. Saved args use one epoch, unlike current YAML3. Notebook cell11 preserves an OOM-failed training attempt; that specific failure and the separately saved completed checkpoint must both be retained. Source: [Baselines/SARA-main/checkpoints/finetune/sara_qasper_proj_lr5e4_seed42/args.json](../repository/Baselines/SARA-main/checkpoints/finetune/sara_qasper_proj_lr5e4_seed42/args.json), [Baselines/SARA-main/checkpoints/finetune/sara_qasper_proj_lr5e4_seed42/checkpoint-250/trainer_state.json](../repository/Baselines/SARA-main/checkpoints/finetune/sara_qasper_proj_lr5e4_seed42/checkpoint-250/trainer_state.json)
- Executed cell13 records RAG/SARA loading in10.23/9.67 seconds, peak GPU13.51/13.58 GiB, compress token32001 and vocabulary32002. RAG is projector-free; SARA prints nonzero projector norm164. Source: Baselines/SARA-main/notebooks/sara_baseline_checkpoints.ipynb (`../../../Baselines/SARA-main/notebooks/sara_baseline_checkpoints.ipynb`; source dependency not packaged), [Baselines/SARA-main/checkpoints/finetune/rag_qasper_lora_r16_seed42/adapter_config.json](../repository/Baselines/SARA-main/checkpoints/finetune/rag_qasper_lora_r16_seed42/adapter_config.json)
- Both trainer histories contain250 finite logged losses. Their means/final losses are recomputed in the table; differences cannot be interpreted as comparative QA accuracy. Source: [Baselines/SARA-main/checkpoints/finetune/rag_qasper_lora_r16_seed42/checkpoint-250/trainer_state.json](../repository/Baselines/SARA-main/checkpoints/finetune/rag_qasper_lora_r16_seed42/checkpoint-250/trainer_state.json), [Baselines/SARA-main/checkpoints/finetune/sara_qasper_proj_lr5e4_seed42/checkpoint-250/trainer_state.json](../repository/Baselines/SARA-main/checkpoints/finetune/sara_qasper_proj_lr5e4_seed42/checkpoint-250/trainer_state.json)
- Evaluation code exists, but no standalone completed local Week1 QA score table or raw evaluation result was located inside Baselines. Week2 outcomes are not copied backward into Week1. Source: Baselines/SARA-main/src/eval/eval_sara.py (`../../../Baselines/SARA-main/src/eval/eval_sara.py`; source dependency not packaged), Baselines/SARA-main/src/eval/calculate_qa_performance.py (`../../../Baselines/SARA-main/src/eval/calculate_qa_performance.py`; source dependency not packaged)
- SANE code/configuration and benchmark interfaces are present. No completed local Week1 SANE quality run was found; current default model/config must not be assumed to be its historical Week1 frozen identity. Source: Baselines/SANE-main/config/default.yaml (`../../../Baselines/SANE-main/config/default.yaml`; source dependency not packaged), Baselines/SANE-main/benchmarks/metrics.py (`../../../Baselines/SANE-main/benchmarks/metrics.py`; source dependency not packaged)
- RECOMP implementation is present with a3610-row bundled NQ completion CSV. Its local generation provenance is not established, so it is not counted as a completed Week1 experiment or a QASPER result. Source: Baselines/recomp-main/run_extractive_compressor.py (`../../../Baselines/recomp-main/run_extractive_compressor.py`; source dependency not packaged), Baselines/recomp-main/train_extractive_compressor.py (`../../../Baselines/recomp-main/train_extractive_compressor.py`; source dependency not packaged)

## What did NOT work?

SARA notebook training attempt OOMs; no completed standalone Week1 QA quality comparison or local SANE/RECOMP benchmark is established.

## Limitations

Baseline training sample/epoch identities are not fully matched; quality is not established by training losses, load timing, projector norm or bundled external completions.

## Decision after this week

Saved public-base RAG and SARA checkpoints exist for later controlled evaluation. SANE/RECOMP are implemented references with no verified local Week1 performance.

## One-paragraph week takeaway

The manifest and raw files agree:2088 TRAIN queries/772 papers,231 DEV queries/86 papers, and zero TRAIN/DEV paper overlap. TEST has1309 rows according to metadata only; its questions/outcomes were not loaded for this reconstruction. RAG has250 logged optimizer steps and a saved adapter. Executed notebook cell10 reports506 training examples, runtime14988.353 seconds and train_loss5.325839; the final logged step loss2.9502 is a different quantity. The SARA checkpoint trainer state records250 optimizer steps and epoch0.501002, with last logged loss5.4034. Saved args use one epoch, unlike current YAML3. Notebook cell11 preserves an OOM-failed training attempt; that specific failure and the separately saved completed checkpoint must both be retained. Executed cell13 records RAG/SARA loading in10.23/9.67 seconds, peak GPU13.51/13.58 GiB, compress token32001 and vocabulary32002. RAG is projector-free; SARA prints nonzero projector norm164. Both trainer histories contain250 finite logged losses. Their means/final losses are recomputed in the table; differences cannot be interpreted as comparative QA accuracy. Evaluation code exists, but no standalone completed local Week1 QA score table or raw evaluation result was located inside Baselines. Week2 outcomes are not copied backward into Week1. SANE code/configuration and benchmark interfaces are present. No completed local Week1 SANE quality run was found; current default model/config must not be assumed to be its historical Week1 frozen identity. RECOMP implementation is present with a3610-row bundled NQ completion CSV. Its local generation provenance is not established, so it is not counted as a completed Week1 experiment or a QASPER result.

# Primary Sources Used

- Baselines/SANE-main/benchmarks/metrics.py (`../../../Baselines/SANE-main/benchmarks/metrics.py`; source dependency not packaged)
- Baselines/SANE-main/config/default.yaml (`../../../Baselines/SANE-main/config/default.yaml`; source dependency not packaged)
- Baselines/SANE-main/sane/agents/sane_agent.py (`../../../Baselines/SANE-main/sane/agents/sane_agent.py`; source dependency not packaged)
- [Baselines/SARA-main/checkpoints/finetune/rag_qasper_lora_r16_seed42/adapter_config.json](../repository/Baselines/SARA-main/checkpoints/finetune/rag_qasper_lora_r16_seed42/adapter_config.json)
- [Baselines/SARA-main/checkpoints/finetune/rag_qasper_lora_r16_seed42/args.json](../repository/Baselines/SARA-main/checkpoints/finetune/rag_qasper_lora_r16_seed42/args.json)
- [Baselines/SARA-main/checkpoints/finetune/rag_qasper_lora_r16_seed42/checkpoint-250/trainer_state.json](../repository/Baselines/SARA-main/checkpoints/finetune/rag_qasper_lora_r16_seed42/checkpoint-250/trainer_state.json)
- [Baselines/SARA-main/checkpoints/finetune/sara_qasper_proj_lr5e4_seed42/adapter_config.json](../repository/Baselines/SARA-main/checkpoints/finetune/sara_qasper_proj_lr5e4_seed42/adapter_config.json)
- [Baselines/SARA-main/checkpoints/finetune/sara_qasper_proj_lr5e4_seed42/args.json](../repository/Baselines/SARA-main/checkpoints/finetune/sara_qasper_proj_lr5e4_seed42/args.json)
- [Baselines/SARA-main/checkpoints/finetune/sara_qasper_proj_lr5e4_seed42/checkpoint-250/trainer_state.json](../repository/Baselines/SARA-main/checkpoints/finetune/sara_qasper_proj_lr5e4_seed42/checkpoint-250/trainer_state.json)
- Baselines/SARA-main/checkpoints/finetune/sara_qasper_proj_lr5e4_seed42/sara_config.json (`../../../Baselines/SARA-main/checkpoints/finetune/sara_qasper_proj_lr5e4_seed42/sara_config.json`; source dependency not packaged)
- [Baselines/SARA-main/config/language_modeling/Finetune_RAG_qasper_pubbase.yaml](../repository/Baselines/SARA-main/config/language_modeling/Finetune_RAG_qasper_pubbase.yaml)
- [Baselines/SARA-main/config/language_modeling/Finetune_SARA_qasper_pubbase.yaml](../repository/Baselines/SARA-main/config/language_modeling/Finetune_SARA_qasper_pubbase.yaml)
- Baselines/SARA-main/data/manifests/qasper_split.json (`../../../Baselines/SARA-main/data/manifests/qasper_split.json`; source dependency not packaged)
- Baselines/SARA-main/data/reformatted/QASPER_dev.jsonl (`../../../Baselines/SARA-main/data/reformatted/QASPER_dev.jsonl`; source dependency not packaged)
- Baselines/SARA-main/data/reformatted/QASPER_train_split.jsonl (`../../../Baselines/SARA-main/data/reformatted/QASPER_train_split.jsonl`; source dependency not packaged)
- Baselines/SARA-main/notebooks/sara_baseline_checkpoints.ipynb (`../../../Baselines/SARA-main/notebooks/sara_baseline_checkpoints.ipynb`; source dependency not packaged)
- Baselines/SARA-main/scripts/build_qasper_dataset.py (`../../../Baselines/SARA-main/scripts/build_qasper_dataset.py`; source dependency not packaged)
- Baselines/SARA-main/src/data/make_qasper_splits.py (`../../../Baselines/SARA-main/src/data/make_qasper_splits.py`; source dependency not packaged)
- Baselines/SARA-main/src/eval/calculate_qa_performance.py (`../../../Baselines/SARA-main/src/eval/calculate_qa_performance.py`; source dependency not packaged)
- Baselines/SARA-main/src/eval/eval_sara.py (`../../../Baselines/SARA-main/src/eval/eval_sara.py`; source dependency not packaged)
- Baselines/SARA-main/src/run_sara.py (`../../../Baselines/SARA-main/src/run_sara.py`; source dependency not packaged)
- Baselines/SARA-main/src/train/train_generator.py (`../../../Baselines/SARA-main/src/train/train_generator.py`; source dependency not packaged)
- Baselines/recomp-main/data/completions/flan_ul2_nq_5shot_no_passage.csv (`../../../Baselines/recomp-main/data/completions/flan_ul2_nq_5shot_no_passage.csv`; source dependency not packaged)
- Baselines/recomp-main/eval_qa.py (`../../../Baselines/recomp-main/eval_qa.py`; source dependency not packaged)
- Baselines/recomp-main/run_extractive_compressor.py (`../../../Baselines/recomp-main/run_extractive_compressor.py`; source dependency not packaged)
- Baselines/recomp-main/train_extractive_compressor.py (`../../../Baselines/recomp-main/train_extractive_compressor.py`; source dependency not packaged)
- [results/weekly_reports/week_01/CheckpointProfilingExtract.csv](../repository/results/weekly_reports/week_01/CheckpointProfilingExtract.csv)
- [results/weekly_reports/week_01/NotebookExecutionChecks.json](../repository/results/weekly_reports/week_01/NotebookExecutionChecks.json)
- [results/weekly_reports/week_01/SplitRecomputation.json](../repository/results/weekly_reports/week_01/SplitRecomputation.json)
- [results/weekly_reports/week_01/TrainingLogExtract.csv](../repository/results/weekly_reports/week_01/TrainingLogExtract.csv)
- [results/weekly_reports/week_01/TrainingRecomputation.csv](../repository/results/weekly_reports/week_01/TrainingRecomputation.csv)
- [results/weekly_reports/week_01/figures/logged_training_loss.png](../repository/results/weekly_reports/week_01/figures/logged_training_loss.png)

# Existing Markdown Used as Evidence

NONE


---

## Week 2

Source: [results/weekly_reports/week_02/WeeklySummaryAnalysis.md](../repository/results/weekly_reports/week_02/WeeklySummaryAnalysis.md)

# Week 2 — Summary Analysis

## Objective

Measure the static SARA text/latent representation-budget frontier and retrospective adaptive headroom.

## Experiments performed

| Part    | Question                                                                              | Status    | Main_result                                                                                                                                                                                            |
|:--------|:--------------------------------------------------------------------------------------|:----------|:-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| FIXED-K | How do answer quality and context cost change as verbatim-passage budget k increases? | COMPLETED | SARA k8 has mean F1 0.3950 versus parent k5 0.3629; separate plain-RAG k10 has F1 0.4090. Increasing text budget improves these aggregate point estimates.                                             |
| ORACLE  | Would per-query best-tested k have headroom over the best static SARA budget?         | COMPLETED | The retrospective SARA oracle is about 0.5008 F1 versus static k8 0.3950; the full sweep oracle is about 0.5264. These are outcome-selected ceilings.                                                  |
| FREEZE  | Is the query/action grid complete and which reference was frozen for later modeling?  | COMPLETED | The 1,617-row matrix is exactly 231 queries × seven actions with no duplicate query/k pairs; static SARA k8 is retained. The checkpoint records zero train/dev paper overlap at that historical stage. |

## Key results

### Raw-result recomputed fixed-k metrics

|   k | method   |   queries |       F1 |       EM |      tokens |
|----:|:---------|----------:|---------:|---------:|------------:|
|   0 | sara     |       231 | 0.138829 | 0.086580 |  130.822511 |
|   2 | sara     |       231 | 0.303835 | 0.168831 |  526.523810 |
|   4 | sara     |       231 | 0.359601 | 0.199134 |  938.121212 |
|   5 | sara     |       231 | 0.362858 | 0.186147 | 1148.982684 |
|   6 | sara     |       231 | 0.385699 | 0.186147 | 1351.116883 |
|   8 | sara     |       231 | 0.394995 | 0.186147 | 1750.463203 |
|  10 | rag      |       231 | 0.409043 | 0.203463 | 2129.883117 |

Source: results/week2/raw/dev_fixed_k_matrix.jsonl (`../../week2/raw/dev_fixed_k_matrix.jsonl`; source dependency not packaged).

### Retrospective ceilings; not deployable policies

| actions                      |   retrospective_oracle_F1 |
|:-----------------------------|--------------------------:|
| SARA {0,2,4,5,6,8}           |                  0.500781 |
| Full sweep including RAG k10 |                  0.526415 |

Source: results/week2/raw/dev_fixed_k_matrix.jsonl (`../../week2/raw/dev_fixed_k_matrix.jsonl`; source dependency not packaged).

### Smallest-k tie-broken distribution

|         k |   best_sara_k_count |   best_sara_k_pct |   best_overall_k_count |   best_overall_k_pct |
|----------:|--------------------:|------------------:|-----------------------:|---------------------:|
|  0.000000 |           81.000000 |         35.060000 |              73.000000 |            31.600000 |
|  2.000000 |           55.000000 |         23.810000 |              52.000000 |            22.510000 |
|  4.000000 |           37.000000 |         16.020000 |              33.000000 |            14.290000 |
|  5.000000 |           15.000000 |          6.490000 |              14.000000 |             6.060000 |
|  6.000000 |           21.000000 |          9.090000 |              21.000000 |             9.090000 |
|  8.000000 |           22.000000 |          9.520000 |              19.000000 |             8.230000 |
| 10.000000 |            0.000000 |          0.000000 |              19.000000 |             8.230000 |

Source: [results/week2/processed/best_k_distribution.csv](../repository/results/week2/processed/best_k_distribution.csv).

## Main scientific conclusions

- SARA k8 has mean F1 0.3950 versus parent k5 0.3629; separate plain-RAG k10 has F1 0.4090. Increasing text budget improves these aggregate point estimates. Source: results/week2/raw/dev_fixed_k_matrix.jsonl (`../../week2/raw/dev_fixed_k_matrix.jsonl`; source dependency not packaged), [results/week2/processed/dev_fixed_k_summary.csv](../repository/results/week2/processed/dev_fixed_k_summary.csv)
- The retrospective SARA oracle is about 0.5008 F1 versus static k8 0.3950; the full sweep oracle is about 0.5264. These are outcome-selected ceilings. Source: results/week2/processed/per_query_best_k.csv (`../../week2/processed/per_query_best_k.csv`; source dependency not packaged), [results/week2/processed/oracle_vs_static_summary.json](../repository/results/week2/processed/oracle_vs_static_summary.json)
- The 1,617-row matrix is exactly 231 queries × seven actions with no duplicate query/k pairs; static SARA k8 is retained. The checkpoint records zero train/dev paper overlap at that historical stage. Source: [results/week2/processed/best_static_baseline.json](../repository/results/week2/processed/best_static_baseline.json), [results/week2/processed/week2_validation_checkpoint.json](../repository/results/week2/processed/week2_validation_checkpoint.json)

## What did NOT work?

No learned allocator or prospective generalization is evaluated.

## Limitations

Small local DEV cohort, outcome-selected ceilings, shared-query dependence and different SARA/RAG checkpoints.

## Decision after this week

SARA k8 retained; RAG k10 tracked separately.

## One-paragraph week takeaway

SARA k8 has mean F1 0.3950 versus parent k5 0.3629; separate plain-RAG k10 has F1 0.4090. Increasing text budget improves these aggregate point estimates. The retrospective SARA oracle is about 0.5008 F1 versus static k8 0.3950; the full sweep oracle is about 0.5264. These are outcome-selected ceilings. The 1,617-row matrix is exactly 231 queries × seven actions with no duplicate query/k pairs; static SARA k8 is retained. The checkpoint records zero train/dev paper overlap at that historical stage.

## Additional primary visualizations

![Recorded experimental figure](../repository/results/week2/plots/05_token_f1_vs_context_tokens.png)

X-axis is mean context tokens; y-axis token F1. The fixed-k frontier shows the quality/cost tradeoff; k10 is a separately trained RAG system, not an isolated compression ablation.

Source: [results/week2/plots/05_token_f1_vs_context_tokens.png](../repository/results/week2/plots/05_token_f1_vs_context_tokens.png).

# Primary Sources Used

- [configs/week2/sweep_config.yaml](../repository/configs/week2/sweep_config.yaml)
- notebooks/week2/week2_dev_fixed_k_sweep.ipynb (`../../../notebooks/week2/week2_dev_fixed_k_sweep.ipynb`; source dependency not packaged)
- [results/week2/processed/best_k_distribution.csv](../repository/results/week2/processed/best_k_distribution.csv)
- [results/week2/processed/best_static_baseline.json](../repository/results/week2/processed/best_static_baseline.json)
- [results/week2/processed/dev_fixed_k_summary.csv](../repository/results/week2/processed/dev_fixed_k_summary.csv)
- [results/week2/processed/oracle_vs_static_summary.json](../repository/results/week2/processed/oracle_vs_static_summary.json)
- results/week2/processed/per_query_best_k.csv (`../../week2/processed/per_query_best_k.csv`; source dependency not packaged)
- [results/week2/processed/week2_validation_checkpoint.json](../repository/results/week2/processed/week2_validation_checkpoint.json)
- results/week2/raw/dev_fixed_k_matrix.jsonl (`../../week2/raw/dev_fixed_k_matrix.jsonl`; source dependency not packaged)

- [results/week2/plots/05_token_f1_vs_context_tokens.png](../repository/results/week2/plots/05_token_f1_vs_context_tokens.png)

# Existing Markdown Used as Evidence

NONE


---

## Week 3

Source: [results/weekly_reports/week_03/WeeklySummaryAnalysis.md](../repository/results/weekly_reports/week_03/WeeklySummaryAnalysis.md)

# Week 3 — Summary Analysis

## Objective

Quantify tie-aware adaptive headroom, freeze epsilon targets, inspect observable signals and prepare blinded human validation.

## Experiments performed

| Part           | Question                                                                                             | Status      | Main_result                                                                                                                                                                                                     |
|:---------------|:-----------------------------------------------------------------------------------------------------|:------------|:----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| QUALITY-ORACLE | How much adaptive headroom remains after excluding pure compression and the separate RAG checkpoint? | COMPLETED   | The restricted retrospective oracle mean is 0.489507, with mean gain 0.094512 over k8. Only 29.44% of queries strictly improve over k8; 60.61% tie k8 with a smaller action.                                    |
| EPSILON        | Can smaller retrospective actions preserve quality within a declared tolerance?                      | COMPLETED   | The development-selected epsilon is 0.01: stored mean F1 0.4894, mean k3.49 and mean context 841.3 tokens, about 52.16% below k8. Primary action-set feasibility is 100%.                                       |
| FEATURES       | Do simple retrieval/query observables correlate with oracle action labels?                           | COMPLETED   | Recorded feature associations are weak; for example n_high versus budget has Spearman rho −0.1421 (nominal p0.0308). This motivates testing predictors but does not establish out-of-sample predictive utility. |
| HUMAN-AUDIT    | Do human ratings independently confirm automatic-score differences?                                  | IMPLEMENTED | SOURCE CONFLICT: human_audit_summary.csv reports 50 judgments per k, but all 150 score_0_1_2 entries in human_scoring_template.csv are blank and week3_gate.json says PENDING_MANUAL_EVALUATION. The summary cannot be certified as observed human evaluation; completed human judgment evidence is not established.                                                                 |

## Key results

### Smallest-budget quality oracle distribution

|        k |      count |       pct |   cumulative_count |   cumulative_pct |
|---------:|-----------:|----------:|-------------------:|-----------------:|
| 2.000000 | 130.000000 | 56.280000 |         130.000000 |        56.280000 |
| 4.000000 |  40.000000 | 17.320000 |         170.000000 |        73.590000 |
| 5.000000 |  17.000000 |  7.360000 |         187.000000 |        80.950000 |
| 6.000000 |  21.000000 |  9.090000 |         208.000000 |        90.040000 |
| 8.000000 |  23.000000 |  9.960000 |         231.000000 |       100.000000 |

Source: [results/week3/processed/quality_oracle_distribution.csv](../repository/results/week3/processed/quality_oracle_distribution.csv).

### Tie-aware counts and stored uncertainty

| field                                       |      value |
|:--------------------------------------------|-----------:|
| tie_aware.k8_in_exact_best_set_count        | 163.000000 |
| tie_aware.k8_in_exact_best_set_pct          |  70.560000 |
| tie_aware.k8_unique_strict_winner_count     |  23.000000 |
| tie_aware.k8_unique_strict_winner_pct       |   9.960000 |
| tie_aware.k8_strictly_suboptimal_count      |  68.000000 |
| tie_aware.k8_strictly_suboptimal_pct        |  29.440000 |
| tie_aware.k8_tied_with_smaller_budget_count | 140.000000 |
| tie_aware.k8_tied_with_smaller_budget_pct   |  60.610000 |
| bootstrap.mean_oracle_f1.mean               |   0.490400 |
| bootstrap.mean_oracle_f1.ci_lower           |   0.439900 |
| bootstrap.mean_oracle_f1.ci_upper           |   0.545400 |
| bootstrap.mean_oracle_f1.ci_level           |   0.950000 |

Source: [results/week3/processed/heterogeneity_summary.json](../repository/results/week3/processed/heterogeneity_summary.json). First 12 of 56 rows shown; detailed report and source preserve the full comparison.

### All epsilon candidates

|   epsilon |   mean_k |   median_k |   mean_f1 |   mean_regret |   max_regret |   p95_regret |   mean_context_tokens |   context_reduction_pct_vs_k8 |   context_reduction_pct_vs_k10 |   feasibility_pct_sara |    pct_k2 |    pct_k4 |   pct_k5 |   pct_k6 |   pct_k8 |   diag_sweep_feasibility_pct |
|----------:|---------:|-----------:|----------:|--------------:|-------------:|-------------:|----------------------:|------------------------------:|-------------------------------:|-----------------------:|----------:|----------:|---------:|---------:|---------:|-----------------------------:|
|  0.000000 | 3.530000 |   2.000000 |  0.489500 |      0.000000 |     0.000000 |     0.000000 |            848.400000 |                     51.750000 |                      60.320000 |             100.000000 | 56.280000 | 17.320000 | 7.360000 | 9.090000 | 9.960000 |                    86.580000 |
|  0.010000 | 3.490000 |   2.000000 |  0.489400 |      0.000100 |     0.009500 |     0.000000 |            841.300000 |                     52.160000 |                      60.650000 |             100.000000 | 57.140000 | 17.320000 | 7.360000 | 8.230000 | 9.960000 |                    86.580000 |
|  0.020000 | 3.450000 |   2.000000 |  0.489200 |      0.000300 |     0.020000 |     0.000000 |            831.600000 |                     52.710000 |                      61.100000 |             100.000000 | 58.010000 | 17.320000 | 6.930000 | 8.660000 | 9.090000 |                    87.010000 |
|  0.050000 | 3.430000 |   2.000000 |  0.488800 |      0.000700 |     0.050000 |     0.000000 |            828.000000 |                     52.910000 |                      61.270000 |             100.000000 | 58.440000 | 16.880000 | 6.930000 | 9.090000 | 8.660000 |                    88.310000 |

Source: [results/week3/processed/epsilon_summary.csv](../repository/results/week3/processed/epsilon_summary.csv).

### Offline recomputed means

|   epsilon |          n |   mean_k |       F1 |   regret |     tokens |
|----------:|-----------:|---------:|---------:|---------:|-----------:|
|  0.000000 | 231.000000 | 3.528139 | 0.489507 | 0.000000 | 848.418182 |
|  0.010000 | 231.000000 | 3.493506 | 0.489391 | 0.000116 | 841.278788 |
|  0.020000 | 231.000000 | 3.445887 | 0.489203 | 0.000304 | 831.556277 |
|  0.050000 | 231.000000 | 3.428571 | 0.488839 | 0.000668 | 828.045455 |

Source: [results/week3/processed/epsilon_oracle_all.csv](../repository/results/week3/processed/epsilon_oracle_all.csv).

## Main scientific conclusions

- The restricted retrospective oracle mean is 0.489507, with mean gain 0.094512 over k8. Only 29.44% of queries strictly improve over k8; 60.61% tie k8 with a smaller action. Source: [results/week3/processed/dev_quality_oracle.csv](../repository/results/week3/processed/dev_quality_oracle.csv), [results/week3/processed/heterogeneity_summary.json](../repository/results/week3/processed/heterogeneity_summary.json)
- The development-selected epsilon is 0.01: stored mean F1 0.4894, mean k3.49 and mean context 841.3 tokens, about 52.16% below k8. Primary action-set feasibility is 100%. Source: [results/week3/processed/epsilon_summary.csv](../repository/results/week3/processed/epsilon_summary.csv), [results/week3/processed/epsilon_oracle_all.csv](../repository/results/week3/processed/epsilon_oracle_all.csv)
- Recorded feature associations are weak; for example n_high versus budget has Spearman rho −0.1421 (nominal p0.0308). This motivates testing predictors but does not establish out-of-sample predictive utility. Source: [results/week3/processed/feature_signal_analysis.csv](../repository/results/week3/processed/feature_signal_analysis.csv)
- SOURCE CONFLICT: human_audit_summary.csv reports 50 judgments per k, but all 150 score_0_1_2 entries in human_scoring_template.csv are blank and week3_gate.json says PENDING_MANUAL_EVALUATION. The summary cannot be certified as observed human evaluation; completed human judgment evidence is not established. Source: results/week3/human_audit/human_scoring_template.csv (`../../week3/human_audit/human_scoring_template.csv`; source dependency not packaged), [results/week3/human_audit/human_audit_summary.csv](../repository/results/week3/human_audit/human_audit_summary.csv)

## What did NOT work?

Human evaluation remains pending; no deployable adaptive controller is established.

## Limitations

Development exposure, weak associations, oracle label ties and small paper count.

## Decision after this week

epsilon0.01 retained; proceed gate concerns modeling readiness, not successful human validation.

## One-paragraph week takeaway

The restricted retrospective oracle mean is 0.489507, with mean gain 0.094512 over k8. Only 29.44% of queries strictly improve over k8; 60.61% tie k8 with a smaller action. The development-selected epsilon is 0.01: stored mean F1 0.4894, mean k3.49 and mean context 841.3 tokens, about 52.16% below k8. Primary action-set feasibility is 100%. Recorded feature associations are weak; for example n_high versus budget has Spearman rho −0.1421 (nominal p0.0308). This motivates testing predictors but does not establish out-of-sample predictive utility. SOURCE CONFLICT: human_audit_summary.csv reports 50 judgments per k, but all 150 score_0_1_2 entries in human_scoring_template.csv are blank and week3_gate.json says PENDING_MANUAL_EVALUATION. The summary cannot be certified as observed human evaluation; completed human judgment evidence is not established.

## Additional primary visualizations

![Recorded experimental figure](../repository/results/week3/plots/plot5_epsilon_vs_mean_k.png)

X-axis is retrospective oracle tolerance epsilon; y-axis mean selected k. Lower cost follows outcome-aware selection, not a trained inference-time policy. Human-score figures are deliberately excluded because raw ratings are blank.

Source: [results/week3/plots/plot5_epsilon_vs_mean_k.png](../repository/results/week3/plots/plot5_epsilon_vs_mean_k.png).

# Primary Sources Used

- [configs/week3/week3_config.yaml](../repository/configs/week3/week3_config.yaml)
- notebooks/week3/week3_oracle_epsilon_human_audit.ipynb (`../../../notebooks/week3/week3_oracle_epsilon_human_audit.ipynb`; source dependency not packaged)
- notebooks/week3/week3_oracle_target_analysis.ipynb (`../../../notebooks/week3/week3_oracle_target_analysis.ipynb`; source dependency not packaged)
- [results/week3/human_audit/human_audit_summary.csv](../repository/results/week3/human_audit/human_audit_summary.csv)
- results/week3/human_audit/human_scoring_template.csv (`../../week3/human_audit/human_scoring_template.csv`; source dependency not packaged)
- [results/week3/processed/dev_quality_oracle.csv](../repository/results/week3/processed/dev_quality_oracle.csv)
- [results/week3/processed/epsilon_oracle_all.csv](../repository/results/week3/processed/epsilon_oracle_all.csv)
- [results/week3/processed/epsilon_summary.csv](../repository/results/week3/processed/epsilon_summary.csv)
- [results/week3/processed/feature_signal_analysis.csv](../repository/results/week3/processed/feature_signal_analysis.csv)
- [results/week3/processed/heterogeneity_summary.json](../repository/results/week3/processed/heterogeneity_summary.json)
- [results/week3/processed/quality_oracle_distribution.csv](../repository/results/week3/processed/quality_oracle_distribution.csv)
- [results/week3/processed/selected_epsilon.json](../repository/results/week3/processed/selected_epsilon.json)
- [results/week3/processed/week3_gate.json](../repository/results/week3/processed/week3_gate.json)

- [results/week3/plots/plot5_epsilon_vs_mean_k.png](../repository/results/week3/plots/plot5_epsilon_vs_mean_k.png)

# Existing Markdown Used as Evidence

NONE


---

## Week 4

Source: [results/weekly_reports/week_04/WeeklySummaryAnalysis.md](../repository/results/weekly_reports/week_04/WeeklySummaryAnalysis.md)

# Week 4 — Summary Analysis

## Objective

Test whether observable query/retrieval/content features can choose SARA representation budgets, then diagnose direct and sequential allocation failures.

## Experiments performed

| Part               | Question                                                                       | Status    | Main_result                                                                                                                                                                   |
|:-------------------|:-------------------------------------------------------------------------------|:----------|:------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| FEATURE-DISCOVERY  | Which pregeneration feature families associate with budget/transition targets? | COMPLETED | All feature-family maximum absolute Spearman correlations are below 0.19; observed individual associations are weak.                                                          |
| FEATURE-VALIDATION | Do associations survive redundancy and multiple-comparison checks?             | COMPLETED | The six-family validation summary reports zero FDR-significant relationships at q0.10 in every family. Provisional feature retention is exploratory, not confirmed discovery. |
| QCCA-V1            | Can direct budget prediction recover retrospective headroom?                   | COMPLETED | QCCA-LogReg has F1 0.3034 and mean k2.03, below static k8 0.3950; high target-label agreement does not imply downstream quality.                                              |
| MODEL-BENCHMARK    | Do transition classifiers improve the quality/cost decision?                   | COMPLETED | Balanced logistic transition classification at threshold0.5 reaches recorded policy F1 0.3842; model-family/threshold tuning reuses DEV and is exploratory.                   |
| V2-MODELING        | Does sequential expansion avoid direct-classification collapse?                | COMPLETED | Unbalanced sequential logistic policy collapses to k2 (F1 0.3038). Balanced logistic reaches 0.3318; ridge reaches 0.3675, still below static k8.                             |
| V2-DIAGNOSTIC      | What do calibration and transition errors reveal about failures?               | COMPLETED | Stored balanced/ridge policy F1 values are 0.3318/0.3675; transition quality and policy quality are distinct quantities.                                                      |
| V2-FINAL           | Does the selected C1 transition policy retain quality while reducing context?  | COMPLETED | Final C1 F1 is 0.3842 at 1115.9 tokens, versus k6 0.385699 at1359.1 and k8 0.394995 at1758.5; paired F1 intervals versus all three static references cross zero.              |

## Key results

### feature family summary

| feature_family                  |   n_features |   max_abs_spearman_rho |   median_abs_spearman_rho |   mean_abs_spearman_rho |   n_features_fold_stable | strongest_feature           | strongest_target   |   strongest_rho |
|:--------------------------------|-------------:|-----------------------:|--------------------------:|------------------------:|-------------------------:|:----------------------------|:-------------------|----------------:|
| B: Query Complexity             |           12 |               0.188800 |                  0.054300 |                0.062000 |                        9 | query_conjunction_count     | oracle_k           |        0.188800 |
| A: BM25/Retrieval               |           17 |               0.174300 |                  0.049700 |                0.056500 |                       17 | bm25_mean_score             | G_4_to_6           |        0.174300 |
| E: Lexical Coverage             |            8 |               0.173500 |                  0.074800 |                0.075700 |                        8 | lex_coverage_top1           | oracle_k           |        0.173500 |
| C: Semantic Structure           |           11 |               0.172100 |                  0.066100 |                0.072100 |                       11 | sem_sim_mean_top6           | G_4_to_6           |        0.172100 |
| D: Passage Redundancy/Diversity |           10 |               0.156900 |                  0.036300 |                0.043400 |                       10 | passage_sim_std             | G_6_to_8           |        0.156900 |
| F: Evidence Structure           |            6 |               0.152200 |                  0.046500 |                0.052600 |                        6 | evidence_query_cluster_span | G_4_to_6           |        0.152200 |

Source: [results/week4/feature_discovery/feature_family_summary.csv](../repository/results/week4/feature_discovery/feature_family_summary.csv).

### feature family validation summary

| feature_family                  |   original_features |   fdr_sig_relationships_q10 |   bootstrap_ci_excludes_zero |   median_abs_rho |   max_abs_rho |   median_fold_stability | representative_features                                                                |
|:--------------------------------|--------------------:|----------------------------:|-----------------------------:|-----------------:|--------------:|------------------------:|:---------------------------------------------------------------------------------------|
| A: BM25/Retrieval               |                  17 |                           0 |                            6 |         0.049700 |      0.174300 |                0.800000 | bm25_mean_score, bm25_top1_score, bm25_first_gap_ratio                                 |
| B: Query Complexity             |                  12 |                           0 |                            6 |         0.054300 |      0.188800 |                0.600000 | query_conjunction_count, query_is_what_which, query_is_factoid                         |
| C: Semantic Structure           |                  11 |                           0 |                           10 |         0.066100 |      0.172100 |                0.600000 | sem_sim_mean_top6, sem_sim_top2, sem_sim_gap_12                                        |
| D: Passage Redundancy/Diversity |                  10 |                           0 |                            1 |         0.036300 |      0.156900 |                0.600000 | passage_sim_std, passage_sim_min, passage_sim_mean                                     |
| E: Lexical Coverage             |                   8 |                           0 |                            9 |         0.074800 |      0.173500 |                0.800000 | lex_coverage_top1, lex_coverage_top2, lex_coverage_gain_1_to_4                         |
| F: Evidence Structure           |                   6 |                           0 |                            1 |         0.046500 |      0.152200 |                0.600000 | evidence_query_cluster_span, evidence_lexical_overlap_mean, evidence_unique_word_count |

Source: [results/week4/feature_validation/feature_family_validation_summary.csv](../repository/results/week4/feature_validation/feature_family_validation_summary.csv).

### Retained exploratory features

| feature                  | family                          |   spearman_rho |   q_value_fdr |   bootstrap_ci_low |   bootstrap_ci_high |
|:-------------------------|:--------------------------------|---------------:|--------------:|-------------------:|--------------------:|
| query_conjunction_count  | B: Query Complexity             |       0.188800 |      0.410400 |           0.049400 |            0.329100 |
| query_is_what_which      | B: Query Complexity             |       0.175200 |      0.410400 |           0.041400 |            0.301300 |
| query_is_numerical       | B: Query Complexity             |      -0.123000 |      0.496400 |          -0.174300 |           -0.053500 |
| lex_coverage_top1        | E: Lexical Coverage             |       0.173500 |      0.410400 |           0.044400 |            0.316400 |
| lex_coverage_top2        | E: Lexical Coverage             |      -0.170100 |      0.410400 |          -0.300200 |           -0.040500 |
| lex_coverage_gain_1_to_4 | E: Lexical Coverage             |      -0.147900 |      0.455200 |          -0.256600 |           -0.018700 |
| sem_sim_mean_top6        | C: Semantic Structure           |       0.172100 |      0.410400 |           0.026300 |            0.319600 |
| sem_sim_top1             | C: Semantic Structure           |       0.135400 |      0.496400 |           0.001900 |            0.264900 |
| bm25_mean_score          | A: BM25/Retrieval               |       0.174300 |      0.410400 |           0.046000 |            0.295800 |
| bm25_first_gap_ratio     | A: BM25/Retrieval               |       0.147800 |      0.455200 |           0.011700 |            0.275700 |
| passage_sim_std          | D: Passage Redundancy/Diversity |       0.156900 |      0.455200 |           0.015400 |            0.283100 |
| passage_cluster_count    | D: Passage Redundancy/Diversity |       0.076600 |      0.710400 |          -0.053400 |            0.202500 |

Source: [results/week4/feature_validation/provisional_feature_set.csv](../repository/results/week4/feature_validation/provisional_feature_set.csv). First 12 of 14 rows shown; detailed report and source preserve the full comparison.

### model comparison

| system                  |   mean_f1 |   mean_k |   mean_context_tokens |   context_reduction_pct_vs_k8 |   mean_epsilon_regret |   mean_oracle_regret |   target_accuracy |   oracle_headroom_recovered_pct |
|:------------------------|----------:|---------:|----------------------:|------------------------------:|----------------------:|---------------------:|------------------:|--------------------------------:|
| Static k=5              |  0.362900 | 5.000000 |           1157.000000 |                     34.210000 |              0.126600 |             0.126600 |          0.073600 |                      -34.000000 |
| Static k=8              |  0.395000 | 8.000000 |           1758.500000 |                      0.000000 |              0.094500 |             0.094500 |          0.099600 |                        0.000000 |
| Best Static SARA (k=8)  |  0.395000 | 8.000000 |           1758.500000 |                      0.000000 |              0.094500 |             0.094500 |          0.099600 |                        0.000000 |
| Random Allocation       |  0.370900 | 4.900000 |           1131.000000 |                     35.680000 |              0.118500 |             0.118600 |          0.203500 |                      -25.450000 |
| QCCA-Rule               |  0.328600 | 3.560000 |            854.400000 |                     51.410000 |              0.160800 |             0.160900 |          0.324700 |                      -70.260000 |
| QCCA-LogReg             |  0.303400 | 2.030000 |            539.800000 |                     69.300000 |              0.186000 |             0.186200 |          0.567100 |                      -96.960000 |
| QCCA-Tree               |  0.328200 | 2.660000 |            671.000000 |                     61.840000 |              0.161200 |             0.161300 |          0.489200 |                      -70.700000 |
| Epsilon Oracle (ε=0.01) |  0.489400 | 3.490000 |            841.300000 |                     52.160000 |              0.000000 |             0.000100 |          1.000000 |                       99.880000 |
| Quality Oracle          |  0.489500 | 3.530000 |            848.400000 |                     51.750000 |              0.000000 |             0.000000 |          0.982700 |                      100.000000 |

Source: [results/week4/processed/model_comparison.csv](../repository/results/week4/processed/model_comparison.csv).

### policy comparison

| system                                                                |   mean_f1 |   mean_k |   mean_context_tokens |   context_reduction_pct_vs_k8 |   mean_regret | system_type             |
|:----------------------------------------------------------------------|----------:|---------:|----------------------:|------------------------------:|--------------:|:------------------------|
| Static SARA k=2                                                       |  0.303835 | 2.000000 |            534.500000 |                     69.600000 |      0.185672 | Static Baseline         |
| Static SARA k=4                                                       |  0.359601 | 4.000000 |            946.100000 |                     46.200000 |      0.129906 | Static Baseline         |
| Static SARA k=5                                                       |  0.362858 | 5.000000 |           1157.000000 |                     34.210000 |      0.126649 | Static Baseline         |
| Static SARA k=6                                                       |  0.385699 | 6.000000 |           1359.100000 |                     22.710000 |      0.103808 | Static Baseline         |
| Static SARA k=8                                                       |  0.394995 | 8.000000 |           1758.500000 |                      0.000000 |      0.094512 | Static Baseline         |
| Random Allocation                                                     |  0.370900 | 4.900000 |           1131.000000 |                     35.680000 |      0.118500 | Unlearned Baseline      |
| Oracle Sequential Ceiling                                             |  0.406900 | 2.560000 |            650.300000 |                     63.020000 |      0.082500 | Theoretical Bound       |
| Policy C1 [Balanced Logistic Regression (5 feats, Baseline)] (t=0.50) |  0.384200 | 4.820000 |           1115.900000 |                     36.540000 |      0.105300 | Learned Policy (t=0.50) |
| Policy C1 [Balanced Logistic Regression (2 feats: BM25+Lex)] (t=0.50) |  0.380000 | 4.830000 |           1117.700000 |                     36.440000 |      0.109500 | Learned Policy (t=0.50) |
| Policy C1 [Shallow Decision Tree (5 feats)] (t=0.50)                  |  0.367100 | 4.640000 |           1078.400000 |                     38.670000 |      0.122400 | Learned Policy (t=0.50) |
| Policy C1 [Random Forest (5 feats)] (t=0.50)                          |  0.371700 | 4.730000 |           1096.300000 |                     37.660000 |      0.117800 | Learned Policy (t=0.50) |
| Policy C1 [XGBoost (5 feats)] (t=0.50)                                |  0.372500 | 4.560000 |           1062.300000 |                     39.590000 |      0.117000 | Learned Policy (t=0.50) |

Source: [results/week4/model_benchmark/policy_comparison.csv](../repository/results/week4/model_benchmark/policy_comparison.csv). First 12 of 19 rows shown; detailed report and source preserve the full comparison.

### Stored bootstrap contrasts; interpret named metric/difference exactly

| candidate                                        | baseline                                         |   mean_delta_f1 |   ci_95_f1_low |   ci_95_f1_high | statistically_detectable_f1   |   mean_delta_tokens |   ci_95_tokens_low |   ci_95_tokens_high | statistically_detectable_tokens   |   mean_delta_regret |   ci_95_regret_low |   ci_95_regret_high |
|:-------------------------------------------------|:-------------------------------------------------|----------------:|---------------:|----------------:|:------------------------------|--------------------:|-------------------:|--------------------:|:----------------------------------|--------------------:|-------------------:|--------------------:|
| Balanced Logistic Regression (5 feats, Baseline) | Static SARA k=8                                  |       -0.011200 |      -0.044200 |        0.021200 | False                         |         -642.400000 |        -676.100000 |         -609.400000 | True                              |            0.011200 |          -0.021200 |            0.044200 |
| Balanced Logistic Regression (5 feats, Baseline) | Static SARA k=6                                  |       -0.001600 |      -0.022300 |        0.018200 | False                         |         -243.000000 |        -276.700000 |         -210.000000 | True                              |            0.001600 |          -0.018200 |            0.022300 |
| Balanced Logistic Regression (2 feats: BM25+Lex) | Balanced Logistic Regression (5 feats, Baseline) |       -0.004200 |      -0.017700 |        0.009100 | False                         |            1.900000 |         -16.300000 |           20.800000 | False                             |            0.004200 |          -0.009100 |            0.017700 |
| Balanced Logistic Regression (2 feats: BM25+Lex) | Static SARA k=8                                  |       -0.015400 |      -0.047000 |        0.015500 | False                         |         -640.600000 |        -672.100000 |         -608.500000 | True                              |            0.015400 |          -0.015500 |            0.047000 |
| Balanced Logistic Regression (2 feats: BM25+Lex) | Static SARA k=6                                  |       -0.005800 |      -0.027700 |        0.016400 | False                         |         -241.200000 |        -272.700000 |         -209.100000 | True                              |            0.005800 |          -0.016400 |            0.027700 |
| Shallow Decision Tree (5 feats)                  | Balanced Logistic Regression (5 feats, Baseline) |       -0.016800 |      -0.034800 |        0.000100 | False                         |          -37.600000 |         -66.500000 |           -9.300000 | True                              |            0.016800 |          -0.000100 |            0.034800 |
| Shallow Decision Tree (5 feats)                  | Static SARA k=8                                  |       -0.028000 |      -0.060200 |        0.003900 | False                         |         -680.000000 |        -706.800000 |         -653.800000 | True                              |            0.028000 |          -0.003900 |            0.060200 |
| Shallow Decision Tree (5 feats)                  | Static SARA k=6                                  |       -0.018400 |      -0.043700 |        0.007200 | False                         |         -280.600000 |        -307.400000 |         -254.400000 | True                              |            0.018400 |          -0.007200 |            0.043700 |
| Random Forest (5 feats)                          | Balanced Logistic Regression (5 feats, Baseline) |       -0.012400 |      -0.030000 |        0.003800 | False                         |          -19.300000 |         -42.600000 |            5.600000 | False                             |            0.012400 |          -0.003800 |            0.030000 |
| Random Forest (5 feats)                          | Static SARA k=8                                  |       -0.023600 |      -0.054600 |        0.007000 | False                         |         -661.800000 |        -691.900000 |         -630.900000 | True                              |            0.023600 |          -0.007000 |            0.054600 |
| Random Forest (5 feats)                          | Static SARA k=6                                  |       -0.014000 |      -0.041100 |        0.011600 | False                         |         -262.400000 |        -292.500000 |         -231.500000 | True                              |            0.014000 |          -0.011600 |            0.041100 |
| XGBoost (5 feats)                                | Balanced Logistic Regression (5 feats, Baseline) |       -0.011500 |      -0.031300 |        0.007700 | False                         |          -53.400000 |         -77.800000 |          -29.800000 | True                              |            0.011500 |          -0.007700 |            0.031300 |

Source: [results/week4/model_benchmark/bootstrap_comparison.csv](../repository/results/week4/model_benchmark/bootstrap_comparison.csv). First 12 of 35 rows shown; detailed report and source preserve the full comparison.

### qcca v2 policy summary

| policy                        |   mean_f1 |   mean_k |   mean_context_tokens |   context_reduction_pct_vs_k8 |   f1_per_1k_tokens |   mean_regret |   median_regret |     pct_k2 |    pct_k4 |    pct_k6 |    pct_k8 |   stage1_expansion_prec |   stage1_expansion_rec |   stage2_expansion_prec |   stage2_expansion_rec |   stage3_expansion_prec |   stage3_expansion_rec |
|:------------------------------|----------:|---------:|----------------------:|------------------------------:|-------------------:|--------------:|----------------:|-----------:|----------:|----------:|----------:|------------------------:|-----------------------:|------------------------:|-----------------------:|------------------------:|-----------------------:|
| QCCA-V2 (Logistic Regression) |  0.303800 | 2.000000 |            534.500000 |                     69.600000 |           0.568400 |      0.185600 |        0.000000 | 100.000000 |  0.000000 |  0.000000 |  0.000000 |                0.000000 |               0.000000 |                0.000000 |               0.000000 |                0.000000 |               0.000000 |
| QCCA-V2 (Balanced LogReg)     |  0.331800 | 3.500000 |            842.600000 |                     52.080000 |           0.393700 |      0.157700 |        0.000000 |  55.000000 | 19.000000 | 22.100000 |  3.900000 |                0.201900 |               0.381800 |                0.316700 |               0.791700 |                0.222200 |               0.200000 |
| QCCA-V2 (Decision Tree d=2)   |  0.306700 | 2.080000 |            550.500000 |                     68.690000 |           0.557100 |      0.182700 |        0.000000 |  96.500000 |  3.000000 |  0.400000 |  0.000000 |                0.125000 |               0.018200 |                0.000000 |               0.000000 |                0.000000 |               0.000000 |
| QCCA-V2 (Ridge Regression)    |  0.367500 | 5.450000 |           1241.600000 |                     29.390000 |           0.296000 |      0.122000 |        0.000000 |  12.600000 | 26.400000 | 37.200000 | 23.800000 |                0.232700 |               0.854500 |                0.205700 |               0.725000 |                0.109100 |               0.333300 |

Source: [results/week4/qcca_v2/qcca_v2_policy_summary.csv](../repository/results/week4/qcca_v2/qcca_v2_policy_summary.csv).

## Main scientific conclusions

- All feature-family maximum absolute Spearman correlations are below 0.19; observed individual associations are weak. Source: [results/week4/feature_discovery/feature_family_summary.csv](../repository/results/week4/feature_discovery/feature_family_summary.csv)
- The six-family validation summary reports zero FDR-significant relationships at q0.10 in every family. Provisional feature retention is exploratory, not confirmed discovery. Source: [results/week4/feature_validation/feature_family_validation_summary.csv](../repository/results/week4/feature_validation/feature_family_validation_summary.csv)
- QCCA-LogReg has F1 0.3034 and mean k2.03, below static k8 0.3950; high target-label agreement does not imply downstream quality. Source: [results/week4/processed/model_comparison.csv](../repository/results/week4/processed/model_comparison.csv)
- Balanced logistic transition classification at threshold0.5 reaches recorded policy F1 0.3842; model-family/threshold tuning reuses DEV and is exploratory. Source: [results/week4/model_benchmark/policy_comparison.csv](../repository/results/week4/model_benchmark/policy_comparison.csv)
- Unbalanced sequential logistic policy collapses to k2 (F1 0.3038). Balanced logistic reaches 0.3318; ridge reaches 0.3675, still below static k8. Source: [results/week4/qcca_v2/qcca_v2_policy_summary.csv](../repository/results/week4/qcca_v2/qcca_v2_policy_summary.csv)
- Stored balanced/ridge policy F1 values are 0.3318/0.3675; transition quality and policy quality are distinct quantities. Source: [results/week4/qcca_v2_diagnostic/transition_model_comparison.csv](../repository/results/week4/qcca_v2_diagnostic/transition_model_comparison.csv)
- Final C1 F1 is 0.3842 at 1115.9 tokens, versus k6 0.385699 at1359.1 and k8 0.394995 at1758.5; paired F1 intervals versus all three static references cross zero. Source: [results/week4/qcca_v2_final_validation/policy_pareto_points.csv](../repository/results/week4/qcca_v2_final_validation/policy_pareto_points.csv)

## What did NOT work?

Several learned policies underperform static k8; no feature relationships survive family-reported q0.10 FDR; final F1 intervals cross zero.

## Limitations

OOF predictions do not erase exploratory feature/model/threshold selection on the same DEV cohort.

## Decision after this week

Final validation table identifies C1; no superiority claim follows. Later Week5 tests content representations and target formulations.

## One-paragraph week takeaway

All feature-family maximum absolute Spearman correlations are below 0.19; observed individual associations are weak. The six-family validation summary reports zero FDR-significant relationships at q0.10 in every family. Provisional feature retention is exploratory, not confirmed discovery. QCCA-LogReg has F1 0.3034 and mean k2.03, below static k8 0.3950; high target-label agreement does not imply downstream quality. Balanced logistic transition classification at threshold0.5 reaches recorded policy F1 0.3842; model-family/threshold tuning reuses DEV and is exploratory. Unbalanced sequential logistic policy collapses to k2 (F1 0.3038). Balanced logistic reaches 0.3318; ridge reaches 0.3675, still below static k8. Stored balanced/ridge policy F1 values are 0.3318/0.3675; transition quality and policy quality are distinct quantities. Final C1 F1 is 0.3842 at 1115.9 tokens, versus k6 0.385699 at1359.1 and k8 0.394995 at1758.5; paired F1 intervals versus all three static references cross zero.

# Primary Sources Used

- [configs/week4/week4_config.yaml](../repository/configs/week4/week4_config.yaml)
- notebooks/week4/week4_feature_discovery.ipynb (`../../../notebooks/week4/week4_feature_discovery.ipynb`; source dependency not packaged)
- notebooks/week4/week4_feature_validation.ipynb (`../../../notebooks/week4/week4_feature_validation.ipynb`; source dependency not packaged)
- notebooks/week4/week4_model_benchmark.ipynb (`../../../notebooks/week4/week4_model_benchmark.ipynb`; source dependency not packaged)
- notebooks/week4/week4_qcca_development.ipynb (`../../../notebooks/week4/week4_qcca_development.ipynb`; source dependency not packaged)
- notebooks/week4/week4_qcca_v2_diagnostic.ipynb (`../../../notebooks/week4/week4_qcca_v2_diagnostic.ipynb`; source dependency not packaged)
- notebooks/week4/week4_qcca_v2_final_validation.ipynb (`../../../notebooks/week4/week4_qcca_v2_final_validation.ipynb`; source dependency not packaged)
- notebooks/week4/week4_qcca_v2_modeling.ipynb (`../../../notebooks/week4/week4_qcca_v2_modeling.ipynb`; source dependency not packaged)
- [results/week4/feature_discovery/feature_family_summary.csv](../repository/results/week4/feature_discovery/feature_family_summary.csv)
- [results/week4/feature_validation/feature_family_validation_summary.csv](../repository/results/week4/feature_validation/feature_family_validation_summary.csv)
- [results/week4/feature_validation/provisional_feature_set.csv](../repository/results/week4/feature_validation/provisional_feature_set.csv)
- [results/week4/model_benchmark/bootstrap_comparison.csv](../repository/results/week4/model_benchmark/bootstrap_comparison.csv)
- [results/week4/model_benchmark/policy_comparison.csv](../repository/results/week4/model_benchmark/policy_comparison.csv)
- [results/week4/processed/model_comparison.csv](../repository/results/week4/processed/model_comparison.csv)
- [results/week4/qcca_v2/bootstrap_policy_comparison.csv](../repository/results/week4/qcca_v2/bootstrap_policy_comparison.csv)
- [results/week4/qcca_v2/qcca_v2_policy_summary.csv](../repository/results/week4/qcca_v2/qcca_v2_policy_summary.csv)
- [results/week4/qcca_v2_diagnostic/figures/policy_pareto_frontier.png](../repository/results/week4/qcca_v2_diagnostic/figures/policy_pareto_frontier.png)
- [results/week4/qcca_v2_diagnostic/transition_model_comparison.csv](../repository/results/week4/qcca_v2_diagnostic/transition_model_comparison.csv)
- [results/week4/qcca_v2_final_validation/policy_pareto_points.csv](../repository/results/week4/qcca_v2_final_validation/policy_pareto_points.csv)
- [results/week4/qcca_v2_final_validation/statistical_comparisons.csv](../repository/results/week4/qcca_v2_final_validation/statistical_comparisons.csv)

# Existing Markdown Used as Evidence

NONE


---

## Week 5

Source: [results/weekly_reports/week_05/WeeklySummaryAnalysis.md](../repository/results/weekly_reports/week_05/WeeklySummaryAnalysis.md)

# Week 5 — Summary Analysis

## Objective

Use TRAIN response supervision and content-aware encoders to learn cost-aware SARA budget allocation.

## Experiments performed

| Part          | Question                                                                                    | Status    | Main_result                                                                                                                                                                   |
|:--------------|:--------------------------------------------------------------------------------------------|:----------|:------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| TRAIN-SURFACE | Can allocation labels be generated from TRAIN responses rather than fitting only DEV?       | COMPLETED | TRAIN fixed-k and supervision artifacts exist separately from DEV; the exact cohort/target distributions are retained in the tables.                                          |
| A             | Do passage semantics improve allocation over query-only/handcrafted inputs?                 | COMPLETED | Most regret-model configurations return k8. I2-T2 reaches F1 0.3952 versus static0.3950 with only1.72% stored token reduction; this is not a strong adaptive breakthrough.    |
| B             | Can predicting an admissible action set avoid direct-label ambiguity and fallback collapse? | COMPLETED | Completed seed-level and aggregate T3 outputs exist. The table reports fallback rates alongside F1; oracle quality/cost entries are retrospective references.                 |
| C             | Does unfreezing MiniLM layers improve content-aware allocation?                             | COMPLETED | C0 mean F1 0.381033 exceeds last1-layer0.3620 and last2-layer0.3743 point estimates. Encoder adaptation does not show a robust improvement over frozen features or static k8. |

## Key results

### train static performance

|        k |   mean_token_f1 |   std_token_f1 |   mean_context_tokens |   std_context_tokens |
|---------:|----------------:|---------------:|----------------------:|---------------------:|
| 2.000000 |        0.326400 |       0.395800 |            535.200000 |            95.500000 |
| 4.000000 |        0.378400 |       0.406600 |            956.400000 |           138.400000 |
| 5.000000 |        0.396500 |       0.407800 |           1166.200000 |           159.700000 |
| 6.000000 |        0.406000 |       0.410500 |           1373.700000 |           179.800000 |
| 8.000000 |        0.425400 |       0.413400 |           1787.400000 |           224.600000 |

Source: [results/week5/tables/train_static_performance.csv](../repository/results/week5/tables/train_static_performance.csv).

### dev vs train target distribution

|        k |   train_count |   train_pct |   dev_count |   dev_pct |   shift_delta_pct |
|---------:|--------------:|------------:|------------:|----------:|------------------:|
| 2.000000 |   1234.000000 |   59.100000 |  132.000000 | 57.140000 |          1.960000 |
| 4.000000 |    354.000000 |   16.950000 |   40.000000 | 17.320000 |         -0.360000 |
| 5.000000 |    163.000000 |    7.810000 |   17.000000 |  7.360000 |          0.450000 |
| 6.000000 |    134.000000 |    6.420000 |   19.000000 |  8.230000 |         -1.810000 |
| 8.000000 |    203.000000 |    9.720000 |   23.000000 |  9.960000 |         -0.230000 |

Source: [results/week5/tables/dev_vs_train_target_distribution.csv](../repository/results/week5/tables/dev_vs_train_target_distribution.csv).

### main results

| model_name                          | condition                     | target          |   mean_answer_f1 |   mean_selected_k |   mean_context_tokens |   token_reduction_pct_vs_k8 |   mean_oracle_regret |   recovered_oracle_headroom |   zero_regret_pct |
|:------------------------------------|:------------------------------|:----------------|-----------------:|------------------:|----------------------:|----------------------------:|---------------------:|----------------------------:|------------------:|
| Static k=2                          | Static Baseline               | nan             |         0.303800 |          2.000000 |            526.500000 |                   69.920000 |             0.185700 |                   -0.964700 |         57.140000 |
| Static k=4                          | Static Baseline               | nan             |         0.359600 |          4.000000 |            938.100000 |                   46.410000 |             0.129900 |                   -0.374600 |         64.940000 |
| Static k=5                          | Static Baseline               | nan             |         0.362900 |          5.000000 |           1149.000000 |                   34.360000 |             0.126600 |                   -0.340100 |         65.370000 |
| Static k=6                          | Static Baseline               | nan             |         0.385700 |          6.000000 |           1351.100000 |                   22.820000 |             0.103800 |                   -0.098400 |         67.100000 |
| Static k=8                          | Static Baseline               | nan             |         0.395000 |          8.000000 |           1750.500000 |                    0.000000 |             0.094500 |                   -0.000100 |         71.000000 |
| W4 Best Allocator (Balanced LogReg) | Handcrafted Features Only     | Classification  |         0.384200 |          4.820000 |           1115.900000 |                   36.250000 |             0.105300 |                   -0.114300 |         52.380000 |
| Quality Oracle (Upper Bound)        | Theoretical Upper Bound       | Oracle max F1   |         0.489500 |          3.530000 |            846.100000 |                   51.670000 |             0.000000 |                    1.000000 |        100.000000 |
| Cost-Aware Oracle (eps=0.01)        | Theoretical Cost-Aware Target | Oracle eps=0.01 |         0.489400 |          3.490000 |            839.400000 |                   52.050000 |             0.000100 |                    0.998800 |        100.000000 |
| I1-T1                               | I1                            | T1              |         0.370900 |          4.690000 |           1076.100000 |                   38.530000 |             0.118600 |                   -0.255000 |        nan        |
| I1-T2                               | I1                            | T2              |         0.395000 |          8.000000 |           1750.500000 |                    0.000000 |             0.094500 |                   -0.000100 |        nan        |
| I2-T1                               | I2                            | T1              |         0.369300 |          5.130000 |           1173.000000 |                   32.990000 |             0.120200 |                   -0.272400 |        nan        |
| I2-T2                               | I2                            | T2              |         0.395200 |          7.850000 |           1720.400000 |                    1.720000 |             0.094300 |                    0.002400 |        nan        |

Source: [results/week5/content_allocator/tables/main_results.csv](../repository/results/week5/content_allocator/tables/main_results.csv). First 12 of 16 rows shown; detailed report and source preserve the full comparison.

### Stored bootstrap contrasts; interpret named metric/difference exactly

| Model   | Comparison    |   observed_delta_f1 |   ci_lower_95 |   ci_upper_95 |   p_value |   n_bootstrap |
|:--------|:--------------|--------------------:|--------------:|--------------:|----------:|--------------:|
| I1-T1   | vs Static k=8 |           -0.017500 |     -0.049100 |      0.013500 |  0.131000 |          2000 |
| I1-T2   | vs Static k=8 |            0.000000 |      0.000000 |      0.000000 |  1.000000 |          2000 |
| I2-T1   | vs Static k=8 |           -0.021900 |     -0.055000 |      0.010700 |  0.085000 |          2000 |
| I2-T2   | vs Static k=8 |            0.000700 |     -0.018700 |      0.019000 |  0.477000 |          2000 |
| I3-T1   | vs Static k=8 |            0.000000 |      0.000000 |      0.000000 |  1.000000 |          2000 |
| I3-T2   | vs Static k=8 |            0.000000 |      0.000000 |      0.000000 |  1.000000 |          2000 |
| I4-T1   | vs Static k=8 |           -0.032500 |     -0.063800 |     -0.002500 |  0.021000 |          2000 |
| I4-T2   | vs Static k=8 |            0.000000 |      0.000000 |      0.000000 |  1.000000 |          2000 |

Source: [results/week5/content_allocator/bootstrap/paper_clustered_bootstrap_results.csv](../repository/results/week5/content_allocator/bootstrap/paper_clustered_bootstrap_results.csv).

## Main scientific conclusions

- TRAIN fixed-k and supervision artifacts exist separately from DEV; the exact cohort/target distributions are retained in the tables. Source: [results/week5/tables/train_static_performance.csv](../repository/results/week5/tables/train_static_performance.csv), [results/week5/preflight/split_audit.json](../repository/results/week5/preflight/split_audit.json)
- Most regret-model configurations return k8. I2-T2 reaches F1 0.3952 versus static0.3950 with only1.72% stored token reduction; this is not a strong adaptive breakthrough. Source: [results/week5/content_allocator/tables/main_results.csv](../repository/results/week5/content_allocator/tables/main_results.csv)
- Completed seed-level and aggregate T3 outputs exist. The table reports fallback rates alongside F1; oracle quality/cost entries are retrospective references. Source: [results/week5/content_allocator/w5b/tables/w5b_main_results.csv](../repository/results/week5/content_allocator/w5b/tables/w5b_main_results.csv)
- C0 mean F1 0.381033 exceeds last1-layer0.3620 and last2-layer0.3743 point estimates. Encoder adaptation does not show a robust improvement over frozen features or static k8. Source: [results/week5/content_allocator/w5c_encoder_adaptation/tables/w5c_main_results.csv](../repository/results/week5/content_allocator/w5c_encoder_adaptation/tables/w5c_main_results.csv)

## What did NOT work?

Fallback-to-k8, weak content gains and worse adapted-encoder point estimates remain visible.

## Limitations

Historical DEV reuse, seed variability, target definitions and inconsistent token-accounting constants.

## Decision after this week

No universal content-aware allocator superiority established; frozen semantic information motivates passage-routing tests.

## One-paragraph week takeaway

TRAIN fixed-k and supervision artifacts exist separately from DEV; the exact cohort/target distributions are retained in the tables. Most regret-model configurations return k8. I2-T2 reaches F1 0.3952 versus static0.3950 with only1.72% stored token reduction; this is not a strong adaptive breakthrough. Completed seed-level and aggregate T3 outputs exist. The table reports fallback rates alongside F1; oracle quality/cost entries are retrospective references. C0 mean F1 0.381033 exceeds last1-layer0.3620 and last2-layer0.3743 point estimates. Encoder adaptation does not show a robust improvement over frozen features or static k8.

## Additional primary visualizations

![Recorded experimental figure](../repository/results/week5/content_allocator/figures/pareto_quality_vs_tokens.png)

X-axis is recorded context-token cost; y-axis answer F1. Learned-policy, static and oracle references share the plot; oracle points are retrospective and token-reference conflicts prevent cross-week cost claims.

Source: [results/week5/content_allocator/figures/pareto_quality_vs_tokens.png](../repository/results/week5/content_allocator/figures/pareto_quality_vs_tokens.png).

# Primary Sources Used

- [configs/week5/content_allocator.yaml](../repository/configs/week5/content_allocator.yaml)
- [configs/week5/train_response_surface.yaml](../repository/configs/week5/train_response_surface.yaml)
- [configs/week5/w5c_encoder_adaptation.yaml](../repository/configs/week5/w5c_encoder_adaptation.yaml)
- notebooks/week5/week5_content_aware_allocator.ipynb (`../../../notebooks/week5/week5_content_aware_allocator.ipynb`; source dependency not packaged)
- notebooks/week5/week5c_encoder_adaptation.ipynb (`../../../notebooks/week5/week5c_encoder_adaptation.ipynb`; source dependency not packaged)
- [results/week5/content_allocator/bootstrap/paper_clustered_bootstrap_results.csv](../repository/results/week5/content_allocator/bootstrap/paper_clustered_bootstrap_results.csv)
- [results/week5/content_allocator/tables/main_results.csv](../repository/results/week5/content_allocator/tables/main_results.csv)
- [results/week5/content_allocator/w5b/bootstrap/w5b_bootstrap_comparisons.csv](../repository/results/week5/content_allocator/w5b/bootstrap/w5b_bootstrap_comparisons.csv)
- [results/week5/content_allocator/w5b/tables/w5b_main_results.csv](../repository/results/week5/content_allocator/w5b/tables/w5b_main_results.csv)
- [results/week5/content_allocator/w5b/tables/w5b_seed_results.csv](../repository/results/week5/content_allocator/w5b/tables/w5b_seed_results.csv)
- [results/week5/content_allocator/w5c_encoder_adaptation/bootstrap/w5c_bootstrap_comparisons.csv](../repository/results/week5/content_allocator/w5c_encoder_adaptation/bootstrap/w5c_bootstrap_comparisons.csv)
- [results/week5/content_allocator/w5c_encoder_adaptation/tables/w5c_main_results.csv](../repository/results/week5/content_allocator/w5c_encoder_adaptation/tables/w5c_main_results.csv)
- [results/week5/preflight/split_audit.json](../repository/results/week5/preflight/split_audit.json)
- [results/week5/tables/dev_vs_train_target_distribution.csv](../repository/results/week5/tables/dev_vs_train_target_distribution.csv)
- [results/week5/tables/train_static_performance.csv](../repository/results/week5/tables/train_static_performance.csv)
- src/week5/evaluation.py (`../../../src/week5/evaluation.py`; source dependency not packaged)
- src/week5/supervision.py (`../../../src/week5/supervision.py`; source dependency not packaged)

- [results/week5/content_allocator/figures/pareto_quality_vs_tokens.png](../repository/results/week5/content_allocator/figures/pareto_quality_vs_tokens.png)

# Existing Markdown Used as Evidence

NONE


---

## Week 6

Source: [results/weekly_reports/week_06/WeeklySummaryAnalysis.md](../repository/results/weekly_reports/week_06/WeeklySummaryAnalysis.md)

# Week 6 — Summary Analysis

## Objective

Separate passage identity from representation budget: fix k and compare routing strategies within the same candidate pool.

## Experiments performed

| Part   | Question                                                                           | Status    | Main_result                                                                                                                                                                                    |
|:-------|:-----------------------------------------------------------------------------------|:----------|:-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| A      | Does choosing WHICH retrieved passages remain verbatim improve SARA at the same k? | COMPLETED | At k4, semantic routing reaches0.391333 versus BM25-prefix0.359601 and learned routing0.357210. At k6, semantic0.395345 versus BM250.385699. This tests routing inside a fixed retrieved pool. |
| B      | Does score fusion improve on pure semantic routing?                                | COMPLETED | RRF is best at k2 by point estimate0.325764, but semantic routing remains stronger at k4/k6 than fixed fusion or RRF. No universal hybrid routing gain is established.                         |

## Key results

### w6 main results

| router            |   k |   answer_f1_mean |   answer_f1_std |   context_tokens_mean |   latency_mean_sec |
|:------------------|----:|-----------------:|----------------:|----------------------:|-------------------:|
| R0_bm25_prefix    |   2 |         0.303835 |        0.379664 |            526.523810 |           0.000000 |
| R0_bm25_prefix    |   4 |         0.359601 |        0.393989 |            938.121212 |           0.000000 |
| R0_bm25_prefix    |   6 |         0.385699 |        0.390981 |           1351.116883 |           0.000000 |
| R1_semantic_topk  |   2 |         0.312678 |        0.381688 |            509.636364 |           1.836474 |
| R1_semantic_topk  |   4 |         0.391333 |        0.400429 |            921.073593 |           2.684737 |
| R1_semantic_topk  |   6 |         0.395345 |        0.393080 |           1325.090909 |           3.629630 |
| R2_learned_router |   2 |         0.298276 |        0.374743 |            565.398268 |           1.812983 |
| R2_learned_router |   4 |         0.357210 |        0.390746 |            994.714286 |           2.834549 |
| R2_learned_router |   6 |         0.369367 |        0.392932 |           1422.225108 |           3.909536 |

Source: [results/week6/passage_routing/tables/w6_main_results.csv](../repository/results/week6/passage_routing/tables/w6_main_results.csv).

### w6 routing quality

| router            |   k |   evidence_recall |   evidence_precision |   total_queries |
|:------------------|----:|------------------:|---------------------:|----------------:|
| R0_bm25_prefix    |   2 |          0.392558 |             0.331169 |             231 |
| R0_bm25_prefix    |   4 |          0.615892 |             0.316017 |             231 |
| R0_bm25_prefix    |   6 |          0.791517 |             0.293651 |             231 |
| R1_semantic_topk  |   2 |          0.420913 |             0.333333 |             231 |
| R1_semantic_topk  |   4 |          0.613387 |             0.312771 |             231 |
| R1_semantic_topk  |   6 |          0.771193 |             0.289322 |             231 |
| R2_learned_router |   2 |          0.406514 |             0.352814 |             231 |
| R2_learned_router |   4 |          0.648626 |             0.331169 |             231 |
| R2_learned_router |   6 |          0.800984 |             0.302309 |             231 |

Source: [results/week6/passage_routing/tables/w6_routing_quality.csv](../repository/results/week6/passage_routing/tables/w6_routing_quality.csv).

## Main scientific conclusions

- At k4, semantic routing reaches0.391333 versus BM25-prefix0.359601 and learned routing0.357210. At k6, semantic0.395345 versus BM250.385699. This tests routing inside a fixed retrieved pool. Source: [results/week6/passage_routing/tables/w6_main_results.csv](../repository/results/week6/passage_routing/tables/w6_main_results.csv)
- RRF is best at k2 by point estimate0.325764, but semantic routing remains stronger at k4/k6 than fixed fusion or RRF. No universal hybrid routing gain is established. Source: [results/week6/hybrid_routing/tables/w6b_main_results.csv](../repository/results/week6/hybrid_routing/tables/w6b_main_results.csv)

## What did NOT work?

Learned routing underperforms simple semantic routing; fusion is not consistently best.

## Limitations

Same local DEV, semantic encoder limitations and cached/uncached latency asymmetry.

## Decision after this week

Carry simple semantic routing into budget/routing composition experiments.

## One-paragraph week takeaway

At k4, semantic routing reaches0.391333 versus BM25-prefix0.359601 and learned routing0.357210. At k6, semantic0.395345 versus BM250.385699. This tests routing inside a fixed retrieved pool. RRF is best at k2 by point estimate0.325764, but semantic routing remains stronger at k4/k6 than fixed fusion or RRF. No universal hybrid routing gain is established.

## Additional primary visualizations

![Recorded experimental figure](../repository/results/week6/passage_routing/figures/w6_quality_vs_budget.png)

X-axis is high-fidelity passage budget k; y-axis answer F1 by routing method. Semantic routing is strong at k4/k6; this does not prove a universal retriever winner.

Source: [results/week6/passage_routing/figures/w6_quality_vs_budget.png](../repository/results/week6/passage_routing/figures/w6_quality_vs_budget.png).

# Primary Sources Used

- [configs/week6/hybrid_routing.yaml](../repository/configs/week6/hybrid_routing.yaml)
- [configs/week6/passage_routing.yaml](../repository/configs/week6/passage_routing.yaml)
- notebooks/week6/week6_passage_fidelity_routing.ipynb (`../../../notebooks/week6/week6_passage_fidelity_routing.ipynb`; source dependency not packaged)
- notebooks/week6/week6b_hybrid_routing.ipynb (`../../../notebooks/week6/week6b_hybrid_routing.ipynb`; source dependency not packaged)
- [results/week6/hybrid_routing/bootstrap/w6b_bootstrap_comparisons.csv](../repository/results/week6/hybrid_routing/bootstrap/w6b_bootstrap_comparisons.csv)
- [results/week6/hybrid_routing/tables/w6b_main_results.csv](../repository/results/week6/hybrid_routing/tables/w6b_main_results.csv)
- [results/week6/passage_routing/bootstrap/w6_bootstrap_comparisons.csv](../repository/results/week6/passage_routing/bootstrap/w6_bootstrap_comparisons.csv)
- results/week6/passage_routing/sara_generations/dev_sara_generations.jsonl (`../../week6/passage_routing/sara_generations/dev_sara_generations.jsonl`; source dependency not packaged)
- [results/week6/passage_routing/tables/w6_main_results.csv](../repository/results/week6/passage_routing/tables/w6_main_results.csv)
- [results/week6/passage_routing/tables/w6_routing_quality.csv](../repository/results/week6/passage_routing/tables/w6_routing_quality.csv)

- [results/week6/passage_routing/figures/w6_quality_vs_budget.png](../repository/results/week6/passage_routing/figures/w6_quality_vs_budget.png)

# Existing Markdown Used as Evidence

NONE


---

## Week 7

Source: [results/weekly_reports/week_07/WeeklySummaryAnalysis.md](../repository/results/weekly_reports/week_07/WeeklySummaryAnalysis.md)

# Week 7 — Summary Analysis

## Objective

Test whether semantic routing plus adaptive budget decisions or medium-fidelity representations can improve static semantic context policies.

## Experiments performed

| Part   | Question                                                                  | Status    | Main_result                                                                                                                                                                                |
|:-------|:--------------------------------------------------------------------------|:----------|:-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| A      | Can the old W4 allocator benefit from semantic routing?                   | COMPLETED | Old allocator + semantic routing F1 is0.378150, below the same allocator with BM250.384172 and static semantic k40.391333.                                                                 |
| B      | Can retraining on a semantic response surface improve allocation?         | COMPLETED | New semantic-aware allocator F1 is0.3522 versus semantic k40.3909 and k80.4010; its retrospective epsilon oracle0.4869 is not deployable.                                                  |
| C      | Do richer routing-aware features identify the smallest sufficient budget? | COMPLETED | Selected sufficiency allocator F1 is0.378323 at mean k6.8485, below static semantic k40.390929.                                                                                            |
| C2     | Does direct utility regression/ranking improve the quality/cost tradeoff? | COMPLETED | Selected utility-ranking model F1 is0.392233 at mean k7.3853 and1622.10 tokens, below static k80.401041.                                                                                   |
| C3     | Can safe down/up shifts around semantic k4 improve the anchor?            | COMPLETED | Anchor-and-deviate F1 is0.380107 at903.10 tokens versus anchor k40.390929 at921.06 tokens; limited savings come with lower point quality.                                                  |
| D      | Do stronger learned representations make safer allocation changes?        | COMPLETED | Hierarchical frozen/unfrozen DEV policies collapse to static k4 (F10.390929); listwise7B LoRA reaches0.387714. Internal-VAL table values are different cohorts, not competing DEV scores.  |
| E      | Does adding medium extractive evidence recover k6 quality cheaply?        | COMPLETED | Repaired hybrid E1-H F10.3861 exceeds corrected extract-only0.3755, but trails static k40.3909 while using more tokens. Medium representation does not establish net quality/cost benefit. |

## Key results

### w7a main results

| policy                | routing               |   mean_k |   answer_f1_mean |   answer_f1_std |   context_tokens_mean |   latency_mean_sec |
|:----------------------|:----------------------|---------:|-----------------:|----------------:|----------------------:|-------------------:|
| Static k=2            | BM25 Prefix           | 2.000000 |         0.303835 |        0.379664 |            526.523810 |           0.000000 |
| Static k=4            | BM25 Prefix           | 4.000000 |         0.359601 |        0.393989 |            938.121212 |           0.000000 |
| Static k=6            | BM25 Prefix           | 6.000000 |         0.385699 |        0.390981 |           1351.116883 |           0.000000 |
| Static k=8            | BM25 Prefix           | 8.000000 |         0.395000 |        0.392000 |           1750.500000 |           4.800000 |
| Static k=2            | Semantic Top-k        | 2.000000 |         0.312678 |        0.381688 |            509.636364 |           1.836474 |
| Static k=4            | Semantic Top-k        | 4.000000 |         0.391333 |        0.400429 |            921.073593 |           2.684737 |
| Static k=6            | Semantic Top-k        | 6.000000 |         0.395345 |        0.393080 |           1325.090909 |           3.629630 |
| W4 Adaptive Allocator | BM25 Prefix           | 4.822511 |         0.384172 |        0.389792 |           1114.229437 |           3.065000 |
| W4 Adaptive Allocator | Semantic Top-k (W7-A) | 4.822511 |         0.378150 |        0.395410 |           1095.030303 |           3.094185 |

Source: [results/week7/w7a_budget_semantic_composition/tables/w7a_main_results.csv](../repository/results/week7/w7a_budget_semantic_composition/tables/w7a_main_results.csv).

### Stored bootstrap contrasts; interpret named metric/difference exactly

| comparison             | policy_A    | policy_B   |   delta_f1 |   f1_ci_lower |   f1_ci_upper |   p_value | significant   |   delta_tokens |   tokens_ci_lower |   tokens_ci_upper |
|:-----------------------|:------------|:-----------|-----------:|--------------:|--------------:|----------:|:--------------|---------------:|------------------:|------------------:|
| W4+Semantic_vs_W4+BM25 | W4+Semantic | W4+BM25    |  -0.006022 |     -0.049531 |      0.037156 |  0.814000 | False         |     -19.199134 |        -38.426170 |         -0.282759 |

Source: [results/week7/w7a_budget_semantic_composition/bootstrap/w7a_bootstrap_comparisons.csv](../repository/results/week7/w7a_budget_semantic_composition/bootstrap/w7a_bootstrap_comparisons.csv).

### w7b main dev results

| policy                                | routing                 |   mean_k |   answer_f1_mean |   answer_f1_std |   context_tokens_mean |   token_reduction_pct_vs_k8 |   f1_per_1k_tokens |
|:--------------------------------------|:------------------------|---------:|-----------------:|----------------:|----------------------:|----------------------------:|-------------------:|
| Static semantic k=2                   | Semantic Top-k          | 2.000000 |         0.311800 |        0.383300 |            509.600000 |                   70.670000 |           0.611900 |
| Static semantic k=4                   | Semantic Top-k          | 4.000000 |         0.390900 |        0.402000 |            921.100000 |                   46.990000 |           0.424400 |
| Static semantic k=5                   | Semantic Top-k          | 5.000000 |         0.393100 |        0.397700 |           1123.000000 |                   35.370000 |           0.350100 |
| Static semantic k=6                   | Semantic Top-k          | 6.000000 |         0.395700 |        0.394700 |           1325.100000 |                   23.730000 |           0.298600 |
| Static semantic k=8                   | Semantic Top-k          | 8.000000 |         0.401000 |        0.396300 |           1737.400000 |                    0.000000 |           0.230800 |
| W4 old allocator + semantic routing   | Semantic Top-k (W7-A)   | 4.820000 |         0.378200 |        0.395400 |           1095.000000 |                   36.980000 |           0.345400 |
| NEW semantic-aware adaptive allocator | Semantic Top-k (W7-B)   | 3.480000 |         0.352200 |        0.393200 |            815.400000 |                   53.070000 |           0.432000 |
| Semantic epsilon-oracle (eps=0.01)    | Semantic Top-k (Oracle) | 3.300000 |         0.486900 |        0.392300 |            775.200000 |                   55.380000 |           0.628200 |

Source: [results/week7/w7b_semantic_budget/tables/w7b_main_dev_results.csv](../repository/results/week7/w7b_semantic_budget/tables/w7b_main_dev_results.csv).

### Stored bootstrap contrasts; interpret named metric/difference exactly

| comparison                            |   delta_f1 | ci_95_f1           |   p_value | significant_at_05   |   delta_tokens | ci_95_tokens      |
|:--------------------------------------|-----------:|:-------------------|----------:|:--------------------|---------------:|:------------------|
| W7B_Adaptive_vs_W7A_Composite         |  -0.026000 | [-0.0802, +0.0303] |  0.320000 | False               |    -279.600000 | [-340.4, -223.2]  |
| W7B_Adaptive_vs_Static_Semantic_k4    |  -0.038700 | [-0.0751, -0.0077] |  0.007000 | True                |    -105.700000 | [-157.1, -57.8]   |
| W7B_Adaptive_vs_Static_Semantic_k6    |  -0.043500 | [-0.0873, -0.0038] |  0.034000 | True                |    -509.700000 | [-559.5, -462.3]  |
| W7B_Adaptive_vs_Static_Semantic_k8    |  -0.048800 | [-0.0906, -0.0091] |  0.017000 | True                |    -922.000000 | [-972.8, -870.5]  |
| Semantic_Oracle_vs_Static_Semantic_k8 |   0.085900 | [+0.0610, +0.1142] |  0.000500 | True                |    -962.200000 | [-1015.7, -902.2] |

Source: [results/week7/w7b_semantic_budget/bootstrap/w7b_bootstrap_comparisons.csv](../repository/results/week7/w7b_semantic_budget/bootstrap/w7b_bootstrap_comparisons.csv).

### w7c main dev results

| method                                                  |   mean_k |   mean_f1 |      tokens | notes                      |   ROH_sem |
|:--------------------------------------------------------|---------:|----------:|------------:|:---------------------------|----------:|
| B0: Static Semantic k=2                                 | 2.000000 |  0.311819 |  509.619048 | Static baseline            | -1.039176 |
| B1: Static Semantic k=4                                 | 4.000000 |  0.390929 |  921.056277 | Static baseline            | -0.117776 |
| B2: Static Semantic k=6                                 | 6.000000 |  0.395731 | 1325.073593 | Static baseline            | -0.061852 |
| B3: Static Semantic k=8                                 | 8.000000 |  0.401041 | 1737.411255 | Best static reference      |  0.000000 |
| B4: W7-A (Old W4 + Semantic Routing)                    | 4.820000 |  0.378200 | 1095.000000 | Frozen W4 composition      | -0.266036 |
| B5: W7-B (Semantic-Aware Old W4 Features)               | 3.480000 |  0.352200 |  815.400000 | W4 retrained               | -0.568860 |
| B6: Semantic Epsilon-Oracle                             | 3.300000 |  0.486900 |  775.200000 | Theoretical upper bound    |  1.000000 |
| B7: W7-C Retrieval-Aware Semantic Sufficiency Allocator | 6.848485 |  0.378323 | 1503.800866 | Winning F4 GBDT (tau=0.80) | -0.264598 |

Source: [results/week7/w7c_retrieval_aware_allocator/tables/w7c_main_dev_results.csv](../repository/results/week7/w7c_retrieval_aware_allocator/tables/w7c_main_dev_results.csv).

### Stored bootstrap contrasts; interpret named metric/difference exactly

| comparison                  |   delta_f1 |   ci_lower_f1 |   ci_upper_f1 |   p_value_f1 |   delta_tokens |   ci_lower_tokens |   ci_upper_tokens |
|:----------------------------|-----------:|--------------:|--------------:|-------------:|---------------:|------------------:|------------------:|
| W7-C vs Static Semantic k=4 |  -0.012606 |     -0.049099 |      0.019829 |     0.475000 |     582.744589 |        503.886497 |        659.507719 |
| W7-C vs Static Semantic k=6 |  -0.017408 |     -0.051682 |      0.013709 |     0.279000 |     178.727273 |        107.462990 |        248.906385 |
| W7-C vs Static Semantic k=8 |  -0.022718 |     -0.053577 |      0.003620 |     0.110000 |    -233.610390 |       -301.625401 |       -167.691813 |
| W7-C vs W7-B Allocator      |   0.026487 |     -0.006464 |      0.057484 |     0.125000 |     688.400866 |        596.713808 |        774.317959 |

Source: [results/week7/w7c_retrieval_aware_allocator/bootstrap/w7c_bootstrap_comparisons.csv](../repository/results/week7/w7c_retrieval_aware_allocator/bootstrap/w7c_bootstrap_comparisons.csv).

### w7c2 main dev results

| method                               |   mean_k |   mean_f1 |      tokens | notes                                      |   ROH_sem |
|:-------------------------------------|---------:|----------:|------------:|:-------------------------------------------|----------:|
| B0: Static Semantic k=2              | 2.000000 |  0.311819 |  509.619048 | Static baseline                            | -1.039176 |
| B1: Static Semantic k=4              | 4.000000 |  0.390929 |  921.056277 | Static baseline (Dominant)                 | -0.117776 |
| B2: Static Semantic k=6              | 6.000000 |  0.395731 | 1325.073593 | Static baseline                            | -0.061852 |
| B3: Static Semantic k=8              | 8.000000 |  0.401041 | 1737.411255 | Best static reference                      |  0.000000 |
| B4: W7-A (Old W4 + Semantic Routing) | 4.820000 |  0.378200 | 1095.000000 | W4 composition                             | -0.266036 |
| B5: W7-B (Old Features Retrained)    | 3.480000 |  0.352200 |  815.400000 | W4 retrained                               | -0.568860 |
| B6: W7-C1 (Sufficiency Classifier)   | 6.850000 |  0.378300 | 1503.800000 | Fallback k8 failure                        | -0.264871 |
| B7: Semantic Epsilon-Oracle          | 3.300000 |  0.486900 |  775.200000 | Theoretical upper bound                    |  1.000000 |
| B8: W7-C2 Winner (M1_Reg_delta_0.0)  | 7.385281 |  0.392233 | 1622.099567 | Winning W7-C2 model (M1_Direct_Regression) | -0.102593 |

Source: [results/week7/w7c2_utility_ranking/tables/w7c2_main_dev_results.csv](../repository/results/week7/w7c2_utility_ranking/tables/w7c2_main_dev_results.csv).

## Main scientific conclusions

- Old allocator + semantic routing F1 is0.378150, below the same allocator with BM250.384172 and static semantic k40.391333. Source: [results/week7/w7a_budget_semantic_composition/tables/w7a_main_results.csv](../repository/results/week7/w7a_budget_semantic_composition/tables/w7a_main_results.csv)
- New semantic-aware allocator F1 is0.3522 versus semantic k40.3909 and k80.4010; its retrospective epsilon oracle0.4869 is not deployable. Source: [results/week7/w7b_semantic_budget/tables/w7b_main_dev_results.csv](../repository/results/week7/w7b_semantic_budget/tables/w7b_main_dev_results.csv)
- Selected sufficiency allocator F1 is0.378323 at mean k6.8485, below static semantic k40.390929. Source: [results/week7/w7c_retrieval_aware_allocator/tables/w7c_main_dev_results.csv](../repository/results/week7/w7c_retrieval_aware_allocator/tables/w7c_main_dev_results.csv)
- Selected utility-ranking model F1 is0.392233 at mean k7.3853 and1622.10 tokens, below static k80.401041. Source: [results/week7/w7c2_utility_ranking/tables/w7c2_main_dev_results.csv](../repository/results/week7/w7c2_utility_ranking/tables/w7c2_main_dev_results.csv)
- Anchor-and-deviate F1 is0.380107 at903.10 tokens versus anchor k40.390929 at921.06 tokens; limited savings come with lower point quality. Source: [results/week7/w7c3_anchor_deviate/tables/w7c3_main_dev_results.csv](../repository/results/week7/w7c3_anchor_deviate/tables/w7c3_main_dev_results.csv)
- Hierarchical frozen/unfrozen DEV policies collapse to static k4 (F10.390929); listwise7B LoRA reaches0.387714. Internal-VAL table values are different cohorts, not competing DEV scores. Source: [results/week7/w7d_cross_encoder_router/tables/w7d_main_dev_results.csv](../repository/results/week7/w7d_cross_encoder_router/tables/w7d_main_dev_results.csv)
- Repaired hybrid E1-H F10.3861 exceeds corrected extract-only0.3755, but trails static k40.3909 while using more tokens. Medium representation does not establish net quality/cost benefit. Source: [results/week7/w7e_multifidelity/tables/w7e_main_dev_results.csv](../repository/results/week7/w7e_multifidelity/tables/w7e_main_dev_results.csv)

## What did NOT work?

Retrained, sufficiency, utility and anchor policies generally fail to improve static quality; multifidelity medium extraction adds cost without clear net gain.

## Limitations

Repeated exploratory DEV exposure, outcome-derived oracle targets, semantic-encoder limitations, baseline drift and separate train/VAL/DEV scopes.

## Decision after this week

Simple fixed semantic budgets remain strong references; learned global-k and medium-fidelity choices are not universally promoted.

## One-paragraph week takeaway

Old allocator + semantic routing F1 is0.378150, below the same allocator with BM250.384172 and static semantic k40.391333. New semantic-aware allocator F1 is0.3522 versus semantic k40.3909 and k80.4010; its retrospective epsilon oracle0.4869 is not deployable. Selected sufficiency allocator F1 is0.378323 at mean k6.8485, below static semantic k40.390929. Selected utility-ranking model F1 is0.392233 at mean k7.3853 and1622.10 tokens, below static k80.401041. Anchor-and-deviate F1 is0.380107 at903.10 tokens versus anchor k40.390929 at921.06 tokens; limited savings come with lower point quality. Hierarchical frozen/unfrozen DEV policies collapse to static k4 (F10.390929); listwise7B LoRA reaches0.387714. Internal-VAL table values are different cohorts, not competing DEV scores. Repaired hybrid E1-H F10.3861 exceeds corrected extract-only0.3755, but trails static k40.3909 while using more tokens. Medium representation does not establish net quality/cost benefit.

# Primary Sources Used

- [configs/week7/w7a_budget_semantic_composition.yaml](../repository/configs/week7/w7a_budget_semantic_composition.yaml)
- [configs/week7/w7b_semantic_budget_relearning.yaml](../repository/configs/week7/w7b_semantic_budget_relearning.yaml)
- [configs/week7/w7c2_utility_aware_budget_ranking.yaml](../repository/configs/week7/w7c2_utility_aware_budget_ranking.yaml)
- [configs/week7/w7c3_anchor_deviate.yaml](../repository/configs/week7/w7c3_anchor_deviate.yaml)
- [configs/week7/w7c_retrieval_aware_allocator.yaml](../repository/configs/week7/w7c_retrieval_aware_allocator.yaml)
- [configs/week7/w7d_cross_encoder_fidelity_router.yaml](../repository/configs/week7/w7d_cross_encoder_fidelity_router.yaml)
- [configs/week7/w7e_multifidelity.yaml](../repository/configs/week7/w7e_multifidelity.yaml)
- notebooks/week7/week7a_budget_semantic_composition.ipynb (`../../../notebooks/week7/week7a_budget_semantic_composition.ipynb`; source dependency not packaged)
- notebooks/week7/week7b_semantic_budget_relearning.ipynb (`../../../notebooks/week7/week7b_semantic_budget_relearning.ipynb`; source dependency not packaged)
- notebooks/week7/week7c2_utility_aware_budget_ranking.ipynb (`../../../notebooks/week7/week7c2_utility_aware_budget_ranking.ipynb`; source dependency not packaged)
- notebooks/week7/week7c3_anchor_and_deviate_policy.ipynb (`../../../notebooks/week7/week7c3_anchor_and_deviate_policy.ipynb`; source dependency not packaged)
- notebooks/week7/week7c_retrieval_aware_semantic_allocator.ipynb (`../../../notebooks/week7/week7c_retrieval_aware_semantic_allocator.ipynb`; source dependency not packaged)
- notebooks/week7/week7d_cross_encoder_fidelity_router.ipynb (`../../../notebooks/week7/week7d_cross_encoder_fidelity_router.ipynb`; source dependency not packaged)
- notebooks/week7/week7e_multifidelity_representation.ipynb (`../../../notebooks/week7/week7e_multifidelity_representation.ipynb`; source dependency not packaged)
- [results/week7/w7a_budget_semantic_composition/bootstrap/w7a_bootstrap_comparisons.csv](../repository/results/week7/w7a_budget_semantic_composition/bootstrap/w7a_bootstrap_comparisons.csv)
- [results/week7/w7a_budget_semantic_composition/figures/w7a_quality_vs_tokens.png](../repository/results/week7/w7a_budget_semantic_composition/figures/w7a_quality_vs_tokens.png)
- [results/week7/w7a_budget_semantic_composition/tables/w7a_main_results.csv](../repository/results/week7/w7a_budget_semantic_composition/tables/w7a_main_results.csv)
- [results/week7/w7b_semantic_budget/bootstrap/w7b_bootstrap_comparisons.csv](../repository/results/week7/w7b_semantic_budget/bootstrap/w7b_bootstrap_comparisons.csv)
- [results/week7/w7b_semantic_budget/figures/w7b_quality_vs_tokens.png](../repository/results/week7/w7b_semantic_budget/figures/w7b_quality_vs_tokens.png)
- [results/week7/w7b_semantic_budget/tables/w7b_main_dev_results.csv](../repository/results/week7/w7b_semantic_budget/tables/w7b_main_dev_results.csv)
- [results/week7/w7c2_utility_ranking/bootstrap/w7c2_bootstrap_comparisons.csv](../repository/results/week7/w7c2_utility_ranking/bootstrap/w7c2_bootstrap_comparisons.csv)
- [results/week7/w7c2_utility_ranking/figures/w7c2_quality_vs_tokens.png](../repository/results/week7/w7c2_utility_ranking/figures/w7c2_quality_vs_tokens.png)
- [results/week7/w7c2_utility_ranking/tables/w7c2_main_dev_results.csv](../repository/results/week7/w7c2_utility_ranking/tables/w7c2_main_dev_results.csv)
- [results/week7/w7c3_anchor_deviate/bootstrap/w7c3_bootstrap_comparisons.csv](../repository/results/week7/w7c3_anchor_deviate/bootstrap/w7c3_bootstrap_comparisons.csv)
- [results/week7/w7c3_anchor_deviate/figures/w7c3_oof_quality_vs_tokens.png](../repository/results/week7/w7c3_anchor_deviate/figures/w7c3_oof_quality_vs_tokens.png)
- [results/week7/w7c3_anchor_deviate/tables/w7c3_main_dev_results.csv](../repository/results/week7/w7c3_anchor_deviate/tables/w7c3_main_dev_results.csv)
- [results/week7/w7c_retrieval_aware_allocator/bootstrap/w7c_bootstrap_comparisons.csv](../repository/results/week7/w7c_retrieval_aware_allocator/bootstrap/w7c_bootstrap_comparisons.csv)
- [results/week7/w7c_retrieval_aware_allocator/figures/w7c_quality_vs_tokens.png](../repository/results/week7/w7c_retrieval_aware_allocator/figures/w7c_quality_vs_tokens.png)
- [results/week7/w7c_retrieval_aware_allocator/tables/w7c_main_dev_results.csv](../repository/results/week7/w7c_retrieval_aware_allocator/tables/w7c_main_dev_results.csv)
- [results/week7/w7d_cross_encoder_router/bootstrap/w7d_bootstrap_comparisons.csv](../repository/results/week7/w7d_cross_encoder_router/bootstrap/w7d_bootstrap_comparisons.csv)
- [results/week7/w7d_cross_encoder_router/figures/w7d_quality_vs_tokens.png](../repository/results/week7/w7d_cross_encoder_router/figures/w7d_quality_vs_tokens.png)
- [results/week7/w7d_cross_encoder_router/tables/w7d_main_dev_results.csv](../repository/results/week7/w7d_cross_encoder_router/tables/w7d_main_dev_results.csv)
- [results/week7/w7e_multifidelity/tables/w7e_main_dev_results.csv](../repository/results/week7/w7e_multifidelity/tables/w7e_main_dev_results.csv)

# Existing Markdown Used as Evidence

NONE


---

## Week 8

Source: [results/weekly_reports/week_08/WeeklySummaryAnalysis.md](../repository/results/weekly_reports/week_08/WeeklySummaryAnalysis.md)

# Week 8 — Summary Analysis

## Objective

Investigate draft-aware selective evidence promotion, measured generator interaction and adaptation while separating real execution from archived/smoke prototypes.

## Experiments performed

| Part       | Question                                                                                         | Status             | Main_result                                                                                                                                                                                         |
|:-----------|:-------------------------------------------------------------------------------------------------|:-------------------|:----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| A          | Is there selective evidence-promotion headroom beyond a semantic-k4 draft?                       | COMPLETED          | FIT has10476 candidate rows for1746 queries. Base F1 is 0.385631; the retrospective selective oracle is 0.485209.                                                                                   |
| B          | Can draft generation signals identify when more evidence may help?                               | PARTIALLY EXECUTED | Executed code-cell outputs record342 generated drafts and12 uncertainty features. The saved output also has degenerate logprob/length features (e.g. answer length mean0) despite completed drafts. |
| C          | Can a learned selector outperform draft-semantic or heuristic selection?                         | COMPLETED          | U4-A FIT OOF oracle-gated headroom recovery is0.390104 versus DraftSemantic0.389770: an extremely small difference. Oracle-gated F1 must not be mistaken for unconditional promoted-answer quality. |
| D          | Do semantic/redundancy/masking features improve selection after draft generation?                | COMPLETED          | Masking measured10464/10476 FIT candidate rows; missing12 are not observed zeros. On INTERNAL-VAL, S3/S7 always-promote F1 is0.412572 versus base0.389061; U4-A is0.408329.                         |
| D-CLOSEOUT | Does a replay preserve selector identities and distinguish actual from oracle-gated improvement? | COMPLETED          | Separate FIT metrics and frozen-decision artifacts exist for the closeout. Always-promote and oracle-gated SHR columns are reported separately.                                                     |
| E          | Can an implementable gate retain helpful promotions while rejecting harmful ones?                | COMPLETED          | The 342-query INTERNAL-VAL table distinguishes no-promotion E0 F10.389061, always-promotion E1 0.412572, and gated E2 0.406122. Pipeline status is complete for this controller artifact set.       |
| F          | Does conditioning/adapting the generator improve draft answers?                                  | COMPLETED          | QCLA0/1/2 validation F1 is0.389061/0.393799/0.398994. QCLA2 doubles recorded cumulative prompt tokens; trainable parameters are about62.9M.                                                         |
| G          | Does outcome-weighted generator adaptation improve difficult cases?                              | IMPLEMENTED        | No executed code outputs or completed full-run result artifact were found in the named G notebook/output paths.                                                                                     |
| H          | Does the integrated DAFiR system improve answer quality and cumulative cost?                     | SMOKE-TESTED       | Only explicitly smoke-labelled full-system cost output was located; full-system completion is not established.                                                                                      |
| I          | Which components contribute in the integrated system?                                            | IMPLEMENTED        | No completed result artifact was found for the named I full-run path.                                                                                                                               |
| J          | Does the frozen integrated system generalize to DEV?                                             | SMOKE-TESTED       | The surviving final-comparison bootstrap is smoke-labelled. A full completed J DEV evaluation is not established.                                                                                   |

## Key results

### Raw six-candidate FIT surface recomputation

|     queries |   candidate_rows |   base_F1 |   always_best_candidate_F1 |   retrospective_selective_oracle_F1 |
|------------:|-----------------:|----------:|---------------------------:|------------------------------------:|
| 1746.000000 |     10476.000000 |  0.385631 |                   0.481899 |                            0.485209 |

Source: results/week8/surfaces/promotion_surface_fit.jsonl (`../../week8/surfaces/promotion_surface_fit.jsonl`; source dependency not packaged).

### fit oof comparison

| selector         |   base_k4_f1 |   oracle_selective1_f1 |   num_queries |   top1_oracle_accuracy |   near_oracle_selection_rate |   mean_selected_delta_f1 |   unconditional_downstream_f1 |   num_promoted |   mean_regret |   median_regret |   help_precision |   hurt_rate |   final_downstream_f1 |   selector_headroom_recovery |
|:-----------------|-------------:|-----------------------:|--------------:|-----------------------:|-----------------------------:|-------------------------:|------------------------------:|---------------:|--------------:|----------------:|-----------------:|------------:|----------------------:|-----------------------------:|
| S0 Rank5         |     0.385631 |               0.485174 |   1746.000000 |               0.735395 |                     0.742268 |                 0.012389 |                      0.398021 |    1746.000000 |      0.083878 |        0.000000 |         0.129439 |    0.094502 |              0.417425 |                     0.319403 |
| S1 BM25          |     0.385631 |               0.485174 |   1746.000000 |               0.727377 |                     0.734250 |                 0.017482 |                      0.403113 |    1746.000000 |      0.078785 |        0.000000 |         0.130011 |    0.101375 |              0.421979 |                     0.365144 |
| S2 Semantic      |     0.385631 |               0.485174 |   1746.000000 |               0.735395 |                     0.742268 |                 0.012389 |                      0.398021 |    1746.000000 |      0.083878 |        0.000000 |         0.129439 |    0.094502 |              0.417425 |                     0.319403 |
| S3 DraftSemantic |     0.385631 |               0.485174 |   1746.000000 |               0.741695 |                     0.749141 |                 0.019823 |                      0.405454 |    1746.000000 |      0.076444 |        0.000000 |         0.143184 |    0.098511 |              0.424430 |                     0.389770 |
| S4 MIG           |     0.385631 |               0.485174 |   1746.000000 |               0.744559 |                     0.750859 |                 0.017753 |                      0.403384 |    1746.000000 |      0.078514 |        0.000000 |         0.138603 |    0.092784 |              0.422394 |                     0.369316 |
| Oracle           |     0.385631 |               0.485174 |   1746.000000 |               1.000000 |                     1.000000 |                 0.096267 |                      0.481899 |    1746.000000 |      0.000000 |        0.000000 |         0.302405 |    0.015464 |              0.485174 |                     1.000000 |
| U0               |     0.385631 |               0.485174 |   1746.000000 |               0.724513 |                     0.730813 |                 0.010577 |                      0.396208 |    1746.000000 |      0.085691 |        0.000000 |         0.115120 |    0.101375 |              0.413699 |                     0.281970 |
| U1               |     0.385631 |               0.485174 |   1746.000000 |               0.721649 |                     0.729095 |                 0.012770 |                      0.398401 |    1746.000000 |      0.083498 |        0.000000 |         0.119129 |    0.102520 |              0.419636 |                     0.341613 |
| U2-F             |     0.385631 |               0.485174 |   1746.000000 |               0.718213 |                     0.725659 |                 0.012201 |                      0.397832 |    1746.000000 |      0.084067 |        0.000000 |         0.122566 |    0.108247 |              0.419232 |                     0.337552 |
| U2-A             |     0.385631 |               0.485174 |   1746.000000 |               0.737113 |                     0.745132 |                 0.016968 |                      0.402600 |    1746.000000 |      0.079299 |        0.000000 |         0.139748 |    0.100229 |              0.422009 |                     0.365444 |
| U3               |     0.385631 |               0.485174 |   1746.000000 |               0.725086 |                     0.732532 |                 0.012090 |                      0.397721 |    1746.000000 |      0.084177 |        0.000000 |         0.115120 |    0.092784 |              0.413827 |                     0.283256 |
| U4-A             |     0.385631 |               0.485174 |   1746.000000 |               0.741695 |                     0.748568 |                 0.017139 |                      0.402770 |    1746.000000 |      0.079128 |        0.000000 |         0.145475 |    0.103093 |              0.424463 |                     0.390104 |

Source: [results/week8/w8c_utility/fit_oof_comparison.csv](../repository/results/week8/w8c_utility/fit_oof_comparison.csv).

### Masking feature availability

|   rows |   measured_masking |   missing_masking |
|-------:|-------------------:|------------------:|
|  10476 |              10464 |                12 |

Source: results/week8/w8d_attribution/full/features_fit.csv (`../../week8/w8d_attribution/full/features_fit.csv`; source dependency not packaged).

### internal val metrics

| selector   |   always_promote_f1 |   base_f1 |   oracle_gated_shr |   n |   help_rate |   hurt_rate |   mean_delta |   mean_regret |   top1_tied_best |   near_oracle_rate |   final_prompt_tokens |   cumulative_prompt_tokens |   escalation.n |   escalation.help_rate |   escalation.hurt_rate |   escalation.mean_delta |   escalation.mean_regret |   escalation.top1_tied_best |   escalation.near_oracle_rate |
|:-----------|--------------------:|----------:|-------------------:|----:|------------:|------------:|-------------:|--------------:|-----------------:|-------------------:|----------------------:|---------------------------:|---------------:|-----------------------:|-----------------------:|------------------------:|-------------------------:|----------------------------:|------------------------------:|
| S3         |            0.412572 |  0.389061 |           0.447599 | 342 |    0.146199 |    0.099415 |     0.023511 |      0.067451 |         0.769006 |           0.771930 |           1125.228070 |                2052.385965 |             98 |               0.510204 |               0.153061 |                0.143096 |                 0.176601 |                    0.377551 |                      0.377551 |
| S5         |            0.389016 |  0.389061 |           0.205557 | 342 |    0.111111 |    0.111111 |    -0.000045 |      0.091007 |         0.730994 |           0.739766 |           1134.005848 |                2061.163743 |             98 |               0.387755 |               0.173469 |                0.065716 |                 0.253981 |                    0.285714 |                      0.285714 |
| S6         |            0.396327 |  0.389061 |           0.216938 | 342 |    0.108187 |    0.099415 |     0.007266 |      0.083697 |         0.730994 |           0.739766 |           1116.874269 |                2044.032164 |             98 |               0.377551 |               0.163265 |                0.069354 |                 0.250343 |                    0.265306 |                      0.265306 |
| S7         |            0.412572 |  0.389061 |           0.447599 | 342 |    0.146199 |    0.099415 |     0.023511 |      0.067451 |         0.769006 |           0.771930 |           1125.605263 |                2052.763158 |             98 |               0.510204 |               0.153061 |                0.143096 |                 0.176601 |                    0.377551 |                      0.377551 |
| S8         |            0.412572 |  0.389061 |           0.447599 | 342 |    0.146199 |    0.099415 |     0.023511 |      0.067451 |         0.769006 |           0.771930 |           1125.605263 |                2052.763158 |             98 |               0.510204 |               0.153061 |                0.143096 |                 0.176601 |                    0.377551 |                      0.377551 |
| U4-A       |            0.408329 |  0.389061 |           0.286666 | 342 |    0.134503 |    0.070175 |     0.019267 |      0.071695 |         0.777778 |           0.786550 |           1164.154971 |                2091.312865 |             98 |               0.469388 |               0.132653 |                0.091646 |                 0.228051 |                    0.336735 |                      0.346939 |
| U4-B       |            0.416716 |  0.389061 |           0.395678 | 342 |    0.134503 |    0.064327 |     0.027655 |      0.063308 |         0.769006 |           0.783626 |           1139.616959 |                2066.774854 |             98 |               0.469388 |               0.091837 |                0.126497 |                 0.193200 |                    0.346939 |                      0.357143 |

Source: [results/week8/w8d_closeout/internal_val_metrics.csv](../repository/results/week8/w8d_closeout/internal_val_metrics.csv).

### fit metrics

| selector    |   always_promote_f1 |   base_f1 |   oracle_gated_shr |    n |   help_rate |   hurt_rate |   mean_delta |   mean_regret |   top1_tied_best |   near_oracle_rate |   final_prompt_tokens |   cumulative_prompt_tokens |   escalation.n |   escalation.help_rate |   escalation.hurt_rate |   escalation.mean_delta |   escalation.mean_regret |   escalation.top1_tied_best |   escalation.near_oracle_rate |
|:------------|--------------------:|----------:|-------------------:|-----:|------------:|------------:|-------------:|--------------:|-----------------:|-------------------:|----------------------:|---------------------------:|---------------:|-----------------------:|-----------------------:|------------------------:|-------------------------:|----------------------------:|------------------------------:|
| S3          |            0.405454 |  0.385631 |           0.389770 | 1746 |    0.143184 |    0.098511 |     0.019823 |      0.076444 |         0.741695 |           0.749141 |           1138.769187 |                2071.313288 |            528 |               0.473485 |               0.106061 |                0.128301 |                 0.200869 |                    0.344697 |                      0.354167 |
| S5          |            0.396207 |  0.385631 |           0.292828 | 1746 |    0.113975 |    0.095647 |     0.010576 |      0.085691 |         0.723368 |           0.726804 |           1140.276632 |                2072.820733 |            528 |               0.376894 |               0.107955 |                0.096390 |                 0.232780 |                    0.272727 |                      0.276515 |
| S6          |            0.403384 |  0.385631 |           0.369316 | 1746 |    0.138603 |    0.092784 |     0.017753 |      0.078514 |         0.744559 |           0.750859 |           1126.317297 |                2058.861397 |            528 |               0.458333 |               0.107955 |                0.121568 |                 0.207602 |                    0.333333 |                      0.340909 |
| S7          |            0.405454 |  0.385631 |           0.389770 | 1746 |    0.143184 |    0.098511 |     0.019823 |      0.076444 |         0.741695 |           0.749141 |           1138.622566 |                2071.166667 |            528 |               0.473485 |               0.106061 |                0.128301 |                 0.200869 |                    0.344697 |                      0.354167 |
| S8          |            0.400908 |  0.385631 |           0.372510 | 1746 |    0.144903 |    0.105384 |     0.015277 |      0.080990 |         0.738259 |           0.746850 |           1136.412944 |                2068.957045 |            528 |               0.479167 |               0.117424 |                0.122619 |                 0.206551 |                    0.348485 |                      0.361742 |
| U4-A        |            0.402770 |  0.385631 |           0.390104 | 1746 |    0.145475 |    0.103093 |     0.017139 |      0.079128 |         0.741695 |           0.748568 |           1160.022337 |                2092.566438 |            528 |               0.481061 |               0.106061 |                0.128411 |                 0.200759 |                    0.354167 |                      0.365530 |
| U4-A-replay |            0.402770 |  0.385631 |           0.390104 | 1746 |    0.145475 |    0.103093 |     0.017139 |      0.079128 |         0.741695 |           0.748568 |           1160.022337 |                2092.566438 |            528 |               0.481061 |               0.106061 |                0.128411 |                 0.200759 |                    0.354167 |                      0.365530 |
| U4-B        |            0.403255 |  0.385631 |           0.395365 | 1746 |    0.142039 |    0.101375 |     0.017624 |      0.078643 |         0.735395 |           0.741695 |           1157.974227 |                2090.518328 |            528 |               0.469697 |               0.104167 |                0.130142 |                 0.199028 |                    0.339015 |                      0.348485 |

Source: [results/week8/w8d_closeout/fit_metrics.csv](../repository/results/week8/w8d_closeout/fit_metrics.csv).

### internal val metrics

| Unnamed: 0       |   num_queries |   promotion_rate |   downstream_f1 |   gain_over_k4 |   mean_final_prompt_tokens |   mean_cumulative_prompt_tokens |   help_rate_all_queries |   hurt_rate_all_queries |
|:-----------------|--------------:|-----------------:|----------------:|---------------:|---------------------------:|--------------------------------:|------------------------:|------------------------:|
| E0               |           342 |         0.000000 |        0.389061 |       0.000000 |                 935.157895 |                      935.157895 |                0.000000 |                0.000000 |
| E1               |           342 |         1.000000 |        0.412572 |       0.023511 |                1133.228070 |                     2068.385965 |                0.146199 |                0.099415 |
| E2               |           342 |         0.625731 |        0.406122 |       0.017061 |                1060.959064 |                     1651.935673 |                0.131579 |                0.087719 |
| E3               |           342 |         0.625731 |        0.401963 |       0.012902 |                1084.216374 |                     1675.192982 |                0.122807 |                0.070175 |
| E5-DraftSemantic |           342 |         0.421053 |        0.400080 |       0.011018 |                1017.593567 |                     1416.111111 |                0.055556 |                0.046784 |
| E5-U4-A          |           342 |         0.485380 |        0.399381 |       0.010320 |                1050.204678 |                     1509.903509 |                0.087719 |                0.035088 |

Source: [results/week8/w8e_controller/internal_val_metrics.csv](../repository/results/week8/w8e_controller/internal_val_metrics.csv).

### comparison

| variant   |   validation_queries |   trainable_params |   validation_f1 |   validation_query_mean_answer_nll |   mean_final_prompt_tokens |   mean_cumulative_prompt_tokens |   mean_adapted_generation_latency_sec |   mean_estimated_cumulative_generation_latency_sec |   mean_conditioning_encode_seconds |   end_to_end_latency_sec |
|:----------|---------------------:|-------------------:|----------------:|-----------------------------------:|---------------------------:|--------------------------------:|--------------------------------------:|---------------------------------------------------:|-----------------------------------:|-------------------------:|
| qcla_0    |                  342 |                  0 |        0.389061 |                           1.259202 |                 935.157895 |                      935.157895 |                              2.711161 |                                           2.711161 |                           0.000000 |                      nan |
| qcla_1    |                  342 |           52439552 |        0.393799 |                           1.218129 |                 935.157895 |                      935.157895 |                              2.523085 |                                           2.523085 |                           0.102399 |                      nan |
| qcla_2    |                  342 |           62925312 |        0.398994 |                           1.219554 |                 935.157895 |                     1870.315789 |                              2.555450 |                                           5.247229 |                           0.204798 |                      nan |

Source: [results/week8/w8f_qcla/full/comparison.csv](../repository/results/week8/w8f_qcla/full/comparison.csv).

### w8h dafir1 cost summary smoke

|   mean_final_context_tokens |   mean_cumulative_prompt_tokens |   mean_generated_tokens |   mean_e2e_latency_sec |   mean_num_passes |   promotion_rate |   mean_num_promotions |   gpu_peak_memory_mb |
|----------------------------:|--------------------------------:|------------------------:|-----------------------:|------------------:|-----------------:|----------------------:|---------------------:|
|                 1125.500000 |                     1944.500000 |            -1946.000000 |               4.514522 |          2.000000 |         1.000000 |              1.000000 |             0.000000 |

Source: [results/week8/tables/w8h_dafir1_cost_summary_smoke.csv](../repository/results/week8/tables/w8h_dafir1_cost_summary_smoke.csv).

### w8j bootstrap dafir vs k4 smoke

| comparison                |   n_resamples |   n_queries |   n_papers |   mean_treatment_f1 |   mean_control_f1 |   delta_f1 | ci_f1_95                                     |   p_value_f1 |   delta_final_tokens | ci_final_tokens_95   |   delta_cum_tokens |   delta_latency_sec |
|:--------------------------|--------------:|------------:|-----------:|--------------------:|------------------:|-----------:|:---------------------------------------------|-------------:|---------------------:|:---------------------|-------------------:|--------------------:|
| DAFiR_Full_vs_Semantic_k4 |            50 |           5 |          4 |            0.414000 |          0.390900 |   0.023100 | [0.023099999999999954, 0.023099999999999954] |     0.000000 |            74.000000 | [74.0, 74.0]         |         459.000000 |            0.000000 |

Source: [results/week8/tables/w8j_bootstrap_dafir_vs_k4_smoke.csv](../repository/results/week8/tables/w8j_bootstrap_dafir_vs_k4_smoke.csv).

## Main scientific conclusions

- FIT has10476 candidate rows for1746 queries. Base F1 is 0.385631; the retrospective selective oracle is 0.485209. Source: results/week8/surfaces/promotion_surface_fit.jsonl (`../../week8/surfaces/promotion_surface_fit.jsonl`; source dependency not packaged)
- Executed code-cell outputs record342 generated drafts and12 uncertainty features. The saved output also has degenerate logprob/length features (e.g. answer length mean0) despite completed drafts. Source: notebooks/week8/week8b_draft_diagnostics.ipynb (`../../../notebooks/week8/week8b_draft_diagnostics.ipynb`; source dependency not packaged), results/week8/drafts/draft_diagnostics_internal_val.jsonl (`../../week8/drafts/draft_diagnostics_internal_val.jsonl`; source dependency not packaged)
- U4-A FIT OOF oracle-gated headroom recovery is0.390104 versus DraftSemantic0.389770: an extremely small difference. Oracle-gated F1 must not be mistaken for unconditional promoted-answer quality. Source: [results/week8/w8c_utility/fit_oof_comparison.csv](../repository/results/week8/w8c_utility/fit_oof_comparison.csv), [results/week8/w8c_utility/w8c_frozen_selector_config.json](../repository/results/week8/w8c_utility/w8c_frozen_selector_config.json)
- Masking measured10464/10476 FIT candidate rows; missing12 are not observed zeros. On INTERNAL-VAL, S3/S7 always-promote F1 is0.412572 versus base0.389061; U4-A is0.408329. Source: results/week8/w8d_attribution/full/features_fit.csv (`../../week8/w8d_attribution/full/features_fit.csv`; source dependency not packaged), [results/week8/w8d_closeout/internal_val_metrics.csv](../repository/results/week8/w8d_closeout/internal_val_metrics.csv)
- Separate FIT metrics and frozen-decision artifacts exist for the closeout. Always-promote and oracle-gated SHR columns are reported separately. Source: [results/week8/w8d_closeout/fit_metrics.csv](../repository/results/week8/w8d_closeout/fit_metrics.csv), [results/week8/w8d_closeout/fit_frozen_decisions.json](../repository/results/week8/w8d_closeout/fit_frozen_decisions.json)
- The 342-query INTERNAL-VAL table distinguishes no-promotion E0 F10.389061, always-promotion E1 0.412572, and gated E2 0.406122. Pipeline status is complete for this controller artifact set. Source: [results/week8/w8e_controller/internal_val_metrics.csv](../repository/results/week8/w8e_controller/internal_val_metrics.csv), [results/week8/w8e_controller/controller_summary.json](../repository/results/week8/w8e_controller/controller_summary.json)
- QCLA0/1/2 validation F1 is0.389061/0.393799/0.398994. QCLA2 doubles recorded cumulative prompt tokens; trainable parameters are about62.9M. Source: [results/week8/w8f_qcla/full/comparison.csv](../repository/results/week8/w8f_qcla/full/comparison.csv), [results/week8/w8f_qcla/full/summary.json](../repository/results/week8/w8f_qcla/full/summary.json)
- No executed code outputs or completed full-run result artifact were found in the named G notebook/output paths. Source: notebooks/week8/week8g_outcome_weighted_sft.ipynb (`../../../notebooks/week8/week8g_outcome_weighted_sft.ipynb`; source dependency not packaged)
- Only explicitly smoke-labelled full-system cost output was located; full-system completion is not established. Source: [results/week8/tables/w8h_dafir1_cost_summary_smoke.csv](../repository/results/week8/tables/w8h_dafir1_cost_summary_smoke.csv)
- No completed result artifact was found for the named I full-run path. Source: notebooks/week8/week8i_ablations.ipynb (`../../../notebooks/week8/week8i_ablations.ipynb`; source dependency not packaged)
- The surviving final-comparison bootstrap is smoke-labelled. A full completed J DEV evaluation is not established. Source: notebooks/week8/week8j_final_dev_evaluation.ipynb (`../../../notebooks/week8/week8j_final_dev_evaluation.ipynb`; source dependency not packaged), [results/week8/tables/w8j_bootstrap_dafir_vs_k4_smoke.csv](../repository/results/week8/tables/w8j_bootstrap_dafir_vs_k4_smoke.csv)

## What did NOT work?

Learned selector gain over a simple draft-semantic selector is tiny on FIT; missing masking and stale uncertainty features require care; full G/I/J evaluation is not established.

## Limitations

Same project development exposure; retrospective gates/oracles; missing continuous likelihood labels; archived invalidated runs; smoke/full ambiguity must not be collapsed.

## Decision after this week

Controller/selector freezes preserve their FIT/INTERNAL-VAL roles. No universal learned-selector or end-to-end-system win is established.

## One-paragraph week takeaway

FIT has10476 candidate rows for1746 queries. Base F1 is 0.385631; the retrospective selective oracle is 0.485209. Executed code-cell outputs record342 generated drafts and12 uncertainty features. The saved output also has degenerate logprob/length features (e.g. answer length mean0) despite completed drafts. U4-A FIT OOF oracle-gated headroom recovery is0.390104 versus DraftSemantic0.389770: an extremely small difference. Oracle-gated F1 must not be mistaken for unconditional promoted-answer quality. Masking measured10464/10476 FIT candidate rows; missing12 are not observed zeros. On INTERNAL-VAL, S3/S7 always-promote F1 is0.412572 versus base0.389061; U4-A is0.408329. Separate FIT metrics and frozen-decision artifacts exist for the closeout. Always-promote and oracle-gated SHR columns are reported separately. The 342-query INTERNAL-VAL table distinguishes no-promotion E0 F10.389061, always-promotion E1 0.412572, and gated E2 0.406122. Pipeline status is complete for this controller artifact set. QCLA0/1/2 validation F1 is0.389061/0.393799/0.398994. QCLA2 doubles recorded cumulative prompt tokens; trainable parameters are about62.9M. No executed code outputs or completed full-run result artifact were found in the named G notebook/output paths. Only explicitly smoke-labelled full-system cost output was located; full-system completion is not established. No completed result artifact was found for the named I full-run path. The surviving final-comparison bootstrap is smoke-labelled. A full completed J DEV evaluation is not established.

# Primary Sources Used

- [configs/week8/w8_dafir.yaml](../repository/configs/week8/w8_dafir.yaml)
- notebooks/week8/week8_master.ipynb (`../../../notebooks/week8/week8_master.ipynb`; source dependency not packaged)
- notebooks/week8/week8a_promotion_oracle.ipynb (`../../../notebooks/week8/week8a_promotion_oracle.ipynb`; source dependency not packaged)
- notebooks/week8/week8b_draft_diagnostics.ipynb (`../../../notebooks/week8/week8b_draft_diagnostics.ipynb`; source dependency not packaged)
- notebooks/week8/week8c_utility_modeling.ipynb (`../../../notebooks/week8/week8c_utility_modeling.ipynb`; source dependency not packaged)
- notebooks/week8/week8d_cached_closeout.ipynb (`../../../notebooks/week8/week8d_cached_closeout.ipynb`; source dependency not packaged)
- notebooks/week8/week8d_generator_interaction.ipynb (`../../../notebooks/week8/week8d_generator_interaction.ipynb`; source dependency not packaged)
- notebooks/week8/week8e_controller.ipynb (`../../../notebooks/week8/week8e_controller.ipynb`; source dependency not packaged)
- notebooks/week8/week8f_qcla.ipynb (`../../../notebooks/week8/week8f_qcla.ipynb`; source dependency not packaged)
- notebooks/week8/week8g_outcome_weighted_sft.ipynb (`../../../notebooks/week8/week8g_outcome_weighted_sft.ipynb`; source dependency not packaged)
- notebooks/week8/week8h_full_system.ipynb (`../../../notebooks/week8/week8h_full_system.ipynb`; source dependency not packaged)
- notebooks/week8/week8i_ablations.ipynb (`../../../notebooks/week8/week8i_ablations.ipynb`; source dependency not packaged)
- notebooks/week8/week8j_final_dev_evaluation.ipynb (`../../../notebooks/week8/week8j_final_dev_evaluation.ipynb`; source dependency not packaged)
- results/week8/drafts/draft_diagnostics_internal_val.jsonl (`../../week8/drafts/draft_diagnostics_internal_val.jsonl`; source dependency not packaged)
- results/week8/surfaces/promotion_surface_fit.jsonl (`../../week8/surfaces/promotion_surface_fit.jsonl`; source dependency not packaged)
- [results/week8/tables/w8h_dafir1_cost_summary_smoke.csv](../repository/results/week8/tables/w8h_dafir1_cost_summary_smoke.csv)
- [results/week8/tables/w8j_bootstrap_dafir_vs_k4_smoke.csv](../repository/results/week8/tables/w8j_bootstrap_dafir_vs_k4_smoke.csv)
- [results/week8/w8c_utility/fit_oof_comparison.csv](../repository/results/week8/w8c_utility/fit_oof_comparison.csv)
- [results/week8/w8c_utility/w8c_frozen_selector_config.json](../repository/results/week8/w8c_utility/w8c_frozen_selector_config.json)
- results/week8/w8d_attribution/full/features_fit.csv (`../../week8/w8d_attribution/full/features_fit.csv`; source dependency not packaged)
- [results/week8/w8d_closeout/closeout_summary.json](../repository/results/week8/w8d_closeout/closeout_summary.json)
- [results/week8/w8d_closeout/fit_frozen_decisions.json](../repository/results/week8/w8d_closeout/fit_frozen_decisions.json)
- [results/week8/w8d_closeout/fit_metrics.csv](../repository/results/week8/w8d_closeout/fit_metrics.csv)
- [results/week8/w8d_closeout/internal_val_metrics.csv](../repository/results/week8/w8d_closeout/internal_val_metrics.csv)
- [results/week8/w8e_controller/controller_summary.json](../repository/results/week8/w8e_controller/controller_summary.json)
- [results/week8/w8e_controller/internal_val_metrics.csv](../repository/results/week8/w8e_controller/internal_val_metrics.csv)
- [results/week8/w8e_controller/pipeline_status.json](../repository/results/week8/w8e_controller/pipeline_status.json)
- [results/week8/w8f_qcla/full/comparison.csv](../repository/results/week8/w8f_qcla/full/comparison.csv)
- [results/week8/w8f_qcla/full/summary.json](../repository/results/week8/w8f_qcla/full/summary.json)

# Existing Markdown Used as Evidence

NONE


---

## Week 9

Source: [results/weekly_reports/week_09/WeeklySummaryAnalysis.md](../repository/results/weekly_reports/week_09/WeeklySummaryAnalysis.md)

# Week 9 — Summary Analysis

## Objective

Isolate retrieval, evidence count, selector, representation and revision effects, then evaluate frozen systems on historical QASPER TEST.

## Experiments performed

| Part   | Question                                                                               | Status       | Main_result                                                                                                                                                                                          |
|:-------|:---------------------------------------------------------------------------------------|:-------------|:-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| PRE    | Can candidate generator interfaces execute reliably before expensive evidence studies? | SMOKE-TESTED | Preflight/smoke artifacts exist; model qualification is not downstream quality evaluation.                                                                                                           |
| A      | Which chunking/retrieval configuration supplies a high-recall pool?                    | COMPLETED    | The frozen configuration is FIXED-5 / SEMANTIC / width20; recall/cost identity is compared before downstream generation.                                                                             |
| B      | Do fixed evidence counts improve the original draft?                                   | COMPLETED    | K0 F10.385631 exceeds fixed K1/K2/K4 point estimates; primary policy remains no intervention.                                                                                                        |
| C      | Does better selection rescue raw coarse evidence?                                      | COMPLETED    | SANE-adapted0.386336 vs DraftSemantic0.385004 is a small gain with one extra LM call; cost-efficient DraftSemantic remains the controlled selector.                                                  |
| D      | Does extracting evidence help beyond the same raw chunks?                              | COMPLETED    | Query-only D2 F10.368659 and draft-aware D3 0.376936 trail D00.385631; generative extraction does not establish a quality improvement.                                                               |
| E      | Do source support checks and fail-closed extraction make intervention useful?          | COMPLETED    | E0/E1-Q/E1-QD/E2 F1 is0.366109/0.382523/0.382099/0.383591, all below D0. Source grounding is not answer correctness.                                                                                 |
| E3     | Can non-generative exact-source sentence filtering improve evidence utilization?       | COMPLETED    | E3-k3 is the FIT-selected fixed policy at F10.390024; its +0.004393 versus D0 has CI[−0.008467,0.017454], so superiority is not established.                                                         |
| F      | Can revision prompts retain useful evidence while avoiding harmful edits?              | COMPLETED    | F0 is an alias of E3-k3 (0.390024); frozen F2-A is0.389616. Paired intervals versus D0/F0 span or nearly span zero; no robust revision breakthrough.                                                 |
| G      | Can a lightweight post-draft verifier learn to accept helpful revisions?               | COMPLETED    | Nested paper-OOF logistic/HGB F1 is0.389443/0.389266. Retrospective action-oracle headroom is not evidence that a verifier can learn it.                                                             |
| H      | Do frozen Week9 systems improve on untouched historical TEST?                          | COMPLETED    | On1309 TEST queries, W9-PRIMARY F10.372788 trails D00.376655, semantic k60.406446, semantic k80.415539 and BM25_k80.423667. W9-SAFE0.384465 and W9-VERIFY0.379775 are not clear paired improvements. |

## Key results

### Numerical preflight fields

| field                         |      value |
|:------------------------------|-----------:|
| [0].queries                   |   2.000000 |
| [0].f1                        |   0.029412 |
| [0].exact_match               |   0.000000 |
| [0].help_rate                 |   0.000000 |
| [0].hurt_rate                 |   1.000000 |
| [0].evidence_utilization_rate |   1.000000 |
| [0].faithfulness              | nan        |
| [0].empty_rate                |   0.000000 |
| [0].malformed_rate            |   0.000000 |
| [0].mean_input_tokens         | 208.500000 |
| [0].mean_generated_tokens     |  50.000000 |
| [0].mean_total_query_tokens   | 258.500000 |

Source: [results/week9/preflight/smoke_summary.json](../repository/results/week9/preflight/smoke_summary.json). First 12 of 180 rows shown; detailed report and source preserve the full comparison.

### Chunking / retrieval freeze primary outcome table

| representation   | retriever   |   retrieval_width |   any_gold_evidence_recall |   all_gold_evidence_recall |   retrieved_context_tokens |   evidence_overlap_density |
|:-----------------|:------------|------------------:|---------------------------:|---------------------------:|---------------------------:|---------------------------:|
| FIXED-5          | SEMANTIC    |                10 |                   0.945898 |                   0.873960 |                5364.430126 |                   0.050515 |
| FIXED-5          | SEMANTIC    |                20 |                   0.948870 |                   0.878716 |                5600.471936 |                   0.050366 |
| FIXED-5          | SEMANTIC    |                40 |                   0.948870 |                   0.878716 |                5613.739404 |                   0.050360 |

Source: [results/week9/retrieval/fit/w9a_summary.csv](../repository/results/week9/retrieval/fit/w9a_summary.csv).

### Evidence-count surface primary outcome table

| policy   |   n_queries |       f1 |   exact_match |   total_query_prompt_tokens |   num_lm_calls |
|:---------|------------:|---------:|--------------:|----------------------------:|---------------:|
| K_E=0    |        1746 | 0.385631 |      0.227950 |                  940.544101 |       1.000000 |
| K_E=1    |        1746 | 0.380967 |      0.201031 |                 2966.892325 |       2.000000 |
| K_E=2    |        1746 | 0.385004 |      0.193013 |                 3981.902062 |       2.000000 |
| K_E=4    |        1746 | 0.380388 |      0.176976 |                 5807.210195 |       2.000000 |

Source: [results/week9/ke_surface/fit/w9b_summary.csv](../repository/results/week9/ke_surface/fit/w9b_summary.csv).

### Forced-K2 selector diagnostic primary outcome table

| policy        |   n_queries |       f1 |   exact_match |   total_query_prompt_tokens |   num_lm_calls |
|:--------------|------------:|---------:|--------------:|----------------------------:|---------------:|
| BM25          |        1746 | 0.382157 |      0.190722 |                 4027.894044 |       2.000000 |
| QuerySemantic |        1746 | 0.383490 |      0.192440 |                 3985.801260 |       2.000000 |
| DraftSemantic |        1746 | 0.385004 |      0.193013 |                 3981.902062 |       2.000000 |
| QueryDraft    |        1746 | 0.384095 |      0.193585 |                 4001.830470 |       2.000000 |
| SANE-adapted  |        1746 | 0.386336 |      0.190722 |                 4794.498855 |       3.000000 |

Source: [results/week9/diagnostics/w9c_k2/selection/fit/w9c_summary.csv](../repository/results/week9/diagnostics/w9c_k2/selection/fit/w9c_summary.csv).

### Generative representation transformation primary outcome table

| policy   |   n_queries |       f1 |   exact_match |   total_query_prompt_tokens |   num_lm_calls |
|:---------|------------:|---------:|--------------:|----------------------------:|---------------:|
| D0       |        1746 | 0.385631 |      0.227950 |                  940.544101 |       1.000000 |
| D1       |        1746 | 0.385004 |      0.193013 |                 3981.902062 |       2.000000 |
| D2       |        1746 | 0.368659 |      0.205040 |                 5618.391180 |       3.000000 |
| D3       |        1746 | 0.376936 |      0.211340 |                 5690.195876 |       3.000000 |

Source: [results/week9/diagnostics/w9c_k2/extraction/fit/w9d_summary.csv](../repository/results/week9/diagnostics/w9c_k2/extraction/fit/w9d_summary.csv).

### Grounded extraction / faithfulness primary outcome table

| policy   |   queries |       f1 |   exact_match |   delta_f1 |   total_query_prompt_tokens |   num_lm_calls |
|:---------|----------:|---------:|--------------:|-----------:|----------------------------:|---------------:|
| D0       |      1746 | 0.385631 |      0.227950 |   0.000000 |                  940.544101 |       1.000000 |
| D1       |      1746 | 0.385004 |      0.193013 |  -0.000627 |                 3981.902062 |       2.000000 |
| D2       |      1746 | 0.368659 |      0.205040 |  -0.016972 |                 5618.391180 |       3.000000 |
| D3       |      1746 | 0.376936 |      0.211340 |  -0.008695 |                 5690.195876 |       3.000000 |
| E0       |      1746 | 0.366109 |      0.209049 |  -0.019522 |                 2033.599656 |       2.000000 |
| E1-Q     |      1746 | 0.382523 |      0.223940 |  -0.003108 |                 3365.097938 |       2.066438 |
| E1-QD    |      1746 | 0.382099 |      0.226231 |  -0.003532 |                 3455.739977 |       2.076174 |
| E2       |      1746 | 0.383591 |      0.225659 |  -0.002040 |                 3590.909507 |       2.127721 |

Source: [results/week9/diagnostics/w9c_k2/grounded_faithfulness/v1/budget_128/fit/answer_and_cost_summary.csv](../repository/results/week9/diagnostics/w9c_k2/grounded_faithfulness/v1/budget_128/fit/answer_and_cost_summary.csv).

### Semantic sentence suppression primary outcome table

| policy   |   n_queries |       f1 |   exact_match |   delta_f1 |   total_query_prompt_tokens |   num_lm_calls |
|:---------|------------:|---------:|--------------:|-----------:|----------------------------:|---------------:|
| E0       |        1746 | 0.366109 |      0.209049 |  -0.019522 |                 2033.599656 |       2.000000 |
| E1-Q     |        1746 | 0.382523 |      0.223940 |  -0.003108 |                 3365.097938 |       2.066438 |
| E1-QD    |        1746 | 0.382099 |      0.226231 |  -0.003532 |                 3455.739977 |       2.076174 |
| E2       |        1746 | 0.383591 |      0.225659 |  -0.002040 |                 3590.909507 |       2.127721 |
| D0       |        1746 | 0.385631 |      0.227950 |   0.000000 |                  940.544101 |       1.000000 |
| D1       |        1746 | 0.385004 |      0.193013 |  -0.000627 |                 3981.902062 |       2.000000 |
| D2       |        1746 | 0.368659 |      0.205040 |  -0.016972 |                 5618.391180 |       3.000000 |
| D3       |        1746 | 0.376936 |      0.211340 |  -0.008695 |                 5690.195876 |       3.000000 |
| E3-k1    |        1746 | 0.376361 |      0.218786 |  -0.009271 |                 1957.501718 |       2.000000 |
| E3-k2    |        1746 | 0.381658 |      0.221077 |  -0.003974 |                 1992.202749 |       2.000000 |
| E3-k3    |        1746 | 0.390024 |      0.226231 |   0.004393 |                 2026.312715 |       2.000000 |
| E3-k4    |        1746 | 0.380518 |      0.215349 |  -0.005113 |                 2062.064147 |       2.000000 |

Source: [results/week9/w9e3_senttopk/v1/fit/summary.csv](../repository/results/week9/w9e3_senttopk/v1/fit/summary.csv). First 12 of 14 rows shown; detailed report and source preserve the full comparison.

### Stored bootstrap contrasts; interpret named metric/difference exactly

| comparison   |   point_estimate |   ci95_low |   ci95_high |   resamples | cluster   |   seed |
|:-------------|-----------------:|-----------:|------------:|------------:|:----------|-------:|
| E3-k1 - D0   |        -0.009271 |  -0.022229 |    0.003307 |       10000 | paper_id  |     42 |
| E3-k1 - D1   |        -0.008644 |  -0.025509 |    0.008277 |       10000 | paper_id  |     42 |
| E3-k2 - D0   |        -0.003974 |  -0.017109 |    0.008815 |       10000 | paper_id  |     42 |
| E3-k2 - D1   |        -0.003347 |  -0.018465 |    0.012269 |       10000 | paper_id  |     42 |
| E3-k3 - D0   |         0.004393 |  -0.008467 |    0.017454 |       10000 | paper_id  |     42 |
| E3-k3 - D1   |         0.005020 |  -0.010208 |    0.020848 |       10000 | paper_id  |     42 |
| E3-k4 - D0   |        -0.005113 |  -0.018656 |    0.008573 |       10000 | paper_id  |     42 |
| E3-k4 - D1   |        -0.004486 |  -0.018943 |    0.010112 |       10000 | paper_id  |     42 |
| E3-k6 - D0   |         0.000278 |  -0.013954 |    0.014583 |       10000 | paper_id  |     42 |
| E3-k6 - D1   |         0.000905 |  -0.013409 |    0.015910 |       10000 | paper_id  |     42 |
| E3-k8 - D0   |        -0.005707 |  -0.020568 |    0.008933 |       10000 | paper_id  |     42 |
| E3-k8 - D1   |        -0.005080 |  -0.018700 |    0.008935 |       10000 | paper_id  |     42 |

Source: [results/week9/w9e3_senttopk/v1/fit/bootstrap.csv](../repository/results/week9/w9e3_senttopk/v1/fit/bootstrap.csv). First 12 of 15 rows shown; detailed report and source preserve the full comparison.

### Revision / preservation modes primary outcome table

| policy    |   n_queries |       f1 |   exact_match |   delta_f1 |   total_query_prompt_tokens |   num_lm_calls |
|:----------|------------:|---------:|--------------:|-----------:|----------------------------:|---------------:|
| D0        |        1746 | 0.385631 |      0.227950 |   0.000000 |                  940.544101 |       1.000000 |
| F0        |        1746 | 0.390024 |      0.226231 |   0.004393 |                 2026.312715 |       2.000000 |
| F1        |        1746 | 0.387094 |      0.229095 |   0.001463 |                 2097.990263 |       2.000000 |
| F2-A      |        1746 | 0.389616 |      0.231386 |   0.003985 |                 2119.990263 |       2.000000 |
| F2-B      |        1746 | 0.386866 |      0.226231 |   0.001235 |                 2130.990263 |       2.000000 |
| F2-frozen |        1746 | 0.389616 |      0.231386 |   0.003985 |                 2119.990263 |       2.000000 |

Source: [results/week9/w9f_utilization/v1/fit/summary.csv](../repository/results/week9/w9f_utilization/v1/fit/summary.csv).

### Stored bootstrap contrasts; interpret named metric/difference exactly

| comparison     | actual_left   |   point_estimate |   ci95_low |   ci95_high |   resamples | cluster   |   seed | post_selection   | multiplicity_adjusted   |
|:---------------|:--------------|-----------------:|-----------:|------------:|------------:|:----------|-------:|:-----------------|:------------------------|
| F0 - D0        | F0            |         0.004393 |  -0.008467 |    0.017454 |       10000 | paper_id  |     42 | False            | False                   |
| F1 - D0        | F1            |         0.001463 |  -0.002879 |    0.005921 |       10000 | paper_id  |     42 | False            | False                   |
| F1 - F0        | F1            |        -0.002930 |  -0.015381 |    0.009555 |       10000 | paper_id  |     42 | False            | False                   |
| F2-A - D0      | F2-A          |         0.003985 |  -0.000003 |    0.008224 |       10000 | paper_id  |     42 | False            | False                   |
| F2-A - F0      | F2-A          |        -0.000408 |  -0.012923 |    0.011982 |       10000 | paper_id  |     42 | False            | False                   |
| F2-A - F1      | F2-A          |         0.002522 |  -0.000838 |    0.006018 |       10000 | paper_id  |     42 | False            | False                   |
| F2-B - D0      | F2-B          |         0.001235 |  -0.004746 |    0.007241 |       10000 | paper_id  |     42 | False            | False                   |
| F2-B - F0      | F2-B          |        -0.003158 |  -0.015524 |    0.008825 |       10000 | paper_id  |     42 | False            | False                   |
| F2-B - F1      | F2-B          |        -0.000227 |  -0.005026 |    0.004358 |       10000 | paper_id  |     42 | False            | False                   |
| F2-frozen - D0 | F2-A          |         0.003985 |  -0.000003 |    0.008224 |       10000 | paper_id  |     42 | True             | False                   |
| F2-frozen - F0 | F2-A          |        -0.000408 |  -0.012923 |    0.011982 |       10000 | paper_id  |     42 | True             | False                   |
| F2-frozen - F1 | F2-A          |         0.002522 |  -0.000838 |    0.006018 |       10000 | paper_id  |     42 | True             | False                   |

Source: [results/week9/w9f_utilization/v1/fit/bootstrap.csv](../repository/results/week9/w9f_utilization/v1/fit/bootstrap.csv).

## Main scientific conclusions

- Preflight/smoke artifacts exist; model qualification is not downstream quality evaluation. Source: [results/week9/preflight/smoke_summary.json](../repository/results/week9/preflight/smoke_summary.json)
- The frozen configuration is FIXED-5 / SEMANTIC / width20; recall/cost identity is compared before downstream generation. Source: [results/week9/retrieval/fit/w9a_summary.csv](../repository/results/week9/retrieval/fit/w9a_summary.csv), [results/week9/frozen/w9a_frozen_config.json](../repository/results/week9/frozen/w9a_frozen_config.json)
- K0 F10.385631 exceeds fixed K1/K2/K4 point estimates; primary policy remains no intervention. Source: [results/week9/ke_surface/fit/w9b_summary.csv](../repository/results/week9/ke_surface/fit/w9b_summary.csv), [results/week9/frozen/w9b_frozen_config.json](../repository/results/week9/frozen/w9b_frozen_config.json)
- SANE-adapted0.386336 vs DraftSemantic0.385004 is a small gain with one extra LM call; cost-efficient DraftSemantic remains the controlled selector. Source: [results/week9/diagnostics/w9c_k2/selection/fit/w9c_summary.csv](../repository/results/week9/diagnostics/w9c_k2/selection/fit/w9c_summary.csv)
- Query-only D2 F10.368659 and draft-aware D3 0.376936 trail D00.385631; generative extraction does not establish a quality improvement. Source: [results/week9/diagnostics/w9c_k2/extraction/fit/w9d_summary.csv](../repository/results/week9/diagnostics/w9c_k2/extraction/fit/w9d_summary.csv)
- E0/E1-Q/E1-QD/E2 F1 is0.366109/0.382523/0.382099/0.383591, all below D0. Source grounding is not answer correctness. Source: [results/week9/diagnostics/w9c_k2/grounded_faithfulness/v1/budget_128/fit/answer_and_cost_summary.csv](../repository/results/week9/diagnostics/w9c_k2/grounded_faithfulness/v1/budget_128/fit/answer_and_cost_summary.csv)
- E3-k3 is the FIT-selected fixed policy at F10.390024; its +0.004393 versus D0 has CI[−0.008467,0.017454], so superiority is not established. Source: [results/week9/w9e3_senttopk/v1/fit/summary.csv](../repository/results/week9/w9e3_senttopk/v1/fit/summary.csv), [results/week9/w9e3_senttopk/v1/frozen_e3_senttopk.json](../repository/results/week9/w9e3_senttopk/v1/frozen_e3_senttopk.json)
- F0 is an alias of E3-k3 (0.390024); frozen F2-A is0.389616. Paired intervals versus D0/F0 span or nearly span zero; no robust revision breakthrough. Source: [results/week9/w9f_utilization/v1/fit/summary.csv](../repository/results/week9/w9f_utilization/v1/fit/summary.csv), [results/week9/w9f_utilization/v1/frozen_w9f_f2.json](../repository/results/week9/w9f_utilization/v1/frozen_w9f_f2.json)
- Nested paper-OOF logistic/HGB F1 is0.389443/0.389266. Retrospective action-oracle headroom is not evidence that a verifier can learn it. Source: [results/week9/w9g_action_verification/v1/controller_fit_oof/summary.csv](../repository/results/week9/w9g_action_verification/v1/controller_fit_oof/summary.csv), [results/week9/w9g_action_verification/v1/controller_fit_oof/frozen_verifier.json](../repository/results/week9/w9g_action_verification/v1/controller_fit_oof/frozen_verifier.json)
- On1309 TEST queries, W9-PRIMARY F10.372788 trails D00.376655, semantic k60.406446, semantic k80.415539 and BM25_k80.423667. W9-SAFE0.384465 and W9-VERIFY0.379775 are not clear paired improvements. Source: [results/week9/w9h_final/v2/report/summary_quality.csv](../repository/results/week9/w9h_final/v2/report/summary_quality.csv), [results/week9/w9h_final/v2/w9h_pretest_freeze_manifest.json](../repository/results/week9/w9h_final/v2/w9h_pretest_freeze_manifest.json)

## What did NOT work?

Raw/generative evidence intervention fails to establish a robust gain; selector/revision changes are small; frozen primary TEST system trails strong fixed baselines.

## Limitations

Extensive FIT exploration; historical TEST now consumed; whole-system comparisons; cost components not measured end-to-end.

## Decision after this week

Historical final freeze is preserved, without retrospective winner promotion after TEST.

## One-paragraph week takeaway

Preflight/smoke artifacts exist; model qualification is not downstream quality evaluation. The frozen configuration is FIXED-5 / SEMANTIC / width20; recall/cost identity is compared before downstream generation. K0 F10.385631 exceeds fixed K1/K2/K4 point estimates; primary policy remains no intervention. SANE-adapted0.386336 vs DraftSemantic0.385004 is a small gain with one extra LM call; cost-efficient DraftSemantic remains the controlled selector. Query-only D2 F10.368659 and draft-aware D3 0.376936 trail D00.385631; generative extraction does not establish a quality improvement. E0/E1-Q/E1-QD/E2 F1 is0.366109/0.382523/0.382099/0.383591, all below D0. Source grounding is not answer correctness. E3-k3 is the FIT-selected fixed policy at F10.390024; its +0.004393 versus D0 has CI[−0.008467,0.017454], so superiority is not established. F0 is an alias of E3-k3 (0.390024); frozen F2-A is0.389616. Paired intervals versus D0/F0 span or nearly span zero; no robust revision breakthrough. Nested paper-OOF logistic/HGB F1 is0.389443/0.389266. Retrospective action-oracle headroom is not evidence that a verifier can learn it. On1309 TEST queries, W9-PRIMARY F10.372788 trails D00.376655, semantic k60.406446, semantic k80.415539 and BM25_k80.423667. W9-SAFE0.384465 and W9-VERIFY0.379775 are not clear paired improvements.

## Additional primary visualizations

![Recorded experimental figure](../repository/results/week9/w9h_final/v2/report/quality_cost.png)

X-axis is recorded prompt/token cost; y-axis historical TEST answer F1. Distinct reader/checkpoint/interface systems remain whole-system comparisons; this consumed TEST cannot guide further tuning.

Source: [results/week9/w9h_final/v2/report/quality_cost.png](../repository/results/week9/w9h_final/v2/report/quality_cost.png).

# Primary Sources Used

- [configs/week9/w9a.yaml](../repository/configs/week9/w9a.yaml)
- [configs/week9/w9b.yaml](../repository/configs/week9/w9b.yaml)
- [configs/week9/w9c.yaml](../repository/configs/week9/w9c.yaml)
- [configs/week9/w9c_k2_diagnostic.yaml](../repository/configs/week9/w9c_k2_diagnostic.yaml)
- [configs/week9/w9d.yaml](../repository/configs/week9/w9d.yaml)
- [configs/week9/w9d_k2_diagnostic.yaml](../repository/configs/week9/w9d_k2_diagnostic.yaml)
- [configs/week9/w9e.yaml](../repository/configs/week9/w9e.yaml)
- [configs/week9/w9e3_senttopk.yaml](../repository/configs/week9/w9e3_senttopk.yaml)
- [configs/week9/w9e_grounded.yaml](../repository/configs/week9/w9e_grounded.yaml)
- [configs/week9/w9e_grounded_64.yaml](../repository/configs/week9/w9e_grounded_64.yaml)
- [configs/week9/w9f.yaml](../repository/configs/week9/w9f.yaml)
- [configs/week9/w9f_utilization.yaml](../repository/configs/week9/w9f_utilization.yaml)
- [configs/week9/w9g.yaml](../repository/configs/week9/w9g.yaml)
- [configs/week9/w9g_action_verification.yaml](../repository/configs/week9/w9g_action_verification.yaml)
- [configs/week9/w9h.yaml](../repository/configs/week9/w9h.yaml)
- [configs/week9/w9pre_deepseek_nf4_fp32.yaml](../repository/configs/week9/w9pre_deepseek_nf4_fp32.yaml)
- [configs/week9/w9pre_models.yaml](../repository/configs/week9/w9pre_models.yaml)
- notebooks/week9/week9a_semantic_chunking_retrieval.ipynb (`../../../notebooks/week9/week9a_semantic_chunking_retrieval.ipynb`; source dependency not packaged)
- notebooks/week9/week9b_evidence_k_surface.ipynb (`../../../notebooks/week9/week9b_evidence_k_surface.ipynb`; source dependency not packaged)
- notebooks/week9/week9c_selector.ipynb (`../../../notebooks/week9/week9c_selector.ipynb`; source dependency not packaged)
- notebooks/week9/week9d_representation.ipynb (`../../../notebooks/week9/week9d_representation.ipynb`; source dependency not packaged)
- notebooks/week9/week9e_extraction_faithfulness.ipynb (`../../../notebooks/week9/week9e_extraction_faithfulness.ipynb`; source dependency not packaged)
- notebooks/week9/week9f_revision.ipynb (`../../../notebooks/week9/week9f_revision.ipynb`; source dependency not packaged)
- notebooks/week9/week9g_action_verification.ipynb (`../../../notebooks/week9/week9g_action_verification.ipynb`; source dependency not packaged)
- notebooks/week9/week9g_adaptive_ke.ipynb (`../../../notebooks/week9/week9g_adaptive_ke.ipynb`; source dependency not packaged)
- notebooks/week9/week9h_final.ipynb (`../../../notebooks/week9/week9h_final.ipynb`; source dependency not packaged)
- notebooks/week9/week9h_final_evaluation.ipynb (`../../../notebooks/week9/week9h_final_evaluation.ipynb`; source dependency not packaged)
- notebooks/week9/week9pre_model_preflight.ipynb (`../../../notebooks/week9/week9pre_model_preflight.ipynb`; source dependency not packaged)
- [results/week9/diagnostics/w9c_k2/extraction/fit/w9d_summary.csv](../repository/results/week9/diagnostics/w9c_k2/extraction/fit/w9d_summary.csv)
- [results/week9/diagnostics/w9c_k2/grounded_faithfulness/v1/budget_128/fit/answer_and_cost_summary.csv](../repository/results/week9/diagnostics/w9c_k2/grounded_faithfulness/v1/budget_128/fit/answer_and_cost_summary.csv)
- [results/week9/diagnostics/w9c_k2/selection/fit/w9c_summary.csv](../repository/results/week9/diagnostics/w9c_k2/selection/fit/w9c_summary.csv)
- [results/week9/frozen/w9a_frozen_config.json](../repository/results/week9/frozen/w9a_frozen_config.json)
- [results/week9/frozen/w9b_frozen_config.json](../repository/results/week9/frozen/w9b_frozen_config.json)
- [results/week9/ke_surface/fit/w9b_summary.csv](../repository/results/week9/ke_surface/fit/w9b_summary.csv)
- [results/week9/preflight/smoke_summary.json](../repository/results/week9/preflight/smoke_summary.json)
- [results/week9/retrieval/fit/w9a_summary.csv](../repository/results/week9/retrieval/fit/w9a_summary.csv)
- [results/week9/w9e3_senttopk/v1/fit/bootstrap.csv](../repository/results/week9/w9e3_senttopk/v1/fit/bootstrap.csv)
- [results/week9/w9e3_senttopk/v1/fit/summary.csv](../repository/results/week9/w9e3_senttopk/v1/fit/summary.csv)
- [results/week9/w9e3_senttopk/v1/frozen_e3_senttopk.json](../repository/results/week9/w9e3_senttopk/v1/frozen_e3_senttopk.json)
- [results/week9/w9f_utilization/v1/fit/bootstrap.csv](../repository/results/week9/w9f_utilization/v1/fit/bootstrap.csv)
- [results/week9/w9f_utilization/v1/fit/summary.csv](../repository/results/week9/w9f_utilization/v1/fit/summary.csv)
- [results/week9/w9f_utilization/v1/frozen_w9f_f2.json](../repository/results/week9/w9f_utilization/v1/frozen_w9f_f2.json)
- [results/week9/w9g_action_verification/v1/audit_pre_final/independent_bootstrap.csv](../repository/results/week9/w9g_action_verification/v1/audit_pre_final/independent_bootstrap.csv)
- [results/week9/w9g_action_verification/v1/controller_fit_oof/frozen_verifier.json](../repository/results/week9/w9g_action_verification/v1/controller_fit_oof/frozen_verifier.json)
- [results/week9/w9g_action_verification/v1/controller_fit_oof/summary.csv](../repository/results/week9/w9g_action_verification/v1/controller_fit_oof/summary.csv)
- [results/week9/w9g_action_verification/v1/preflight/go_no_go.json](../repository/results/week9/w9g_action_verification/v1/preflight/go_no_go.json)
- [results/week9/w9h_final/v2/report/paired_bootstrap.csv](../repository/results/week9/w9h_final/v2/report/paired_bootstrap.csv)
- [results/week9/w9h_final/v2/report/summary_cost.csv](../repository/results/week9/w9h_final/v2/report/summary_cost.csv)
- [results/week9/w9h_final/v2/report/summary_quality.csv](../repository/results/week9/w9h_final/v2/report/summary_quality.csv)
- [results/week9/w9h_final/v2/w9h_pretest_freeze_manifest.json](../repository/results/week9/w9h_final/v2/w9h_pretest_freeze_manifest.json)

- [results/week9/w9h_final/v2/report/quality_cost.png](../repository/results/week9/w9h_final/v2/report/quality_cost.png)

# Existing Markdown Used as Evidence

NONE


---

## Week 10

Source: [results/weekly_reports/week_10/WeeklySummaryAnalysis.md](../repository/results/weekly_reports/week_10/WeeklySummaryAnalysis.md)

# Week 10 — Summary Analysis

## Objective

Diagnose the retrieval, reader and evidence-interface contributions behind historical RAG/SARA failures without another TEST-driven tuning cycle.

## Experiments performed

| Part            | Question                                                                                  | Status             | Main_result                                                                                                                                                                                                                  |
|:----------------|:------------------------------------------------------------------------------------------|:-------------------|:-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| AUDIT-PREFLIGHT | Can historical source/interface identities be made explicit before interpreting failures? | SMOKE-TESTED       | The verification artifact records27 unit tests and a synthetic/schema smoke; it explicitly says full experiments had not started at that earlier verification point.                                                         |
| R               | Was the semantic retrieval foundation limiting downstream quality?                        | COMPLETED          | At retrieval k10, SFR any/all recall is0.727273/0.522727 versus MiniLM0.636364/0.445455 and BM250.618182/0.431818. SFR/full k6 F10.419880 and SFR/SARA k6 0.421290 are strong points.                                        |
| C               | Does shortening evidence improve a fine-tuned reader relative to full context?            | COMPLETED          | Fine-tuned C-Mistral full F1 is0.407095, SARA_k40.381233, query-selected2560.344075 and lead2560.321490. Full versus SARA interval crosses zero; full exceeds compressed-text modes in these paired C comparisons.           |
| G               | Do evidence-mode results depend on the reader under the public-text interface?            | COMPLETED          | All three G readers are complete on231 queries per action. Full-context F1 is Mistral0.235322, Qwen0.273760, Llama0.289647; qcs256 scores are0.189431/0.211520/0.197178.                                                     |
| D               | Are observed effects stable under the preregistered perturbation/decoding diagnostic?     | PARTIALLY EXECUTED | Full-study metadata records144 D diagnostic generation rows, distinct from the2079-row complete G panel. D_partial_panel_provenance records scope restrictions; do not present it as a full repeated three-reader benchmark. |
| ORACLE-REPORT   | How much headroom remains when choosing observed actions retrospectively?                 | COMPLETED          | C-Mistral exact retrospective oracle F1 is0.525774 versus best fixed full0.407095. This headroom does not establish a learnable policy or a sole bottleneck.                                                                 |

## Key results

### sara configuration crosswalk

| component               | official paper                                                         | official repo                                              | local implementation                                                  | W0-W9 usage                  | exact match?                                   | potentially material?   | evidence/source                                                               | notes                                                                                        |
|:------------------------|:-----------------------------------------------------------------------|:-----------------------------------------------------------|:----------------------------------------------------------------------|:-----------------------------|:-----------------------------------------------|:------------------------|:------------------------------------------------------------------------------|:---------------------------------------------------------------------------------------------|
| Default retriever       | BM25 plus dense experiments                                            | BM25 default                                               | paper-local BM25                                                      | W2/W5 top10                  | family only                                    | yes                     | https://github.com/Ahren09/SARA; src/week2/precompute_dev_embeddings.py       | Tokenization/stemming implementations not proven equivalent                                  |
| QASPER retrievers       | Table12 SFR/BGE/BM25; section3.4 also names multi-qa-mpnet-base-cos-v1 | BM25 pipeline helper                                       | MiniLM ranking/routing                                                | W6-W9                        | no                                             | yes                     | https://arxiv.org/pdf/2507.05633 Table12                                      | Section3.1 names bge-reranker-v2-m3: cross-encoder ambiguity; exact BGE corpus not specified |
| QASPER SFR              | F1=55.44; ROUGE-L=52.93                                                | SFR component                                              | No completed equivalent full-paper SFR retrieval experiment located   | SFR compression/features     | not established                                | yes                     | Paper Table12; src/week2/precompute_dev_embeddings.py                         | Paper scores use different protocol; not expected project scores                             |
| QASPER BGE              | F1=44.47; ROUGE-L=45.24                                                | Dense config inventory                                     | not canonical                                                         | MiniLM is different          | no                                             | yes                     | Paper Table12                                                                 | Do not substitute an arbitrary BGE bi-encoder                                                |
| QASPER BM25             | F1=36.15; ROUGE-L=39.54                                                | BM25                                                       | BM25                                                                  | historical foundation        | family only                                    | yes                     | Paper Table12                                                                 | Not directly comparable with local TEST F1                                                   |
| Compressor encoders     | SFR; Linq-Embed-Mistral; gte-Qwen2-7B-instruct; stella_en_1.5B_v5      | SFR default                                                | SFR cached4096-dimensional vectors                                    | W2 onward                    | family yes                                     | yes                     | Paper Table6/AppendixB.6                                                      | Encoder ablations are separate from retriever ablations                                      |
| Base model              | Mistral plus Llama/Gemma families                                      | Mistral-7B-Instruct-v0.2                                   | same public base, locally trained adapter/projector                   | W0-W9                        | architecture yes; exact paper weights unproven | yes                     | local checkpoint args.json; official README                                   | Hashing local weights establishes identity, not equivalence to paper checkpoint              |
| Query conditioning      | document encoder query-agnostic; query used by refinement              | cached document embedding projector                        | query-agnostic SFR document vector                                    | W2-W9                        | mechanism yes                                  | yes                     | Paper method; src/week2/precompute_dev_embeddings.py                          | Query-aware routing does not make document latent query-conditioned                          |
| Refinement/presentation | iterative relevance/novelty/CSI                                        | current simplified two-method CLI and BM25 helper          | MiniLM subset restored original BM25 rank                             | W6 routing/W9 interventions  | not full paper algorithm                       | yes                     | src/week6/routing.py; paper Algorithm1                                        | Paper and current public CLI expose different workflows                                      |
| Input source handling   | evaluation setup                                                       | rank_documents list branch joins then wraps Document again | list strings mapped separately to Document                            | local canonical pipeline     | no                                             | potentially             | audit/sources/sara_data.py:27; Baselines/SARA-main/src/utils/data_utils.py:27 | Upstream current list branch appears inconsistent; not executed                              |
| Precision               | paper hardware setting                                                 | BF16 default SDPA                                          | historical BF16; later FP16 efficientSDPA                             | W9 revisions vs first passes | not bitwise                                    | potentially             | src/week9/backend.py; src/week9/final_h05/historical_backend.py               | W10 fixes FP16; preserve historical artifacts                                                |
| MiniLM origin           | not a Table12 retriever                                                | not default                                                | W5 cheap pooled semantic allocator encoder; W6 zero-shot route scorer | 97657ca then2133292          | project extension                              | yes                     | git log -S all-MiniLM-L6-v2; src/week5/models.py; src/week6/models.py         | No located prerequisite matched SFR retrieval comparison                                     |

Source: [results/week10/root_cause/v1/sara_configuration_crosswalk.csv](../repository/results/week10/root_cause/v1/sara_configuration_crosswalk.csv).

### All matched retrieval-depth conditions

|   all_recall |   any_recall |   candidate_diversity |   coverage |   duplicate_rate |   k |      mrr |   n_queries |   retrieved_tokens | retriever   |   unmapped_gold_spans |
|-------------:|-------------:|----------------------:|-----------:|-----------------:|----:|---------:|------------:|-------------------:|:------------|----------------------:|
|     0.095455 |     0.127273 |            nan        |   0.127608 |         0.000000 |   1 | 0.269185 |         231 |         200.783550 | BM25        |              0.155844 |
|     0.150000 |     0.209091 |              0.850845 |   0.215886 |         0.000000 |   2 | 0.269185 |         231 |         413.852814 | BM25        |              0.155844 |
|     0.254545 |     0.386364 |              0.862657 |   0.378124 |         0.000000 |   4 | 0.269185 |         231 |         832.277056 | BM25        |              0.155844 |
|     0.345455 |     0.504545 |              0.868114 |   0.509237 |         0.000000 |   6 | 0.269185 |         231 |        1242.727273 | BM25        |              0.155844 |
|     0.395455 |     0.568182 |              0.871672 |   0.586772 |         0.000000 |   8 | 0.269185 |         231 |        1651.398268 | BM25        |              0.155844 |
|     0.431818 |     0.618182 |              0.873878 |   0.650002 |         0.000000 |  10 | 0.269185 |         231 |        2056.406926 | BM25        |              0.155844 |
|     0.072727 |     0.145455 |            nan        |   0.124316 |         0.000000 |   1 | 0.293698 |         231 |         172.943723 | MiniLM      |              0.155844 |
|     0.172727 |     0.272727 |              0.871296 |   0.259924 |         0.000000 |   2 | 0.293698 |         231 |         366.424242 | MiniLM      |              0.155844 |
|     0.263636 |     0.418182 |              0.876615 |   0.406129 |         0.000000 |   4 | 0.293698 |         231 |         755.346320 | MiniLM      |              0.155844 |
|     0.322727 |     0.500000 |              0.878391 |   0.495579 |         0.000000 |   6 | 0.293698 |         231 |        1136.623377 | MiniLM      |              0.155844 |
|     0.409091 |     0.581818 |              0.880485 |   0.593982 |         0.000000 |   8 | 0.293698 |         231 |        1523.688312 | MiniLM      |              0.155844 |
|     0.445455 |     0.636364 |              0.881101 |   0.667897 |         0.000000 |  10 | 0.293698 |         231 |        1909.523810 | MiniLM      |              0.155844 |

Source: [results/week10/root_cause/v1/retrieval_summary.csv](../repository/results/week10/root_cause/v1/retrieval_summary.csv). First 12 of 18 rows shown; detailed report and source preserve the full comparison.

### Matched retrieval/interface answer scores

| run           | action         |   n_queries |       f1 |   exact_match |   mean_prompt_tokens |   mean_generated_tokens |
|:--------------|:---------------|------------:|---------:|--------------:|---------------------:|------------------------:|
| R-BM25-full   | BM25/full/k2   |         231 | 0.299486 |      0.164502 |           495.571429 |               14.419913 |
| R-BM25-full   | BM25/full/k6   |         231 | 0.383935 |      0.186147 |          1348.008658 |               15.748918 |
| R-BM25-full   | BM25/full/k8   |         231 | 0.377042 |      0.186147 |          1768.398268 |               17.489177 |
| R-BM25-full   | BM25/full/k4   |         231 | 0.363272 |      0.194805 |           925.770563 |               15.567100 |
| R-BM25-sara   | BM25/sara/k2   |         231 | 0.297712 |      0.177489 |           545.051948 |               20.341991 |
| R-BM25-sara   | BM25/sara/k6   |         231 | 0.375524 |      0.190476 |          1377.575758 |               17.411255 |
| R-BM25-sara   | BM25/sara/k8   |         231 | 0.382535 |      0.177489 |          1787.943723 |               16.173160 |
| R-BM25-sara   | BM25/sara/k4   |         231 | 0.340516 |      0.186147 |           965.294372 |               15.718615 |
| R-MiniLM-full | MiniLM/full/k2 |         231 | 0.347328 |      0.190476 |           448.134199 |               15.757576 |
| R-MiniLM-full | MiniLM/full/k6 |         231 | 0.389471 |      0.194805 |          1241.956710 |               17.787879 |
| R-MiniLM-full | MiniLM/full/k8 |         231 | 0.397290 |      0.203463 |          1640.761905 |               17.956710 |
| R-MiniLM-full | MiniLM/full/k4 |         231 | 0.382600 |      0.199134 |           848.891775 |               15.523810 |

Source: [results/week10/root_cause/v1/summary.csv](../repository/results/week10/root_cause/v1/summary.csv). First 12 of 24 rows shown; detailed report and source preserve the full comparison.

### Fine-tuned Mistral evidence modes

| run       | action      |   n_queries |       f1 |   exact_match |   mean_prompt_tokens |   mean_generated_tokens |
|:----------|:------------|------------:|---------:|--------------:|---------------------:|------------------------:|
| C-Mistral | sara_k4     |         231 | 0.381233 |      0.199134 |           863.645022 |               18.086580 |
| C-Mistral | lead256     |         231 | 0.321490 |      0.168831 |           338.987013 |               16.974026 |
| C-Mistral | no_evidence |         231 | 0.154569 |      0.103896 |            70.805195 |               27.086580 |
| C-Mistral | qcs256      |         231 | 0.344075 |      0.199134 |           339.155844 |               12.173160 |
| C-Mistral | full        |         231 | 0.407095 |      0.194805 |          1957.636364 |               17.541126 |

Source: [results/week10/root_cause/v1/summary.csv](../repository/results/week10/root_cause/v1/summary.csv).

### Matched C contrasts

| a                     | b                     |   ci_high |    ci_low |     point |
|:----------------------|:----------------------|----------:|----------:|----------:|
| C-Mistral|sara_k4     | C-Mistral|lead256     |  0.100071 |  0.023821 |  0.059743 |
| C-Mistral|sara_k4     | C-Mistral|no_evidence |  0.289511 |  0.165429 |  0.226664 |
| C-Mistral|sara_k4     | C-Mistral|qcs256      |  0.086709 | -0.011186 |  0.037158 |
| C-Mistral|sara_k4     | C-Mistral|full        |  0.012674 | -0.065663 | -0.025862 |
| C-Mistral|lead256     | C-Mistral|full        | -0.042237 | -0.129921 | -0.085605 |
| C-Mistral|no_evidence | C-Mistral|lead256     | -0.111531 | -0.223883 | -0.166921 |
| C-Mistral|no_evidence | C-Mistral|full        | -0.195202 | -0.310302 | -0.252526 |
| C-Mistral|qcs256      | C-Mistral|lead256     |  0.063554 | -0.018719 |  0.022585 |
| C-Mistral|qcs256      | C-Mistral|no_evidence |  0.253808 |  0.127506 |  0.189506 |
| C-Mistral|qcs256      | C-Mistral|full        | -0.019431 | -0.109377 | -0.063020 |

Source: [results/week10/root_cause/v1/bootstrap.csv](../repository/results/week10/root_cause/v1/bootstrap.csv).

### full reader panel summary

| reader   | action      | status   |   n_queries |       f1 |   exact_match |   net_evidence_utility |     HELP |     HURT |   mean_prompt_tokens |   mean_generated_tokens |   generation_cap_hit_rate |   mean_generation_seconds |   lm_calls |   measured_end_to_end_seconds |
|:---------|:------------|:---------|------------:|---------:|--------------:|-----------------------:|---------:|---------:|---------------------:|------------------------:|--------------------------:|--------------------------:|-----------:|------------------------------:|
| Mistral  | no_evidence | COMPLETE |         231 | 0.066586 |      0.000000 |               0.000000 | 0.000000 | 0.000000 |            41.805195 |               21.991342 |                  0.000000 |                  0.665612 |          1 |                           nan |
| Mistral  | full        | COMPLETE |         231 | 0.235322 |      0.004329 |               0.168735 | 0.619048 | 0.129870 |          1928.636364 |               53.207792 |                  0.025974 |                  2.222297 |          1 |                           nan |
| Mistral  | qcs256      | COMPLETE |         231 | 0.189431 |      0.004329 |               0.122845 | 0.493506 | 0.121212 |           310.155844 |               29.900433 |                  0.000000 |                  0.999506 |          1 |                           nan |
| Qwen     | no_evidence | COMPLETE |         231 | 0.073060 |      0.000000 |               0.000000 | 0.000000 | 0.000000 |            42.142857 |               17.744589 |                  0.000000 |                  0.611891 |          1 |                           nan |
| Qwen     | full        | COMPLETE |         231 | 0.273760 |      0.000000 |               0.200700 | 0.662338 | 0.047619 |          1754.246753 |               21.800866 |                  0.000000 |                  1.243445 |          1 |                           nan |
| Qwen     | qcs256      | COMPLETE |         231 | 0.211520 |      0.008658 |               0.138459 | 0.484848 | 0.112554 |           272.818182 |               19.030303 |                  0.000000 |                  0.730902 |          1 |                           nan |
| Llama    | no_evidence | COMPLETE |         231 | 0.068372 |      0.000000 |               0.000000 | 0.000000 | 0.000000 |            65.125541 |               18.623377 |                  0.000000 |                  0.594164 |          1 |                           nan |
| Llama    | full        | COMPLETE |         231 | 0.289647 |      0.034632 |               0.221275 | 0.662338 | 0.086580 |          1750.519481 |               29.645022 |                  0.000000 |                  1.416510 |          1 |                           nan |
| Llama    | qcs256      | COMPLETE |         231 | 0.197178 |      0.025974 |               0.128806 | 0.476190 | 0.121212 |           292.536797 |               18.489177 |                  0.000000 |                  0.672849 |          1 |                           nan |

Source: [results/week10/root_cause/v1/full_reader_panel_summary.csv](../repository/results/week10/root_cause/v1/full_reader_panel_summary.csv).

## Main scientific conclusions

- The verification artifact records27 unit tests and a synthetic/schema smoke; it explicitly says full experiments had not started at that earlier verification point. Source: [results/week10/root_cause/v1/execution_freeze.json](../repository/results/week10/root_cause/v1/execution_freeze.json), [results/week10/root_cause/v1/verification.json](../repository/results/week10/root_cause/v1/verification.json)
- At retrieval k10, SFR any/all recall is0.727273/0.522727 versus MiniLM0.636364/0.445455 and BM250.618182/0.431818. SFR/full k6 F10.419880 and SFR/SARA k6 0.421290 are strong points. Source: [results/week10/root_cause/v1/retrieval_summary.csv](../repository/results/week10/root_cause/v1/retrieval_summary.csv), [results/week10/root_cause/v1/summary.csv](../repository/results/week10/root_cause/v1/summary.csv)
- Fine-tuned C-Mistral full F1 is0.407095, SARA_k40.381233, query-selected2560.344075 and lead2560.321490. Full versus SARA interval crosses zero; full exceeds compressed-text modes in these paired C comparisons. Source: [results/week10/root_cause/v1/summary.csv](../repository/results/week10/root_cause/v1/summary.csv), [results/week10/root_cause/v1/freeze_C.json](../repository/results/week10/root_cause/v1/freeze_C.json)
- All three G readers are complete on231 queries per action. Full-context F1 is Mistral0.235322, Qwen0.273760, Llama0.289647; qcs256 scores are0.189431/0.211520/0.197178. Source: [results/week10/root_cause/v1/full_reader_panel_summary.csv](../repository/results/week10/root_cause/v1/full_reader_panel_summary.csv), [results/week10/root_cause/v1/full_reader_bootstrap.csv](../repository/results/week10/root_cause/v1/full_reader_bootstrap.csv)
- Full-study metadata records144 D diagnostic generation rows, distinct from the2079-row complete G panel. D_partial_panel_provenance records scope restrictions; do not present it as a full repeated three-reader benchmark. Source: [results/week10/root_cause/v1/full_study_summary.json](../repository/results/week10/root_cause/v1/full_study_summary.json), [results/week10/root_cause/v1/D_partial_panel_provenance.json](../repository/results/week10/root_cause/v1/D_partial_panel_provenance.json)
- C-Mistral exact retrospective oracle F1 is0.525774 versus best fixed full0.407095. This headroom does not establish a learnable policy or a sole bottleneck. Source: [results/week10/root_cause/v1/oracle_diagnostics.json](../repository/results/week10/root_cause/v1/oracle_diagnostics.json), [results/week10/root_cause/v1/retrieval_interface_interactions.csv](../repository/results/week10/root_cause/v1/retrieval_interface_interactions.csv)

## What did NOT work?

Compact text modes do not exceed full context here; no isolated latent-vector superiority; no sole-bottleneck inference.

## Limitations

231 historical DEV queries; repeated exploration; gold mapping gaps; public-versus-adapted interface confounds.

## Decision after this week

SFR is retained as the reviewed retrieval foundation; reader/interface isolation motivates broader multi-dataset study.

## One-paragraph week takeaway

The verification artifact records27 unit tests and a synthetic/schema smoke; it explicitly says full experiments had not started at that earlier verification point. At retrieval k10, SFR any/all recall is0.727273/0.522727 versus MiniLM0.636364/0.445455 and BM250.618182/0.431818. SFR/full k6 F10.419880 and SFR/SARA k6 0.421290 are strong points. Fine-tuned C-Mistral full F1 is0.407095, SARA_k40.381233, query-selected2560.344075 and lead2560.321490. Full versus SARA interval crosses zero; full exceeds compressed-text modes in these paired C comparisons. All three G readers are complete on231 queries per action. Full-context F1 is Mistral0.235322, Qwen0.273760, Llama0.289647; qcs256 scores are0.189431/0.211520/0.197178. Full-study metadata records144 D diagnostic generation rows, distinct from the2079-row complete G panel. D_partial_panel_provenance records scope restrictions; do not present it as a full repeated three-reader benchmark. C-Mistral exact retrospective oracle F1 is0.525774 versus best fixed full0.407095. This headroom does not establish a learnable policy or a sole bottleneck.

# Primary Sources Used

- [configs/week10/root_cause_v1.json](../repository/configs/week10/root_cause_v1.json)
- notebooks/week10/week10_root_cause.ipynb (`../../../notebooks/week10/week10_root_cause.ipynb`; source dependency not packaged)
- [results/week10/root_cause/v1/D_partial_panel_provenance.json](../repository/results/week10/root_cause/v1/D_partial_panel_provenance.json)
- [results/week10/root_cause/v1/bootstrap.csv](../repository/results/week10/root_cause/v1/bootstrap.csv)
- [results/week10/root_cause/v1/execution_freeze.json](../repository/results/week10/root_cause/v1/execution_freeze.json)
- [results/week10/root_cause/v1/freeze_C.json](../repository/results/week10/root_cause/v1/freeze_C.json)
- [results/week10/root_cause/v1/freeze_G.json](../repository/results/week10/root_cause/v1/freeze_G.json)
- [results/week10/root_cause/v1/freeze_R.json](../repository/results/week10/root_cause/v1/freeze_R.json)
- [results/week10/root_cause/v1/full_reader_bootstrap.csv](../repository/results/week10/root_cause/v1/full_reader_bootstrap.csv)
- [results/week10/root_cause/v1/full_reader_panel_summary.csv](../repository/results/week10/root_cause/v1/full_reader_panel_summary.csv)
- [results/week10/root_cause/v1/full_study_summary.json](../repository/results/week10/root_cause/v1/full_study_summary.json)
- [results/week10/root_cause/v1/oracle_diagnostics.json](../repository/results/week10/root_cause/v1/oracle_diagnostics.json)
- [results/week10/root_cause/v1/retrieval_interface_interactions.csv](../repository/results/week10/root_cause/v1/retrieval_interface_interactions.csv)
- [results/week10/root_cause/v1/retrieval_summary.csv](../repository/results/week10/root_cause/v1/retrieval_summary.csv)
- [results/week10/root_cause/v1/sara_configuration_crosswalk.csv](../repository/results/week10/root_cause/v1/sara_configuration_crosswalk.csv)
- [results/week10/root_cause/v1/summary.csv](../repository/results/week10/root_cause/v1/summary.csv)
- [results/week10/root_cause/v1/verification.json](../repository/results/week10/root_cause/v1/verification.json)

# Existing Markdown Used as Evidence

NONE


---

## Week 11

Source: [results/weekly_reports/week_11/WeeklySummaryAnalysis.md](../repository/results/weekly_reports/week_11/WeeklySummaryAnalysis.md)

# Week 11 — Summary Analysis

## Objective

Characterize retrieval, evidence granularity, budget, reader and compressor interactions across three tasks before designing a new allocation method.

## Experiments performed

| Part   | Question                                                                              | Status             | Main_result                                                                                                                                                                                                                              |
|:-------|:--------------------------------------------------------------------------------------|:-------------------|:-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 0      | Which dataset/corpus/interface definitions are actually used?                         | COMPLETED          | Fifty label-independent hash-sampled DEV queries per dataset are recorded. HotpotQA uses provided distractor contexts; SciFact retrieves all corpus abstracts, not gold-only documents.                                                  |
| A      | How does retrieval unit size affect annotated-evidence recall and tokens?             | COMPLETED          | Matched passage/sentence/proposition retrieval outputs exist for BM25/MiniLM/SFR. HotpotQA provided contexts create a candidate-corpus ceiling; high recall there is not unrestricted corpus retrieval.                                  |
| B      | Do passage construction choices change recall at comparable depths?                   | COMPLETED          | The72-row representation summary reports P variants with per-dataset recall/token counts; no reader-quality outcome is inferred from retrieval alone.                                                                                    |
| C      | Which fixed evidence granularity works at each budget?                                | PARTIALLY EXECUTED | The111 completed executable conditions cover Qwen granularity/selector/budget choices. This does not establish that sentence/proposition evidence is generally superior to passages.                                                     |
| D      | Does the best granularity change across public readers?                               | PARTIALLY EXECUTED | There are333 executed conditions, but matched additional reader×granularity intervals all cross zero. Reader interactions are suggestive, not generally established.                                                                     |
| E      | Do different evidence compression mechanisms improve quality under a matched budget?  | PARTIALLY EXECUTED | Executed83-condition compressor summary exists. C2 is query-ranked top8 exact sentences; saturation and strict-prefix whole-passage fit failures confound broad compression-quality claims. LLMLingua2 remains pending.                  |
| F      | Are granularity/selection findings robust to the retriever?                           | COMPLETED          | The48-condition robustness surface is executable-complete. SFR is a strong primary choice, but BM25 remains competitive in some cells; no universal retriever superiority is established.                                                |
| G      | Does fixed hierarchical composition improve on strong single-granularity controls?    | PARTIALLY EXECUTED | H3 can improve over coarse raw context at256, but no robust universal advantage over a strong sentence baseline is established; the63 executable conditions retain all H variants.                                                       |
| H      | Is there retrospective action headroom, and which matched interactions are supported? | COMPLETED          | Paired interaction tables are exploratory. Reader×granularity512 intervals cross zero on all three datasets; some budget-related interactions are positive/negative with nonzero intervals. Do not infer a universal reader interaction. |
| I      | Which patterns survive method, task, budget and interface audit?                      | COMPLETED          | The506-condition combined table summarizes existing outputs rather than506 independent new experiments. QA and SciFact metrics remain separate; no pooled cross-task score is computed.                                                  |

## Key results

### dataset summary df

| dataset   | split   |   n_queries | candidate_corpus                                      | synthetic   |   available_queries |
|:----------|:--------|------------:|:------------------------------------------------------|:------------|--------------------:|
| HotpotQA  | dev     |          50 | provided ten distractor paragraphs                    | False       |                7405 |
| QASPER    | dev     |          50 | complete matching scientific paper                    | False       |                 231 |
| SciFact   | dev     |          50 | all corpus abstracts; never only cited/gold documents | False       |                 300 |

Source: [results/week11/multigranular/v1/setup/dataset_summary_df.csv](../repository/results/week11/multigranular/v1/setup/dataset_summary_df.csv).

### model registry df

| model       | id                                                  | revision                                 | status             |   smoke_model_loaded | tokenizer                              | dtype   |   quantization |   max_context |   max_new_tokens | decoding   |       seed |   peak_vram_measured |
|:------------|:----------------------------------------------------|:-----------------------------------------|:-------------------|---------------------:|:---------------------------------------|:--------|---------------:|--------------:|-----------------:|:-----------|-----------:|---------------------:|
| Mistral     | mistralai/Mistral-7B-Instruct-v0.2                  | 63a8b081895390a26e140280378bc85ec8bce07a | CACHED_SNAPSHOT    |             0.000000 | mistralai/Mistral-7B-Instruct-v0.2     | float16 |            nan |   8192.000000 |       128.000000 | greedy     |  42.000000 |                  nan |
| MiniLM      | sentence-transformers/all-MiniLM-L6-v2              | 1110a243fdf4706b3f48f1d95db1a4f5529b4d41 | CACHED_SNAPSHOT    |             0.000000 | sentence-transformers/all-MiniLM-L6-v2 | float32 |            nan |    nan        |       nan        | nan        |  42.000000 |                  nan |
| SFR         | Salesforce/SFR-Embedding-Mistral                    | 33a60fe7b5e00b9414981280c571e8a4f9f42f1b | CACHED_SNAPSHOT    |             0.000000 | Salesforce/SFR-Embedding-Mistral       | float16 |            nan |    nan        |       nan        | nan        |  42.000000 |                  nan |
| Qwen        | Qwen/Qwen3-8B                                       | b968826d9c46dd6066d109eabc6255188de91218 | CACHED_SNAPSHOT    |             0.000000 | Qwen/Qwen3-8B                          | float16 |            nan |   8192.000000 |       128.000000 | greedy     |  42.000000 |                  nan |
| Llama       | meta-llama/Llama-3.1-8B-Instruct                    | 0e9e39f249a16976918f6564b8830bc894c89659 | CACHED_SNAPSHOT    |             0.000000 | meta-llama/Llama-3.1-8B-Instruct       | float16 |            nan |   8192.000000 |       128.000000 | greedy     |  42.000000 |                  nan |
| LLMLingua-2 | microsoft/llmlingua-2-xlm-roberta-large-meetingbank | nan                                      | PENDING_DEPENDENCY |           nan        | nan                                    | nan     |            nan |    nan        |       nan        | nan        | nan        |                  nan |

Source: [results/week11/multigranular/v1/setup/model_registry_df.csv](../repository/results/week11/multigranular/v1/setup/model_registry_df.csv).

### retrieval summary df

| dataset   | retriever   | passage_representation   | evidence_granularity   |   k |   n_queries |   any_gold_recall |   all_gold_recall |   retrieved_tokens |
|:----------|:------------|:-------------------------|:-----------------------|----:|------------:|------------------:|------------------:|-------------------:|
| HotpotQA  | SFR         | P0                       | PROPOSITION            |   1 |          50 |          0.720000 |          0.000000 |          30.160000 |
| HotpotQA  | SFR         | P0                       | PROPOSITION            |   2 |          50 |          0.820000 |          0.120000 |          64.180000 |
| HotpotQA  | SFR         | P0                       | PROPOSITION            |   4 |          50 |          0.920000 |          0.360000 |         123.360000 |
| HotpotQA  | SFR         | P0                       | PROPOSITION            |   6 |          50 |          0.960000 |          0.520000 |         182.180000 |
| HotpotQA  | SFR         | P0                       | PROPOSITION            |   8 |          50 |          0.980000 |          0.620000 |         244.040000 |
| HotpotQA  | SFR         | P0                       | PROPOSITION            |  10 |          50 |          1.000000 |          0.680000 |         302.300000 |
| HotpotQA  | MiniLM      | P0                       | PASSAGE                |   1 |          50 |          0.860000 |          0.000000 |          92.200000 |
| HotpotQA  | MiniLM      | P0                       | PASSAGE                |   2 |          50 |          0.960000 |          0.360000 |         209.840000 |
| HotpotQA  | MiniLM      | P0                       | PASSAGE                |   4 |          50 |          1.000000 |          0.660000 |         488.960000 |
| HotpotQA  | MiniLM      | P0                       | PASSAGE                |   6 |          50 |          1.000000 |          0.800000 |         761.720000 |
| HotpotQA  | MiniLM      | P0                       | PASSAGE                |   8 |          50 |          1.000000 |          0.860000 |        1046.100000 |
| HotpotQA  | MiniLM      | P0                       | PASSAGE                |  10 |          50 |          1.000000 |          1.000000 |        1351.040000 |

Source: [results/week11/multigranular/v1/retrieval/retrieval_summary_df.csv](../repository/results/week11/multigranular/v1/retrieval/retrieval_summary_df.csv). First 12 of 162 rows shown; detailed report and source preserve the full comparison.

### passage representation summary df

| dataset   | retriever   | passage_representation   | evidence_granularity   |   k |   n_queries |   any_gold_recall |   all_gold_recall |   retrieved_tokens |
|:----------|:------------|:-------------------------|:-----------------------|----:|------------:|------------------:|------------------:|-------------------:|
| HotpotQA  | SFR         | P3                       | PASSAGE                |   1 |          50 |          0.940000 |          0.000000 |          95.740000 |
| HotpotQA  | SFR         | P3                       | PASSAGE                |   2 |          50 |          1.000000 |          0.640000 |         228.040000 |
| HotpotQA  | SFR         | P3                       | PASSAGE                |   4 |          50 |          1.000000 |          0.900000 |         516.220000 |
| HotpotQA  | SFR         | P3                       | PASSAGE                |   6 |          50 |          1.000000 |          0.960000 |         813.620000 |
| HotpotQA  | SFR         | P3                       | PASSAGE                |   8 |          50 |          1.000000 |          0.980000 |        1085.980000 |
| HotpotQA  | SFR         | P3                       | PASSAGE                |  10 |          50 |          1.000000 |          1.000000 |        1351.040000 |
| HotpotQA  | SFR         | P0                       | PASSAGE                |   1 |          50 |          0.940000 |          0.000000 |          92.840000 |
| HotpotQA  | SFR         | P0                       | PASSAGE                |   2 |          50 |          1.000000 |          0.660000 |         207.040000 |
| HotpotQA  | SFR         | P0                       | PASSAGE                |   4 |          50 |          1.000000 |          0.880000 |         473.460000 |
| HotpotQA  | SFR         | P0                       | PASSAGE                |   6 |          50 |          1.000000 |          0.940000 |         776.520000 |
| HotpotQA  | SFR         | P0                       | PASSAGE                |   8 |          50 |          1.000000 |          1.000000 |        1048.000000 |
| HotpotQA  | SFR         | P0                       | PASSAGE                |  10 |          50 |          1.000000 |          1.000000 |        1351.040000 |

Source: [results/week11/multigranular/v1/passage_representation/passage_representation_summary_df.csv](../repository/results/week11/multigranular/v1/passage_representation/passage_representation_summary_df.csv). First 12 of 72 rows shown; detailed report and source preserve the full comparison.

### c summary df

| dataset   | reader   | reader_variant     | retriever   | passage_representation   | evidence_granularity   | selector   | budget   | compressor   | strategy   |   n_queries |   task_primary_quality |   classification_accuracy |   invalid_label_rate |   any_gold_recall |   all_gold_recall |   evidence_tokens |   prompt_tokens |
|:----------|:---------|:-------------------|:------------|:-------------------------|:-----------------------|:-----------|:---------|:-------------|:-----------|------------:|-----------------------:|--------------------------:|---------------------:|------------------:|------------------:|------------------:|----------------:|
| HotpotQA  | Qwen     | PUBLIC_TEXT_READER | SFR         | P0                       | PASSAGE                | semantic   | 512      | C0           | FIXED      |          50 |               0.456280 |                       nan |                  nan |          1.000000 |          0.860000 |        389.100000 |      441.920000 |
| HotpotQA  | Qwen     | PUBLIC_TEXT_READER | SFR         | P0                       | SENTENCE               | hybrid     | FULL     | C0           | FIXED      |          50 |               0.405590 |                       nan |                  nan |          1.000000 |          1.000000 |       1351.020000 |     1403.820000 |
| HotpotQA  | Qwen     | PUBLIC_TEXT_READER | SFR         | P0                       | PASSAGE                | hybrid     | FULL     | C0           | FIXED      |          50 |               0.431145 |                       nan |                  nan |          1.000000 |          1.000000 |       1351.060000 |     1403.860000 |
| HotpotQA  | Qwen     | PUBLIC_TEXT_READER | SFR         | P0                       | PROPOSITION            | lexical    | 512      | C0           | FIXED      |          50 |               0.316340 |                       nan |                  nan |          0.960000 |          0.380000 |        424.380000 |      477.180000 |
| HotpotQA  | Qwen     | PUBLIC_TEXT_READER | SFR         | P0                       | NONE                   | none       | 0        | C0           | FIXED      |          50 |               0.150250 |                       nan |                  nan |          0.000000 |          0.000000 |          0.000000 |       52.800000 |
| HotpotQA  | Qwen     | PUBLIC_TEXT_READER | SFR         | P0                       | PASSAGE                | lexical    | FULL     | C0           | FIXED      |          50 |               0.431145 |                       nan |                  nan |          1.000000 |          1.000000 |       1351.060000 |     1403.860000 |
| HotpotQA  | Qwen     | PUBLIC_TEXT_READER | SFR         | P0                       | SENTENCE               | semantic   | 256      | C0           | FIXED      |          50 |               0.421265 |                       nan |                  nan |          0.980000 |          0.600000 |        201.160000 |      253.960000 |
| HotpotQA  | Qwen     | PUBLIC_TEXT_READER | SFR         | P0                       | PROPOSITION            | semantic   | 512      | C0           | FIXED      |          50 |               0.430585 |                       nan |                  nan |          1.000000 |          0.760000 |        426.660000 |      479.460000 |
| HotpotQA  | Qwen     | PUBLIC_TEXT_READER | SFR         | P0                       | PROPOSITION            | semantic   | 256      | C0           | FIXED      |          50 |               0.407943 |                       nan |                  nan |          0.980000 |          0.540000 |        198.300000 |      251.100000 |
| HotpotQA  | Qwen     | PUBLIC_TEXT_READER | SFR         | P0                       | PASSAGE                | hybrid     | 256      | C0           | FIXED      |          50 |               0.384781 |                       nan |                  nan |          0.980000 |          0.440000 |        157.200000 |      210.020000 |
| HotpotQA  | Qwen     | PUBLIC_TEXT_READER | SFR         | P0                       | PASSAGE                | semantic   | 1024     | C0           | FIXED      |          50 |               0.480272 |                       nan |                  nan |          1.000000 |          1.000000 |        798.360000 |      851.160000 |
| HotpotQA  | Qwen     | PUBLIC_TEXT_READER | SFR         | P0                       | SENTENCE               | hybrid     | 512      | C0           | FIXED      |          50 |               0.396624 |                       nan |                  nan |          1.000000 |          0.800000 |        419.780000 |      472.600000 |

Source: [results/week11/multigranular/v1/granularity_budget/c_summary_df.csv](../repository/results/week11/multigranular/v1/granularity_budget/c_summary_df.csv). First 12 of 111 rows shown; detailed report and source preserve the full comparison.

### audited summary

| dataset   | reader   | reader_variant     | retriever   | passage_representation   | evidence_granularity   | selector   | budget   | compressor   | strategy   |   n_queries |   task_primary_quality |   classification_accuracy |   invalid_label_rate |   any_gold_recall |   all_gold_recall |   evidence_tokens |   prompt_tokens |
|:----------|:---------|:-------------------|:------------|:-------------------------|:-----------------------|:-----------|:---------|:-------------|:-----------|------------:|-----------------------:|--------------------------:|---------------------:|------------------:|------------------:|------------------:|----------------:|
| HotpotQA  | Qwen     | PUBLIC_TEXT_READER | SFR         | P0                       | PASSAGE                | semantic   | 512      | C0           | FIXED      |          50 |               0.456280 |                       nan |                  nan |          1.000000 |          0.860000 |        389.100000 |      441.920000 |
| HotpotQA  | Mistral  | PUBLIC_TEXT_READER | SFR         | P0                       | PASSAGE                | lexical    | 256      | C0           | FIXED      |          50 |               0.228822 |                       nan |                  nan |          0.840000 |          0.240000 |        163.660000 |      217.560000 |
| HotpotQA  | Llama    | PUBLIC_TEXT_READER | SFR         | P0                       | PASSAGE                | lexical    | 512      | C0           | FIXED      |          50 |               0.353926 |                       nan |                  nan |          0.940000 |          0.460000 |        357.480000 |      432.920000 |
| HotpotQA  | Qwen     | PUBLIC_TEXT_READER | SFR         | P0                       | SENTENCE               | hybrid     | FULL     | C0           | FIXED      |          50 |               0.405590 |                       nan |                  nan |          1.000000 |          1.000000 |       1351.020000 |     1403.820000 |
| HotpotQA  | Qwen     | PUBLIC_TEXT_READER | SFR         | P0                       | PASSAGE                | hybrid     | FULL     | C0           | FIXED      |          50 |               0.431145 |                       nan |                  nan |          1.000000 |          1.000000 |       1351.060000 |     1403.860000 |
| HotpotQA  | Llama    | PUBLIC_TEXT_READER | SFR         | P0                       | PROPOSITION            | hybrid     | 256      | C0           | FIXED      |          50 |               0.321213 |                       nan |                  nan |          0.960000 |          0.420000 |        193.500000 |      268.940000 |
| HotpotQA  | Mistral  | PUBLIC_TEXT_READER | SFR         | P0                       | PROPOSITION            | lexical    | 1024     | C0           | FIXED      |          50 |               0.275703 |                       nan |                  nan |          1.000000 |          0.740000 |       1001.160000 |     1054.920000 |
| HotpotQA  | Mistral  | PUBLIC_TEXT_READER | SFR         | P0                       | PASSAGE                | hybrid     | 1024     | C0           | FIXED      |          50 |               0.317028 |                       nan |                  nan |          1.000000 |          0.980000 |        933.340000 |      987.200000 |
| HotpotQA  | Mistral  | PUBLIC_TEXT_READER | SFR         | P0                       | PROPOSITION            | lexical    | 512      | C0           | FIXED      |          50 |               0.226394 |                       nan |                  nan |          0.960000 |          0.380000 |        489.800000 |      543.360000 |
| HotpotQA  | Qwen     | PUBLIC_TEXT_READER | SFR         | P0                       | PROPOSITION            | lexical    | 512      | C0           | FIXED      |          50 |               0.316340 |                       nan |                  nan |          0.960000 |          0.380000 |        424.380000 |      477.180000 |
| HotpotQA  | Qwen     | PUBLIC_TEXT_READER | SFR         | P0                       | NONE                   | none       | 0        | C0           | FIXED      |          50 |               0.150250 |                       nan |                  nan |          0.000000 |          0.000000 |          0.000000 |       52.800000 |
| HotpotQA  | Qwen     | PUBLIC_TEXT_READER | SFR         | P0                       | PASSAGE                | lexical    | FULL     | C0           | FIXED      |          50 |               0.431145 |                       nan |                  nan |          1.000000 |          1.000000 |       1351.060000 |     1403.860000 |

Source: [results/week11/multigranular/v1/reader_granularity/audited_summary.csv](../repository/results/week11/multigranular/v1/reader_granularity/audited_summary.csv). First 12 of 333 rows shown; detailed report and source preserve the full comparison.

### named reader granularity interactions

| dataset   | reader   | reference   | budget   | contrast                                            | family                         |     point |    ci_low |   ci_high |   resamples |   seed | cluster           |
|:----------|:---------|:------------|:---------|:----------------------------------------------------|:-------------------------------|----------:|----------:|----------:|------------:|-------:|:------------------|
| HotpotQA  | Mistral  | Qwen        | 1024     | (sentence-passage)_reader - (sentence-passage)_Qwen | additional_posthoc_exploratory | -0.012425 | -0.081771 |  0.053866 |       10000 |     42 | query_or_claim_id |
| HotpotQA  | Mistral  | Qwen        | FULL     | (sentence-passage)_reader - (sentence-passage)_Qwen | additional_posthoc_exploratory |  0.017846 | -0.017028 |  0.061327 |       10000 |     42 | query_or_claim_id |
| HotpotQA  | Llama    | Qwen        | 1024     | (sentence-passage)_reader - (sentence-passage)_Qwen | additional_posthoc_exploratory | -0.081286 | -0.172899 |  0.004410 |       10000 |     42 | query_or_claim_id |
| HotpotQA  | Llama    | Qwen        | FULL     | (sentence-passage)_reader - (sentence-passage)_Qwen | additional_posthoc_exploratory |  0.022373 | -0.024150 |  0.073229 |       10000 |     42 | query_or_claim_id |
| QASPER    | Mistral  | Qwen        | 1024     | (sentence-passage)_reader - (sentence-passage)_Qwen | additional_posthoc_exploratory | -0.016288 | -0.058948 |  0.024116 |       10000 |     42 | paper_id          |
| QASPER    | Mistral  | Qwen        | FULL     | (sentence-passage)_reader - (sentence-passage)_Qwen | additional_posthoc_exploratory |  0.021602 | -0.006623 |  0.049087 |       10000 |     42 | paper_id          |
| QASPER    | Llama    | Qwen        | 1024     | (sentence-passage)_reader - (sentence-passage)_Qwen | additional_posthoc_exploratory |  0.005213 | -0.057551 |  0.058055 |       10000 |     42 | paper_id          |
| QASPER    | Llama    | Qwen        | FULL     | (sentence-passage)_reader - (sentence-passage)_Qwen | additional_posthoc_exploratory |  0.018994 | -0.004856 |  0.043399 |       10000 |     42 | paper_id          |

Source: [results/week11/multigranular/v1/reader_granularity/named_reader_granularity_interactions.csv](../repository/results/week11/multigranular/v1/reader_granularity/named_reader_granularity_interactions.csv).

### label compliance diagnostic summary

| dataset   | reader   | action_id            | evidence_granularity   | selector   | budget   | compressor   |   n_queries |   strict_accuracy |   strict_format_rate |   leading_label_rate |   leading_label_diagnostic_accuracy |   cap_hit_rate |
|:----------|:---------|:---------------------|:-----------------------|:-----------|:---------|:-------------|------------:|------------------:|---------------------:|---------------------:|------------------------------------:|---------------:|
| SciFact   | Llama    | 02a6f3329796db882b78 | PASSAGE                | lexical    | 512      | C0           |          50 |          0.000000 |             0.000000 |             0.880000 |                            0.460000 |       0.140000 |
| SciFact   | Llama    | 0858fdb4f596b5d5397a | PROPOSITION            | hybrid     | 256      | C0           |          50 |          0.000000 |             0.000000 |             1.000000 |                            0.480000 |       0.140000 |
| SciFact   | Llama    | 12dd48b33d6d3fb8d217 | PROPOSITION            | hybrid     | FULL     | C0           |          50 |          0.020000 |             0.040000 |             1.000000 |                            0.400000 |       0.580000 |
| SciFact   | Llama    | 1cc630dda0b5989c8310 | NONE                   | none       | 0        | C0           |          50 |          0.000000 |             0.000000 |             0.300000 |                            0.100000 |       0.540000 |
| SciFact   | Llama    | 1f9927c5b19b040e9fa8 | PROPOSITION            | hybrid     | 512      | C0           |          50 |          0.000000 |             0.000000 |             1.000000 |                            0.460000 |       0.180000 |
| SciFact   | Llama    | 2554cee82fe23d813c59 | SENTENCE               | lexical    | FULL     | C0           |          50 |          0.020000 |             0.040000 |             1.000000 |                            0.420000 |       0.500000 |
| SciFact   | Llama    | 2a1b91b1e87fc54aa7d0 | SENTENCE               | lexical    | 1024     | C0           |          50 |          0.000000 |             0.000000 |             1.000000 |                            0.460000 |       0.440000 |
| SciFact   | Llama    | 4f92bbc7cd98dee5bf6b | PROPOSITION            | semantic   | FULL     | C0           |          50 |          0.020000 |             0.040000 |             1.000000 |                            0.400000 |       0.580000 |
| SciFact   | Llama    | 56b4550963a50e30655b | PASSAGE                | semantic   | FULL     | C0           |          50 |          0.040000 |             0.080000 |             1.000000 |                            0.400000 |       0.640000 |
| SciFact   | Llama    | 57e7e243ac7aaa306295 | PROPOSITION            | lexical    | 256      | C0           |          50 |          0.000000 |             0.000000 |             0.980000 |                            0.480000 |       0.200000 |
| SciFact   | Llama    | 697b94f7392a98f74b3c | SENTENCE               | lexical    | 512      | C0           |          50 |          0.000000 |             0.000000 |             1.000000 |                            0.480000 |       0.240000 |
| SciFact   | Llama    | 6d0ba532daf1b3b5ca05 | PROPOSITION            | hybrid     | 1024     | C0           |          50 |          0.000000 |             0.000000 |             1.000000 |                            0.440000 |       0.460000 |

Source: [results/week11/multigranular/v1/reader_granularity/label_compliance_diagnostic_summary.csv](../repository/results/week11/multigranular/v1/reader_granularity/label_compliance_diagnostic_summary.csv). First 12 of 111 rows shown; detailed report and source preserve the full comparison.

### audited summary

| dataset   | reader   | reader_variant     | retriever   | passage_representation   | evidence_granularity   | selector   | budget   | compressor   | strategy   |   n_queries |   task_primary_quality |   classification_accuracy |   invalid_label_rate |   any_gold_recall |   all_gold_recall |   evidence_tokens |   prompt_tokens |
|:----------|:---------|:-------------------|:------------|:-------------------------|:-----------------------|:-----------|:---------|:-------------|:-----------|------------:|-----------------------:|--------------------------:|---------------------:|------------------:|------------------:|------------------:|----------------:|
| HotpotQA  | Qwen     | PUBLIC_TEXT_READER | SFR         | P0                       | NONE                   | none       | 0        | C0           | FIXED      |          50 |               0.150250 |                       nan |                  nan |          0.000000 |          0.000000 |          0.000000 |       52.800000 |
| HotpotQA  | Llama    | PUBLIC_TEXT_READER | SFR         | P0                       | PASSAGE                | semantic   | 1024     | C0           | FIXED      |          50 |               0.424796 |                       nan |                  nan |          1.000000 |          1.000000 |        762.960000 |      838.400000 |
| HotpotQA  | Qwen     | PUBLIC_TEXT_READER | SFR         | P0                       | PASSAGE                | semantic   | 256      | C0           | FIXED      |          50 |               0.337510 |                       nan |                  nan |          0.980000 |          0.460000 |        165.900000 |      218.700000 |
| HotpotQA  | Mistral  | PUBLIC_TEXT_READER | SFR         | P0                       | NONE                   | none       | 0        | C0           | FIXED      |          50 |               0.100453 |                       nan |                  nan |          0.000000 |          0.000000 |          0.000000 |       53.360000 |
| HotpotQA  | Mistral  | PUBLIC_TEXT_READER | SFR         | P0                       | PASSAGE                | semantic   | 1024     | C0           | FIXED      |          50 |               0.309067 |                       nan |                  nan |          1.000000 |          1.000000 |        903.240000 |      957.060000 |
| HotpotQA  | Qwen     | PUBLIC_TEXT_READER | SFR         | P0                       | SENTENCE               | semantic   | 512      | C2           | FIXED      |          50 |               0.425640 |                       nan |                  nan |          1.000000 |          0.680000 |        260.040000 |      312.840000 |
| HotpotQA  | Mistral  | PUBLIC_TEXT_READER | SFR         | P0                       | PASSAGE                | semantic   | 512      | C0           | FIXED      |          50 |               0.324281 |                       nan |                  nan |          1.000000 |          0.860000 |        439.180000 |      493.060000 |
| HotpotQA  | Llama    | PUBLIC_TEXT_READER | SFR         | P0                       | NONE                   | none       | 0        | C0           | FIXED      |          50 |               0.094824 |                       nan |                  nan |          0.000000 |          0.000000 |          0.000000 |       75.440000 |
| HotpotQA  | Llama    | PUBLIC_TEXT_READER | SFR         | P0                       | SENTENCE               | semantic   | 1024     | C2           | FIXED      |          50 |               0.354328 |                       nan |                  nan |          1.000000 |          0.680000 |        248.920000 |      324.360000 |
| HotpotQA  | Qwen     | PUBLIC_TEXT_READER | SFR         | P0                       | PASSAGE                | semantic   | FULL     | C0           | FIXED      |          50 |               0.431145 |                       nan |                  nan |          1.000000 |          1.000000 |       1351.060000 |     1403.860000 |
| HotpotQA  | Mistral  | PUBLIC_TEXT_READER | SFR         | P0                       | SENTENCE               | semantic   | FULL     | C2           | FIXED      |          50 |               0.254890 |                       nan |                  nan |          1.000000 |          0.680000 |        300.020000 |      353.600000 |
| HotpotQA  | Llama    | PUBLIC_TEXT_READER | SFR         | P0                       | PASSAGE                | semantic   | 256      | C0           | FIXED      |          50 |               0.284481 |                       nan |                  nan |          0.980000 |          0.460000 |        157.560000 |      233.000000 |

Source: [results/week11/multigranular/v1/compressor_reader/audited_summary.csv](../repository/results/week11/multigranular/v1/compressor_reader/audited_summary.csv). First 12 of 83 rows shown; detailed report and source preserve the full comparison.

### condition status df

| dataset   | action_id            | reader   | granularity   | compressor   | status     | reason      |
|:----------|:---------------------|:---------|:--------------|:-------------|:-----------|:------------|
| QASPER    | 44e401eeab48a0c4bcb3 | Mistral  | NONE          | C0           | EXECUTABLE | nan         |
| QASPER    | b4f75e721e90dbb239db | Mistral  | PASSAGE       | C0           | EXECUTABLE | nan         |
| QASPER    | 642251784cef20d8cbf0 | Mistral  | PASSAGE       | C0           | EXECUTABLE | nan         |
| QASPER    | 46c9eec30ae8d7fc6e33 | Mistral  | PASSAGE       | C0           | EXECUTABLE | nan         |
| QASPER    | b25ba8af53973cc179f0 | Mistral  | PASSAGE       | C0           | EXECUTABLE | nan         |
| QASPER    | 9369d7cd9d8b53d9e176 | Mistral  | TOKEN         | C1           | PENDING    | LLMLingua-2 |
| QASPER    | 2024056f3cc177f0d403 | Mistral  | TOKEN         | C1           | PENDING    | LLMLingua-2 |
| QASPER    | 33610a9a9cea82728a17 | Mistral  | TOKEN         | C1           | PENDING    | LLMLingua-2 |
| QASPER    | 196e3e26ada862d1521a | Mistral  | TOKEN         | C1           | PENDING    | LLMLingua-2 |
| QASPER    | b276cd7bae341c426412 | Mistral  | SENTENCE      | C2           | EXECUTABLE | nan         |
| QASPER    | a69728887f07e1133fa5 | Mistral  | SENTENCE      | C2           | EXECUTABLE | nan         |
| QASPER    | 8f4cfef66be1182e8bc8 | Mistral  | SENTENCE      | C2           | EXECUTABLE | nan         |

Source: [results/week11/multigranular/v1/compressor_reader/condition_status_df.csv](../repository/results/week11/multigranular/v1/compressor_reader/condition_status_df.csv). First 12 of 119 rows shown; detailed report and source preserve the full comparison.

## Main scientific conclusions

- Fifty label-independent hash-sampled DEV queries per dataset are recorded. HotpotQA uses provided distractor contexts; SciFact retrieves all corpus abstracts, not gold-only documents. Source: [results/week11/multigranular/v1/setup/dataset_summary_df.csv](../repository/results/week11/multigranular/v1/setup/dataset_summary_df.csv), [results/week11/multigranular/v1/setup/status.json](../repository/results/week11/multigranular/v1/setup/status.json)
- Matched passage/sentence/proposition retrieval outputs exist for BM25/MiniLM/SFR. HotpotQA provided contexts create a candidate-corpus ceiling; high recall there is not unrestricted corpus retrieval. Source: [results/week11/multigranular/v1/retrieval/retrieval_summary_df.csv](../repository/results/week11/multigranular/v1/retrieval/retrieval_summary_df.csv), [results/week11/multigranular/v1/retrieval/status.json](../repository/results/week11/multigranular/v1/retrieval/status.json)
- The72-row representation summary reports P variants with per-dataset recall/token counts; no reader-quality outcome is inferred from retrieval alone. Source: [results/week11/multigranular/v1/passage_representation/passage_representation_summary_df.csv](../repository/results/week11/multigranular/v1/passage_representation/passage_representation_summary_df.csv), [results/week11/multigranular/v1/passage_representation/status.json](../repository/results/week11/multigranular/v1/passage_representation/status.json)
- The111 completed executable conditions cover Qwen granularity/selector/budget choices. This does not establish that sentence/proposition evidence is generally superior to passages. Source: [results/week11/multigranular/v1/granularity_budget/c_summary_df.csv](../repository/results/week11/multigranular/v1/granularity_budget/c_summary_df.csv), [results/week11/multigranular/v1/granularity_budget/status.json](../repository/results/week11/multigranular/v1/granularity_budget/status.json)
- There are333 executed conditions, but matched additional reader×granularity intervals all cross zero. Reader interactions are suggestive, not generally established. Source: [results/week11/multigranular/v1/reader_granularity/audited_summary.csv](../repository/results/week11/multigranular/v1/reader_granularity/audited_summary.csv), [results/week11/multigranular/v1/reader_granularity/status.json](../repository/results/week11/multigranular/v1/reader_granularity/status.json)
- Executed83-condition compressor summary exists. C2 is query-ranked top8 exact sentences; saturation and strict-prefix whole-passage fit failures confound broad compression-quality claims. LLMLingua2 remains pending. Source: [results/week11/multigranular/v1/compressor_reader/audited_summary.csv](../repository/results/week11/multigranular/v1/compressor_reader/audited_summary.csv), [results/week11/multigranular/v1/compressor_reader/status.json](../repository/results/week11/multigranular/v1/compressor_reader/status.json)
- The48-condition robustness surface is executable-complete. SFR is a strong primary choice, but BM25 remains competitive in some cells; no universal retriever superiority is established. Source: [results/week11/multigranular/v1/retriever_robustness/audited_summary.csv](../repository/results/week11/multigranular/v1/retriever_robustness/audited_summary.csv), [results/week11/multigranular/v1/retriever_robustness/status.json](../repository/results/week11/multigranular/v1/retriever_robustness/status.json)
- H3 can improve over coarse raw context at256, but no robust universal advantage over a strong sentence baseline is established; the63 executable conditions retain all H variants. Source: [results/week11/multigranular/v1/hierarchical/audited_summary.csv](../repository/results/week11/multigranular/v1/hierarchical/audited_summary.csv), [results/week11/multigranular/v1/hierarchical/status.json](../repository/results/week11/multigranular/v1/hierarchical/status.json)
- Paired interaction tables are exploratory. Reader×granularity512 intervals cross zero on all three datasets; some budget-related interactions are positive/negative with nonzero intervals. Do not infer a universal reader interaction. Source: [results/week11/multigranular/v1/oracle/paired_interaction_contrasts_df.csv](../repository/results/week11/multigranular/v1/oracle/paired_interaction_contrasts_df.csv), [results/week11/multigranular/v1/oracle/status.json](../repository/results/week11/multigranular/v1/oracle/status.json)
- The506-condition combined table summarizes existing outputs rather than506 independent new experiments. QA and SciFact metrics remain separate; no pooled cross-task score is computed. Source: [results/week11/multigranular/v1/final_report/master_summary_df.csv](../repository/results/week11/multigranular/v1/final_report/master_summary_df.csv), [results/week11/multigranular/v1/final_report/status.json](../repository/results/week11/multigranular/v1/final_report/status.json)

## What did NOT work?

No universal fine-granularity winner, hierarchical winner or reader×granularity interaction. LLMLingua is unqualified/pending in this week, not a completed benchmark.

## Limitations

Only50 queries per dataset; strict-prefix allocator confound, reader output compliance, multiple exploratory comparisons, top8 C2 saturation and whole-system specialist comparisons.

## Decision after this week

The observed task/budget dependence motivates controlled budgeted fusion; any final promotion remains unestablished at this pilot stage.

## One-paragraph week takeaway

Fifty label-independent hash-sampled DEV queries per dataset are recorded. HotpotQA uses provided distractor contexts; SciFact retrieves all corpus abstracts, not gold-only documents. Matched passage/sentence/proposition retrieval outputs exist for BM25/MiniLM/SFR. HotpotQA provided contexts create a candidate-corpus ceiling; high recall there is not unrestricted corpus retrieval. The72-row representation summary reports P variants with per-dataset recall/token counts; no reader-quality outcome is inferred from retrieval alone. The111 completed executable conditions cover Qwen granularity/selector/budget choices. This does not establish that sentence/proposition evidence is generally superior to passages. There are333 executed conditions, but matched additional reader×granularity intervals all cross zero. Reader interactions are suggestive, not generally established. Executed83-condition compressor summary exists. C2 is query-ranked top8 exact sentences; saturation and strict-prefix whole-passage fit failures confound broad compression-quality claims. LLMLingua2 remains pending. The48-condition robustness surface is executable-complete. SFR is a strong primary choice, but BM25 remains competitive in some cells; no universal retriever superiority is established. H3 can improve over coarse raw context at256, but no robust universal advantage over a strong sentence baseline is established; the63 executable conditions retain all H variants. Paired interaction tables are exploratory. Reader×granularity512 intervals cross zero on all three datasets; some budget-related interactions are positive/negative with nonzero intervals. Do not infer a universal reader interaction. The506-condition combined table summarizes existing outputs rather than506 independent new experiments. QA and SciFact metrics remain separate; no pooled cross-task score is computed.

## Additional primary visualizations

![Recorded experimental figure](../repository/results/week11/multigranular/v1/granularity_budget/figures/HotpotQA_task_score_quality_budget.png)

X-axis is evidence budget; y-axis HotpotQA task score (answer F1). It shows granularity/selector-dependent budget behavior on50 pilot queries, not full-corpus retrieval or universal superiority.

Source: [results/week11/multigranular/v1/granularity_budget/figures/HotpotQA_task_score_quality_budget.png](../repository/results/week11/multigranular/v1/granularity_budget/figures/HotpotQA_task_score_quality_budget.png).

# Primary Sources Used

- [configs/week11/week11_base.yaml](../repository/configs/week11/week11_base.yaml)
- [configs/week11/week11_compressors.yaml](../repository/configs/week11/week11_compressors.yaml)
- [configs/week11/week11_datasets.yaml](../repository/configs/week11/week11_datasets.yaml)
- [configs/week11/week11_granularity.yaml](../repository/configs/week11/week11_granularity.yaml)
- [configs/week11/week11_readers.yaml](../repository/configs/week11/week11_readers.yaml)
- [configs/week11/week11_retrievers.yaml](../repository/configs/week11/week11_retrievers.yaml)
- [configs/week11/week11_runs.yaml](../repository/configs/week11/week11_runs.yaml)
- notebooks/week11/week11_0_setup_and_data.ipynb (`../../../notebooks/week11/week11_0_setup_and_data.ipynb`; source dependency not packaged)
- notebooks/week11/week11_A_retrieval_granularity.ipynb (`../../../notebooks/week11/week11_A_retrieval_granularity.ipynb`; source dependency not packaged)
- notebooks/week11/week11_B_passage_representation.ipynb (`../../../notebooks/week11/week11_B_passage_representation.ipynb`; source dependency not packaged)
- notebooks/week11/week11_C_granularity_budget.ipynb (`../../../notebooks/week11/week11_C_granularity_budget.ipynb`; source dependency not packaged)
- notebooks/week11/week11_D_reader_granularity.ipynb (`../../../notebooks/week11/week11_D_reader_granularity.ipynb`; source dependency not packaged)
- notebooks/week11/week11_E_compressor_reader.ipynb (`../../../notebooks/week11/week11_E_compressor_reader.ipynb`; source dependency not packaged)
- notebooks/week11/week11_F_retriever_robustness.ipynb (`../../../notebooks/week11/week11_F_retriever_robustness.ipynb`; source dependency not packaged)
- notebooks/week11/week11_G_hierarchical_fidelity.ipynb (`../../../notebooks/week11/week11_G_hierarchical_fidelity.ipynb`; source dependency not packaged)
- notebooks/week11/week11_H_oracle_and_interactions.ipynb (`../../../notebooks/week11/week11_H_oracle_and_interactions.ipynb`; source dependency not packaged)
- notebooks/week11/week11_I_final_report.ipynb (`../../../notebooks/week11/week11_I_final_report.ipynb`; source dependency not packaged)
- notebooks/week11/week11_MASTER.ipynb (`../../../notebooks/week11/week11_MASTER.ipynb`; source dependency not packaged)
- [results/week11/multigranular/v1/compressor_reader/audited_summary.csv](../repository/results/week11/multigranular/v1/compressor_reader/audited_summary.csv)
- [results/week11/multigranular/v1/compressor_reader/condition_status_df.csv](../repository/results/week11/multigranular/v1/compressor_reader/condition_status_df.csv)
- [results/week11/multigranular/v1/compressor_reader/status.json](../repository/results/week11/multigranular/v1/compressor_reader/status.json)
- [results/week11/multigranular/v1/final_report/master_summary_df.csv](../repository/results/week11/multigranular/v1/final_report/master_summary_df.csv)
- [results/week11/multigranular/v1/final_report/portable_reader_summary_df.csv](../repository/results/week11/multigranular/v1/final_report/portable_reader_summary_df.csv)
- [results/week11/multigranular/v1/final_report/status.json](../repository/results/week11/multigranular/v1/final_report/status.json)
- [results/week11/multigranular/v1/granularity_budget/c_summary_df.csv](../repository/results/week11/multigranular/v1/granularity_budget/c_summary_df.csv)
- [results/week11/multigranular/v1/granularity_budget/status.json](../repository/results/week11/multigranular/v1/granularity_budget/status.json)
- [results/week11/multigranular/v1/hierarchical/audited_summary.csv](../repository/results/week11/multigranular/v1/hierarchical/audited_summary.csv)
- [results/week11/multigranular/v1/hierarchical/condition_status_df.csv](../repository/results/week11/multigranular/v1/hierarchical/condition_status_df.csv)
- [results/week11/multigranular/v1/hierarchical/status.json](../repository/results/week11/multigranular/v1/hierarchical/status.json)
- [results/week11/multigranular/v1/oracle/oracle_summary_df.csv](../repository/results/week11/multigranular/v1/oracle/oracle_summary_df.csv)
- [results/week11/multigranular/v1/oracle/paired_interaction_contrasts_df.csv](../repository/results/week11/multigranular/v1/oracle/paired_interaction_contrasts_df.csv)
- [results/week11/multigranular/v1/oracle/status.json](../repository/results/week11/multigranular/v1/oracle/status.json)
- [results/week11/multigranular/v1/passage_representation/passage_representation_summary_df.csv](../repository/results/week11/multigranular/v1/passage_representation/passage_representation_summary_df.csv)
- [results/week11/multigranular/v1/passage_representation/status.json](../repository/results/week11/multigranular/v1/passage_representation/status.json)
- [results/week11/multigranular/v1/reader_granularity/audited_summary.csv](../repository/results/week11/multigranular/v1/reader_granularity/audited_summary.csv)
- [results/week11/multigranular/v1/reader_granularity/label_compliance_diagnostic_summary.csv](../repository/results/week11/multigranular/v1/reader_granularity/label_compliance_diagnostic_summary.csv)
- [results/week11/multigranular/v1/reader_granularity/named_reader_granularity_interactions.csv](../repository/results/week11/multigranular/v1/reader_granularity/named_reader_granularity_interactions.csv)
- [results/week11/multigranular/v1/reader_granularity/status.json](../repository/results/week11/multigranular/v1/reader_granularity/status.json)
- [results/week11/multigranular/v1/retrieval/retrieval_summary_df.csv](../repository/results/week11/multigranular/v1/retrieval/retrieval_summary_df.csv)
- [results/week11/multigranular/v1/retrieval/status.json](../repository/results/week11/multigranular/v1/retrieval/status.json)
- [results/week11/multigranular/v1/retriever_robustness/audited_summary.csv](../repository/results/week11/multigranular/v1/retriever_robustness/audited_summary.csv)
- [results/week11/multigranular/v1/retriever_robustness/status.json](../repository/results/week11/multigranular/v1/retriever_robustness/status.json)
- [results/week11/multigranular/v1/setup/dataset_summary_df.csv](../repository/results/week11/multigranular/v1/setup/dataset_summary_df.csv)
- [results/week11/multigranular/v1/setup/model_registry_df.csv](../repository/results/week11/multigranular/v1/setup/model_registry_df.csv)
- [results/week11/multigranular/v1/setup/status.json](../repository/results/week11/multigranular/v1/setup/status.json)

- [results/week11/multigranular/v1/granularity_budget/figures/HotpotQA_task_score_quality_budget.png](../repository/results/week11/multigranular/v1/granularity_budget/figures/HotpotQA_task_score_quality_budget.png)

# Existing Markdown Used as Evidence

NONE


---

## Week 12

Source: [results/weekly_reports/week_12/WeeklySummaryAnalysis.md](../repository/results/weekly_reports/week_12/WeeklySummaryAnalysis.md)

# Week 12 — Summary Analysis

## Objective

Validate query-conditioned budgeted granularity fusion under frozen TRAIN/VAL splits, test its mechanisms, freeze a final fallback, then separate post-hoc attribution from reserved confirmation.

## Experiments performed

| Part   | Question                                                                                                     | Status       | Main_result                                                                                                                                                                                                                                                                                                                                                            |
|:-------|:-------------------------------------------------------------------------------------------------------------|:-------------|:-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 0      | Can TRAIN, reused VAL and reserved confirmation roles be frozen without QASPER TEST reuse?                   | COMPLETED    | VAL counts are QASPER1005, HotpotQA7155 and SciFact177. Frozen confirmation is HotpotQA200, SciFact50, QASPER0. Historical QASPER TEST stays closed.                                                                                                                                                                                                                   |
| A      | Can query-conditioned budgeted mixed-granularity optimization be implemented with exact-source evidence?     | SMOKE-TESTED | Algorithm implementation supports exact-source sentences/passages, query-conditioned weights/mass and a hard additive token budget. Quality evidence belongs in C/D, not implementation tests.                                                                                                                                                                         |
| B      | Which controls are qualified before validation and what can qualification establish?                         | SMOKE-TESTED | The qualified optional LLMLingua2 checkpoint is microsoft/llmlingua-2-bert-base-multilingual-cased-meetingbank @5f0c82792b7ea14c6484e015b6a072009496b7f2, not the XLM-R-large checkpoint. Qualification does not establish quality.                                                                                                                                    |
| C      | Does QBGF improve over strong matched fixed evidence policies?                                               | COMPLETED    | QBGF lacks a robust universal VAL advantage. At256 QASPER QBGF0.235515 trails FIXED_SENTENCE0.263430; HotpotQA0.412068 slightly exceeds0.408247; SciFact0.674969 trails0.700062. At1024 passages are competitive or stronger in multiple tasks.                                                                                                                        |
| C-EXT  | How do BM25 and SFR passage controls compare on the same frozen VAL cohorts/budgets?                         | COMPLETED    | The extension has33348 completed logical rows. At1024 HotpotQA SFR RAW_SKIP0.452133 exceeds BM250.435345; SciFact BM250.710716 exceeds SFR0.698979. No universal SFR claim follows.                                                                                                                                                                                    |
| D      | Does query conditioning matter, and is mixed granularity necessary beyond sentence/passages-only allocation? | COMPLETED    | QBGF_FULL exceeds NO_QUERY in all six VAL cells by point estimate; e.g. HotpotQA2560.412068 vs0.308593. Sentence-only nearly duplicates FULL at256, so query conditioning evidence does not establish necessity of fusion.                                                                                                                                             |
| E      | Does the external token compressor improve matched quality/cost?                                             | SKIPPED      | Optional-phase decisions explicitly mark E NOT_RUN_BY_USER_DECISION. A qualified checkpoint exists, but no full LLMLingua quality outcome is established.                                                                                                                                                                                                              |
| F      | Does trained evidence-utilization adaptation improve the reader?                                             | SKIPPED      | Full F training was skipped by explicit recorded decision. Scheduler/coverage implementation and tiny training qualification are not completed final LoRA training.                                                                                                                                                                                                    |
| G      | Does a trained adapter improve the same frozen evidence?                                                     | SKIPPED      | Full G LoRA evaluation was not run; missing adapter results remain unestablished rather than assigned zero.                                                                                                                                                                                                                                                            |
| H      | Is QBGF sufficiently robust to promote as a universal final policy?                                          | COMPLETED    | All51 aggregate validation conditions reproduce from141729 unique C/D rows after16674 matching duplicates are removed. The Part-I freeze retains FIXED_SENTENCE without LoRA; QBGF universal promotion was not established.                                                                                                                                            |
| I      | Were method, reader, budgets and confirmation membership frozen before outcomes?                             | COMPLETED    | Both byte-identical Part-I freezes have SHA d0188a3582d6aead0a3a31f9f15bad9b51a88a6b475b05ac79ae38e58f05366b. FIXED_SENTENCE, no LoRA, five methods and fixed confirmation IDs were frozen.                                                                                                                                                                            |
| J      | Can post-hoc input ablation use a frozen VAL subset without changing the final system?                       | COMPLETED    | A separate150-query/600-cell VAL attribution freeze exists. It compares QBGF and a VAL-selected comparator at both budgets, not fresh confirmation.                                                                                                                                                                                                                    |
| K      | Which selected units change task score when removed or exposed alone?                                        | COMPLETED    | All600 cells completed, with16032 perturbation rows,9607 LOO units and13410 recorded physical calls. Across units687 are helpful,8311 neutral and609 harmful under the signed task-score criterion.                                                                                                                                                                    |
| L      | Does relevance predict utility, and do oracle-ranked subsets reveal redundancy?                              | COMPLETED    | Ten of12 relevance/importance CIs include zero. Corrected finite retention has only6–34 eligible queries per curve; original curve_summary propagates NaN for undefined ratios. Original outputs remain preserved.                                                                                                                                                     |
| M      | Do the frozen policy and validation conclusions generalize to the reserved cohort?                           | COMPLETED    | All2500 rows complete,2213 distinct cached generations. FIXED_SENTENCE exceeds NONE in all four cells after primary-family correction. SciFact256 sentence-minus-RAW_SKIP is+0.28762 [0.09709,0.47206]; at1024 passage point estimates are higher but paired intervals cross zero. QBGF wins HotpotQA1024 by0.03438 with secondary Holm p0.03160; no universal winner. |

## Key results

### Recorded validation counts

| dataset   |   n_queries |
|:----------|------------:|
| HotpotQA  |        7155 |
| QASPER    |        1005 |
| SciFact   |         177 |

Source: [results/week12/qbgf/v3/analysis/summary.csv](../repository/results/week12/qbgf/v3/analysis/summary.csv).

### Frozen confirmation membership counts

| dataset   |   confirmation_queries |
|:----------|-----------------------:|
| HotpotQA  |                    200 |
| QASPER    |                      0 |
| SciFact   |                     50 |

Source: [results/week12/W13_FINAL_METHOD_FREEZE.json](../repository/results/week12/W13_FINAL_METHOD_FREEZE.json).

### Qualification numeric fields; not benchmark scores

| field                                             |       value |
|:--------------------------------------------------|------------:|
| frozen_science_config_unchanged                   |    1.000000 |
| reason                                            |             |
| synthetic_budget_checks[0].budget                 |  256.000000 |
| synthetic_budget_checks[0].compressed_qwen_tokens |  250.000000 |
| synthetic_budget_checks[0].raw_qwen_tokens        | 2041.000000 |
| synthetic_budget_checks[0].retry_factor           |    0.800000 |
| synthetic_budget_checks[0].seconds                |    6.121564 |
| synthetic_budget_checks[1].budget                 | 1024.000000 |
| synthetic_budget_checks[1].compressed_qwen_tokens |  875.000000 |
| synthetic_budget_checks[1].raw_qwen_tokens        | 2041.000000 |
| synthetic_budget_checks[1].retry_factor           |    0.800000 |
| synthetic_budget_checks[1].seconds                |    6.137273 |

Source: [results/week12/qbgf/v3/protocol/llmlingua_qualification_lock.json](../repository/results/week12/qbgf/v3/protocol/llmlingua_qualification_lock.json).

### Main matched VAL outcomes

| dataset   | method         |   budget | reader    |   n_queries |   quality | metric   |   prompt_tokens |   evidence_tokens |     HELP |     HURT |   invalid_outputs |
|:----------|:---------------|---------:|:----------|------------:|----------:|:---------|----------------:|------------------:|---------:|---------:|------------------:|
| HotpotQA  | C2             |      256 | BASE_FP16 |        7155 |  0.411927 | f1       |      274.616492 |        220.700489 | 0.505521 | 0.094060 |                 0 |
| HotpotQA  | FIXED_SENTENCE |     1024 | BASE_FP16 |        7155 |  0.423310 | f1       |     1055.249057 |       1001.333054 | 0.590217 | 0.089727 |                 0 |
| HotpotQA  | FIXED_SENTENCE |      256 | BASE_FP16 |        7155 |  0.408247 | f1       |      308.606569 |        254.690566 | 0.516841 | 0.094200 |                 0 |
| HotpotQA  | H3             |     1024 | BASE_FP16 |        7155 |  0.436421 | f1       |     1041.308875 |        987.392872 | 0.588959 | 0.089727 |                 0 |
| HotpotQA  | H3             |      256 | BASE_FP16 |        7155 |  0.425311 | f1       |      291.398602 |        237.482600 | 0.525227 | 0.092662 |                 0 |
| HotpotQA  | NONE           |     1024 | BASE_FP16 |        7155 |  0.165324 | f1       |       53.916003 |          0.000000 | 0.000000 | 0.000000 |                 0 |
| HotpotQA  | NONE           |      256 | BASE_FP16 |        7155 |  0.165324 | f1       |       53.916003 |          0.000000 | 0.000000 | 0.000000 |                 0 |
| HotpotQA  | QBGF_FULL      |     1024 | BASE_FP16 |        7155 |  0.432344 | f1       |     1047.078127 |        993.162124 | 0.594549 | 0.087072 |                 0 |
| HotpotQA  | QBGF_FULL      |      256 | BASE_FP16 |        7155 |  0.412068 | f1       |      304.758211 |        250.842208 | 0.518658 | 0.096017 |                 0 |
| HotpotQA  | RAW_SKIP       |     1024 | BASE_FP16 |        7155 |  0.452133 | f1       |     1005.667365 |        951.751363 | 0.592453 | 0.082600 |                 0 |
| HotpotQA  | RAW_SKIP       |      256 | BASE_FP16 |        7155 |  0.406974 | f1       |      278.060936 |        224.144934 | 0.496436 | 0.099511 |                 0 |
| QASPER    | C2             |      256 | BASE_FP16 |        1005 |  0.258118 | f1       |      270.380100 |        227.702488 | 0.544279 | 0.103483 |                 0 |

Source: [results/week12/qbgf/v3/analysis/summary.csv](../repository/results/week12/qbgf/v3/analysis/summary.csv). First 12 of 33 rows shown; detailed report and source preserve the full comparison.

### Matched paired contrasts; joint family where recorded

| dataset   |   budget | left      | right          | metric   | status   |     point |    ci_low |   ci_high |   joint_holm_adjusted_p |
|:----------|---------:|:----------|:---------------|:---------|:---------|----------:|----------:|----------:|------------------------:|
| QASPER    |      256 | QBGF_FULL | RAW_SKIP       | f1       | COMPLETE |  0.066233 |  0.048862 |  0.083949 |                0.005099 |
| QASPER    |      256 | QBGF_FULL | FIXED_SENTENCE | f1       | COMPLETE | -0.027915 | -0.040996 | -0.014908 |                0.005099 |
| QASPER    |      256 | QBGF_FULL | H3             | f1       | COMPLETE | -0.018847 | -0.032123 | -0.005551 |                0.163184 |
| QASPER    |     1024 | QBGF_FULL | RAW_SKIP       | f1       | COMPLETE |  0.007098 | -0.003304 |  0.017170 |                1.000000 |
| QASPER    |     1024 | QBGF_FULL | FIXED_SENTENCE | f1       | COMPLETE | -0.003734 | -0.012490 |  0.005008 |                1.000000 |
| QASPER    |     1024 | QBGF_FULL | H3             | f1       | COMPLETE | -0.004432 | -0.012973 |  0.003865 |                1.000000 |
| HotpotQA  |      256 | QBGF_FULL | RAW_SKIP       | f1       | COMPLETE |  0.005094 | -0.002327 |  0.012384 |                1.000000 |
| HotpotQA  |      256 | QBGF_FULL | FIXED_SENTENCE | f1       | COMPLETE |  0.003821 | -0.003511 |  0.011013 |                1.000000 |
| HotpotQA  |      256 | QBGF_FULL | H3             | f1       | COMPLETE | -0.013243 | -0.020821 | -0.005900 |                0.034997 |
| HotpotQA  |     1024 | QBGF_FULL | RAW_SKIP       | f1       | COMPLETE | -0.019789 | -0.024994 | -0.014683 |                0.005099 |
| HotpotQA  |     1024 | QBGF_FULL | FIXED_SENTENCE | f1       | COMPLETE |  0.009033 |  0.004544 |  0.013509 |                0.022198 |
| HotpotQA  |     1024 | QBGF_FULL | H3             | f1       | COMPLETE | -0.004077 | -0.008862 |  0.000724 |                1.000000 |

Source: [results/week12/qbgf/v3/analysis/primary_comparisons.csv](../repository/results/week12/qbgf/v3/analysis/primary_comparisons.csv). First 12 of 18 rows shown; detailed report and source preserve the full comparison.

### Matched Qwen passage-RAG controls

| dataset   | method         |   budget | reader    |   n_queries |   quality |   prompt_tokens |   evidence_tokens | scope               |
|:----------|:---------------|---------:|:----------|------------:|----------:|----------------:|------------------:|:--------------------|
| HotpotQA  | BM25_PLAIN_RAG |     1024 | BASE_FP16 |        7155 |  0.435345 |     1013.819706 |        959.903704 | matched Qwen/budget |
| HotpotQA  | BM25_PLAIN_RAG |      256 | BASE_FP16 |        7155 |  0.379553 |      279.466806 |        225.550804 | matched Qwen/budget |
| HotpotQA  | SFR_PLAIN_RAG  |     1024 | BASE_FP16 |        7155 |  0.452133 |     1005.667365 |        951.751363 | matched Qwen/budget |
| HotpotQA  | SFR_PLAIN_RAG  |      256 | BASE_FP16 |        7155 |  0.406974 |      278.060936 |        224.144934 | matched Qwen/budget |
| QASPER    | BM25_PLAIN_RAG |     1024 | BASE_FP16 |        1005 |  0.255928 |      950.866667 |        908.189055 | matched Qwen/budget |
| QASPER    | BM25_PLAIN_RAG |      256 | BASE_FP16 |        1005 |  0.153388 |      280.466667 |        237.789055 | matched Qwen/budget |
| QASPER    | SFR_PLAIN_RAG  |     1024 | BASE_FP16 |        1005 |  0.287957 |      955.235821 |        912.558209 | matched Qwen/budget |
| QASPER    | SFR_PLAIN_RAG  |      256 | BASE_FP16 |        1005 |  0.169283 |      267.397015 |        224.719403 | matched Qwen/budget |
| SciFact   | BM25_PLAIN_RAG |     1024 | BASE_FP16 |         177 |  0.710716 |     1003.779661 |        938.841808 | matched Qwen/budget |
| SciFact   | BM25_PLAIN_RAG |      256 | BASE_FP16 |         177 |  0.437511 |      248.971751 |        184.033898 | matched Qwen/budget |
| SciFact   | SFR_PLAIN_RAG  |     1024 | BASE_FP16 |         177 |  0.698979 |      998.937853 |        934.000000 | matched Qwen/budget |
| SciFact   | SFR_PLAIN_RAG  |      256 | BASE_FP16 |         177 |  0.456378 |      251.073446 |        186.135593 | matched Qwen/budget |

Source: [results/week12/qbgf/v3/c_extension/v1/analysis/merged_validation_summary.csv](../repository/results/week12/qbgf/v3/c_extension/v1/analysis/merged_validation_summary.csv).

### Full CORE D ablations

| dataset   | method             |   budget | reader    |   n_queries |   quality | metric   |   prompt_tokens |   evidence_tokens |     HELP |     HURT |   invalid_outputs |
|:----------|:-------------------|---------:|:----------|------------:|----------:|:---------|----------------:|------------------:|---------:|---------:|------------------:|
| HotpotQA  | QBGF_FULL          |     1024 | BASE_FP16 |        7155 |  0.432344 | f1       |     1047.078127 |        993.162124 | 0.594549 | 0.087072 |                 0 |
| HotpotQA  | QBGF_FULL          |      256 | BASE_FP16 |        7155 |  0.412068 | f1       |      304.758211 |        250.842208 | 0.518658 | 0.096017 |                 0 |
| HotpotQA  | QBGF_NO_QUERY      |     1024 | BASE_FP16 |        7155 |  0.412252 | f1       |     1044.255625 |        990.339623 | 0.574563 | 0.096995 |                 0 |
| HotpotQA  | QBGF_NO_QUERY      |      256 | BASE_FP16 |        7155 |  0.308593 | f1       |      304.902166 |        250.986164 | 0.394969 | 0.137386 |                 0 |
| HotpotQA  | QBGF_PASSAGE_ONLY  |     1024 | BASE_FP16 |        7155 |  0.452507 | f1       |     1010.822642 |        956.906639 | 0.594829 | 0.083019 |                 0 |
| HotpotQA  | QBGF_PASSAGE_ONLY  |      256 | BASE_FP16 |        7155 |  0.393509 | f1       |      282.667226 |        228.751223 | 0.483578 | 0.106499 |                 0 |
| HotpotQA  | QBGF_SENTENCE_ONLY |     1024 | BASE_FP16 |        7155 |  0.432295 | f1       |     1046.459119 |        992.543117 | 0.594270 | 0.087072 |                 0 |
| HotpotQA  | QBGF_SENTENCE_ONLY |      256 | BASE_FP16 |        7155 |  0.412189 | f1       |      304.756674 |        250.840671 | 0.518658 | 0.096017 |                 0 |
| QASPER    | QBGF_FULL          |     1024 | BASE_FP16 |        1005 |  0.295055 | f1       |     1063.146269 |       1020.468657 | 0.615920 | 0.070647 |                 0 |
| QASPER    | QBGF_FULL          |      256 | BASE_FP16 |        1005 |  0.235515 | f1       |      295.353234 |        252.675622 | 0.519403 | 0.107463 |                 0 |
| QASPER    | QBGF_NO_QUERY      |     1024 | BASE_FP16 |        1005 |  0.228373 | f1       |     1062.479602 |       1019.801990 | 0.525373 | 0.113433 |                 0 |
| QASPER    | QBGF_NO_QUERY      |      256 | BASE_FP16 |        1005 |  0.147303 | f1       |      295.238806 |        252.561194 | 0.364179 | 0.164179 |                 0 |

Source: [results/week12/qbgf/v3/analysis/summary.csv](../repository/results/week12/qbgf/v3/analysis/summary.csv). First 12 of 24 rows shown; detailed report and source preserve the full comparison.

### Mixed versus single-granularity diagnostics

| dataset   |   budget | left      | right              |     point |    ci_low |   ci_high |   joint_holm_adjusted_p |
|:----------|---------:|:----------|:-------------------|----------:|----------:|----------:|------------------------:|
| QASPER    |      256 | QBGF_FULL | QBGF_SENTENCE_ONLY | -0.000069 | -0.000581 |  0.000367 |                1.000000 |
| QASPER    |      256 | QBGF_FULL | QBGF_PASSAGE_ONLY  |  0.066233 |  0.048862 |  0.083949 |                0.005099 |
| QASPER    |     1024 | QBGF_FULL | QBGF_SENTENCE_ONLY | -0.002685 | -0.010267 |  0.004915 |                1.000000 |
| QASPER    |     1024 | QBGF_FULL | QBGF_PASSAGE_ONLY  |  0.005474 | -0.005031 |  0.015607 |                1.000000 |
| HotpotQA  |      256 | QBGF_FULL | QBGF_SENTENCE_ONLY | -0.000121 | -0.000363 |  0.000000 |                1.000000 |
| HotpotQA  |      256 | QBGF_FULL | QBGF_PASSAGE_ONLY  |  0.018559 |  0.011475 |  0.025506 |                0.005099 |
| HotpotQA  |     1024 | QBGF_FULL | QBGF_SENTENCE_ONLY |  0.000049 | -0.001157 |  0.001270 |                1.000000 |
| HotpotQA  |     1024 | QBGF_FULL | QBGF_PASSAGE_ONLY  | -0.020163 | -0.025042 | -0.015425 |                0.005099 |
| SciFact   |      256 | QBGF_FULL | QBGF_SENTENCE_ONLY |  0.000000 |  0.000000 |  0.000000 |                1.000000 |
| SciFact   |      256 | QBGF_FULL | QBGF_PASSAGE_ONLY  |  0.217194 |  0.139681 |  0.298944 |                0.005099 |
| SciFact   |     1024 | QBGF_FULL | QBGF_SENTENCE_ONLY | -0.024280 | -0.051337 | -0.004812 |                1.000000 |
| SciFact   |     1024 | QBGF_FULL | QBGF_PASSAGE_ONLY  |  0.057305 | -0.009679 |  0.127139 |                1.000000 |

Source: [results/week12/qbgf/v3/analysis/fusion_diagnostic_comparisons.csv](../repository/results/week12/qbgf/v3/analysis/fusion_diagnostic_comparisons.csv).

### Offline raw-result recomputation audit

| dataset   | method         |   budget | reader    |    n |   recomputed_quality |   stored_quality |   difference |   recomputed_prompt_tokens |
|:----------|:---------------|---------:|:----------|-----:|---------------------:|-----------------:|-------------:|---------------------------:|
| HotpotQA  | NONE           |      256 | BASE_FP16 | 7155 |             0.165324 |         0.165324 |    -0.000000 |                  53.916003 |
| HotpotQA  | C2             |      256 | BASE_FP16 | 7155 |             0.411927 |         0.411927 |    -0.000000 |                 274.616492 |
| SciFact   | RAW_SKIP       |      256 | BASE_FP16 |  177 |             0.456378 |         0.456378 |     0.000000 |                 251.073446 |
| HotpotQA  | NONE           |     1024 | BASE_FP16 | 7155 |             0.165324 |         0.165324 |    -0.000000 |                  53.916003 |
| HotpotQA  | RAW_SKIP       |     1024 | BASE_FP16 | 7155 |             0.452133 |         0.452133 |    -0.000000 |                1005.667365 |
| HotpotQA  | H3             |     1024 | BASE_FP16 | 7155 |             0.436421 |         0.436421 |    -0.000000 |                1041.308875 |
| QASPER    | NONE           |     1024 | BASE_FP16 | 1005 |             0.082157 |         0.082157 |     0.000000 |                  42.677612 |
| HotpotQA  | H3             |      256 | BASE_FP16 | 7155 |             0.425311 |         0.425311 |    -0.000000 |                 291.398602 |
| QASPER    | RAW_SKIP       |     1024 | BASE_FP16 | 1005 |             0.287957 |         0.287957 |     0.000000 |                 955.235821 |
| HotpotQA  | QBGF_FULL      |     1024 | BASE_FP16 | 7155 |             0.432344 |         0.432344 |    -0.000000 |                1047.078127 |
| HotpotQA  | QBGF_FULL      |      256 | BASE_FP16 | 7155 |             0.412068 |         0.412068 |    -0.000000 |                 304.758211 |
| QASPER    | FIXED_SENTENCE |      256 | BASE_FP16 | 1005 |             0.263430 |         0.263430 |     0.000000 |                 297.893532 |

Source: [results/weekly_reports/week_12/OfflineValidationRecomputation.csv](../repository/results/weekly_reports/week_12/OfflineValidationRecomputation.csv). First 12 of 51 rows shown; detailed report and source preserve the full comparison.

### Exact frozen confirmation registry

| method         | reader    | budgets   |
|:---------------|:----------|:----------|
| NONE           | BASE_FP16 | 256/1024  |
| RAW_SKIP       | BASE_FP16 | 256/1024  |
| FIXED_SENTENCE | BASE_FP16 | 256/1024  |
| H3             | BASE_FP16 | 256/1024  |
| QBGF_FULL      | BASE_FP16 | 256/1024  |

Source: [results/week12/W13_FINAL_METHOD_FREEZE.json](../repository/results/week12/W13_FINAL_METHOD_FREEZE.json).

### Attribution planned cost metadata

| field                                     |        value |
|:------------------------------------------|-------------:|
| causal_ONLY_top3_unknown_until_LOO        |     1.000000 |
| cells                                     |   600.000000 |
| estimated_additional_disk_GiB_upper       |     0.268601 |
| known_LOO_and_relevance_ONLY_unique       | 10505.000000 |
| known_action_cache_reuse_percent          |     0.514041 |
| known_actions_already_cached              |    54.000000 |
| minimum_free_disk_GiB                     |     2.000000 |
| no_evidence_reference_cache_reuse_percent |   100.000000 |
| optional_replacement                      |     0.000000 |
| optional_third_method                     |     0.000000 |
| original_reference_answers                |   600.000000 |
| original_reference_cache_reuse_percent    |   100.000000 |

Source: [results/week12/attribution/v1/cost_plan.json](../repository/results/week12/attribution/v1/cost_plan.json). First 12 of 16 rows shown; detailed report and source preserve the full comparison.

### unit summary

| dataset   |   budget | method            |   n_queries |   n_units |   mean_importance |   median_importance |   helpful |   neutral |   harmful |   mean_query_harmful |     top1 |   top1_tie_aware |     top3 |   top_relevance_negative |   top_relevance_zero |   within_query_rho |   within_query_valid |   exact_answer_flip |   correctness_flip |
|:----------|---------:|:------------------|------------:|----------:|------------------:|--------------------:|----------:|----------:|----------:|---------------------:|---------:|-----------------:|---------:|-------------------------:|---------------------:|-------------------:|---------------------:|--------------------:|-------------------:|
| HotpotQA  |      256 | H3                |          50 |       451 |          0.026659 |            0.000000 |  0.097561 |  0.853659 |  0.048780 |             0.050845 | 0.120000 |         0.600000 | 0.373333 |                 0.080000 |             0.820000 |          -0.015780 |                   32 |            0.268293 |           0.079823 |
| HotpotQA  |      256 | QBGF_FULL         |          50 |       587 |          0.007786 |            0.000000 |  0.088586 |  0.839864 |  0.071550 |             0.070172 | 0.160000 |         0.640000 | 0.280000 |                 0.100000 |             0.660000 |           0.091010 |                   31 |            0.282794 |           0.069847 |
| HotpotQA  |     1024 | QBGF_FULL         |          50 |      1914 |          0.004924 |            0.000000 |  0.050157 |  0.880878 |  0.068966 |             0.068345 | 0.060000 |         0.560000 | 0.120000 |                 0.120000 |             0.720000 |           0.105920 |                   37 |            0.192268 |           0.025601 |
| HotpotQA  |     1024 | QBGF_PASSAGE_ONLY |          50 |       395 |          0.050549 |            0.000000 |  0.131646 |  0.820253 |  0.048101 |             0.047143 | 0.240000 |         0.700000 | 0.453333 |                 0.060000 |             0.560000 |           0.265397 |                   35 |            0.301266 |           0.068354 |
| QASPER    |      256 | FIXED_SENTENCE    |          50 |       467 |          0.014623 |            0.000000 |  0.156317 |  0.764454 |  0.079229 |             0.081342 | 0.220000 |         0.600000 | 0.346667 |                 0.140000 |             0.660000 |           0.154813 |                   30 |            0.404711 |           0.002141 |
| QASPER    |      256 | QBGF_FULL         |          50 |       511 |          0.017406 |            0.000000 |  0.170254 |  0.694716 |  0.135029 |             0.124977 | 0.300000 |         0.600000 | 0.446667 |                 0.280000 |             0.480000 |           0.144183 |                   32 |            0.481409 |           0.003914 |
| QASPER    |     1024 | H3                |          50 |      1824 |          0.000568 |            0.000000 |  0.069627 |  0.870066 |  0.060307 |             0.060853 | 0.160000 |         0.560000 | 0.233333 |                 0.100000 |             0.720000 |           0.069541 |                   32 |            0.240680 |           0.000548 |
| QASPER    |     1024 | QBGF_FULL         |          50 |      1225 |          0.002085 |            0.000000 |  0.079184 |  0.817959 |  0.102857 |             0.090947 | 0.160000 |         0.560000 | 0.253333 |                 0.140000 |             0.660000 |           0.079713 |                   32 |            0.331429 |           0.004082 |
| SciFact   |      256 | C2                |          50 |       267 |          0.007491 |            0.000000 |  0.071161 |  0.865169 |  0.063670 |             0.062333 | 0.180000 |         0.780000 | 0.593333 |                 0.080000 |             0.800000 |           0.024034 |                   22 |            0.138577 |           0.134831 |
| SciFact   |      256 | QBGF_FULL         |          50 |       425 |         -0.021176 |            0.000000 |  0.028235 |  0.922353 |  0.049412 |             0.044968 | 0.200000 |         0.880000 | 0.393333 |                 0.040000 |             0.860000 |           0.131812 |                   16 |            0.082353 |           0.077647 |
| SciFact   |     1024 | BM25_PLAIN_RAG    |          50 |       156 |          0.096154 |            0.000000 |  0.134615 |  0.826923 |  0.038462 |             0.038333 | 0.440000 |         0.840000 | 0.900000 |                 0.080000 |             0.620000 |           0.281316 |                   23 |            0.192308 |           0.173077 |
| SciFact   |     1024 | QBGF_FULL         |          50 |      1385 |         -0.000722 |            0.000000 |  0.005054 |  0.989170 |  0.005776 |             0.005307 | 0.160000 |         0.920000 | 0.160000 |                 0.040000 |             0.880000 |           0.090958 |                   11 |            0.021661 |           0.010830 |

Source: [results/week12/attribution/v1/analysis/unit_summary.csv](../repository/results/week12/attribution/v1/analysis/unit_summary.csv).

### system quality

| dataset   |   budget | method            |   n_queries |   quality |   accuracy |
|:----------|---------:|:------------------|------------:|----------:|-----------:|
| HotpotQA  |      256 | H3                |          50 |  0.387697 | nan        |
| HotpotQA  |      256 | QBGF_FULL         |          50 |  0.404225 | nan        |
| HotpotQA  |     1024 | QBGF_FULL         |          50 |  0.402047 | nan        |
| HotpotQA  |     1024 | QBGF_PASSAGE_ONLY |          50 |  0.451415 | nan        |
| QASPER    |      256 | FIXED_SENTENCE    |          50 |  0.266794 | nan        |
| QASPER    |      256 | QBGF_FULL         |          50 |  0.264119 | nan        |
| QASPER    |     1024 | H3                |          50 |  0.281196 | nan        |
| QASPER    |     1024 | QBGF_FULL         |          50 |  0.296416 | nan        |
| SciFact   |      256 | C2                |          50 |  0.601190 |   0.620000 |
| SciFact   |      256 | QBGF_FULL         |          50 |  0.530994 |   0.540000 |
| SciFact   |     1024 | BM25_PLAIN_RAG    |          50 |  0.712121 |   0.740000 |
| SciFact   |     1024 | QBGF_FULL         |          50 |  0.588105 |   0.640000 |

Source: [results/week12/attribution/v1/analysis/system_quality.csv](../repository/results/week12/attribution/v1/analysis/system_quality.csv).

### relevance utility

| dataset   |   budget | method            |       rho |    ci_low |   ci_high |   pearson_secondary |   valid_bootstrap |   n_units |   n_clusters |   reason |
|:----------|---------:|:------------------|----------:|----------:|----------:|--------------------:|------------------:|----------:|-------------:|---------:|
| HotpotQA  |      256 | H3                |  0.023016 | -0.064932 |  0.109274 |            0.015805 |             10000 |       451 |           50 |      nan |
| HotpotQA  |      256 | QBGF_FULL         |  0.068114 | -0.015664 |  0.148245 |            0.025706 |             10000 |       587 |           50 |      nan |
| HotpotQA  |     1024 | QBGF_FULL         |  0.010000 | -0.089176 |  0.119896 |            0.035762 |             10000 |      1914 |           50 |      nan |
| HotpotQA  |     1024 | QBGF_PASSAGE_ONLY |  0.221220 |  0.138216 |  0.303377 |            0.205209 |             10000 |       395 |           50 |      nan |
| QASPER    |      256 | FIXED_SENTENCE    |  0.126160 | -0.021608 |  0.266764 |            0.050025 |             10000 |       467 |           50 |      nan |
| QASPER    |      256 | QBGF_FULL         |  0.104150 | -0.054446 |  0.246300 |            0.077742 |             10000 |       511 |           50 |      nan |
| QASPER    |     1024 | H3                | -0.027767 | -0.133377 |  0.081273 |            0.075036 |             10000 |      1824 |           50 |      nan |
| QASPER    |     1024 | QBGF_FULL         | -0.034423 | -0.125624 |  0.057194 |            0.034624 |             10000 |      1225 |           50 |      nan |
| SciFact   |      256 | C2                |  0.038219 | -0.129371 |  0.204550 |            0.054169 |             10000 |       267 |           50 |      nan |
| SciFact   |      256 | QBGF_FULL         |  0.134372 |  0.009403 |  0.244331 |            0.148799 |             10000 |       425 |           50 |      nan |
| SciFact   |     1024 | BM25_PLAIN_RAG    |  0.168433 | -0.013400 |  0.338062 |            0.263932 |             10000 |       156 |           50 |      nan |
| SciFact   |     1024 | QBGF_FULL         |  0.044106 | -0.028456 |  0.112701 |            0.063750 |             10000 |      1385 |           50 |      nan |

Source: [results/week12/attribution/v1/analysis/relevance_utility.csv](../repository/results/week12/attribution/v1/analysis/relevance_utility.csv).

### paired harmful effects

| dataset   |   budget | contrast                                                 |      mean |    ci_low |   ci_high |   n |
|:----------|---------:|:---------------------------------------------------------|----------:|----------:|----------:|----:|
| HotpotQA  |      256 | QBGF - comparator harmful unit fraction (query weighted) |  0.019327 | -0.017290 |  0.059550 |  50 |
| HotpotQA  |     1024 | QBGF - comparator harmful unit fraction (query weighted) |  0.021202 | -0.025015 |  0.076183 |  50 |
| QASPER    |      256 | QBGF - comparator harmful unit fraction (query weighted) |  0.043635 | -0.018040 |  0.113949 |  50 |
| QASPER    |     1024 | QBGF - comparator harmful unit fraction (query weighted) |  0.030094 | -0.032109 |  0.093112 |  50 |
| SciFact   |      256 | QBGF - comparator harmful unit fraction (query weighted) | -0.017365 | -0.076314 |  0.040501 |  50 |
| SciFact   |     1024 | QBGF - comparator harmful unit fraction (query weighted) | -0.033027 | -0.069873 | -0.003404 |  50 |

Source: [results/week12/attribution/v1/analysis/paired_harmful_effects.csv](../repository/results/week12/attribution/v1/analysis/paired_harmful_effects.csv).

## Main scientific conclusions

- VAL counts are QASPER1005, HotpotQA7155 and SciFact177. Frozen confirmation is HotpotQA200, SciFact50, QASPER0. Historical QASPER TEST stays closed. Source: [results/week12/W13_FINAL_METHOD_FREEZE.json](../repository/results/week12/W13_FINAL_METHOD_FREEZE.json), [results/week12/qbgf/v3/protocol/training_execution_patch.json](../repository/results/week12/qbgf/v3/protocol/training_execution_patch.json)
- Algorithm implementation supports exact-source sentences/passages, query-conditioned weights/mass and a hard additive token budget. Quality evidence belongs in C/D, not implementation tests. Source: notebooks/week12/week12_A_qbgf_algorithm.ipynb (`../../../notebooks/week12/week12_A_qbgf_algorithm.ipynb`; source dependency not packaged), [src/week12/algorithm.py](../repository/src/week12/algorithm.py)
- The qualified optional LLMLingua2 checkpoint is microsoft/llmlingua-2-bert-base-multilingual-cased-meetingbank @5f0c82792b7ea14c6484e015b6a072009496b7f2, not the XLM-R-large checkpoint. Qualification does not establish quality. Source: [results/week12/qbgf/v3/qualification/baselines.json](../repository/results/week12/qbgf/v3/qualification/baselines.json), [results/week12/qbgf/v3/protocol/llmlingua_qualification_lock.json](../repository/results/week12/qbgf/v3/protocol/llmlingua_qualification_lock.json)
- QBGF lacks a robust universal VAL advantage. At256 QASPER QBGF0.235515 trails FIXED_SENTENCE0.263430; HotpotQA0.412068 slightly exceeds0.408247; SciFact0.674969 trails0.700062. At1024 passages are competitive or stronger in multiple tasks. Source: [results/week12/qbgf/v3/analysis/summary.csv](../repository/results/week12/qbgf/v3/analysis/summary.csv), [results/week12/qbgf/v3/validation/C/status.json](../repository/results/week12/qbgf/v3/validation/C/status.json)
- The extension has33348 completed logical rows. At1024 HotpotQA SFR RAW_SKIP0.452133 exceeds BM250.435345; SciFact BM250.710716 exceeds SFR0.698979. No universal SFR claim follows. Source: [results/week12/qbgf/v3/c_extension/v1/analysis/merged_validation_summary.csv](../repository/results/week12/qbgf/v3/c_extension/v1/analysis/merged_validation_summary.csv), [results/week12/qbgf/v3/c_extension/v1/status.json](../repository/results/week12/qbgf/v3/c_extension/v1/status.json)
- QBGF_FULL exceeds NO_QUERY in all six VAL cells by point estimate; e.g. HotpotQA2560.412068 vs0.308593. Sentence-only nearly duplicates FULL at256, so query conditioning evidence does not establish necessity of fusion. Source: [results/week12/qbgf/v3/analysis/summary.csv](../repository/results/week12/qbgf/v3/analysis/summary.csv), [results/week12/qbgf/v3/analysis/fusion_diagnostic_comparisons.csv](../repository/results/week12/qbgf/v3/analysis/fusion_diagnostic_comparisons.csv)
- Optional-phase decisions explicitly mark E NOT_RUN_BY_USER_DECISION. A qualified checkpoint exists, but no full LLMLingua quality outcome is established. Source: [results/week12/qbgf/v3/protocol/optional_phase_decisions.json](../repository/results/week12/qbgf/v3/protocol/optional_phase_decisions.json), [results/week12/qbgf/v3/protocol/llmlingua_qualification_lock.json](../repository/results/week12/qbgf/v3/protocol/llmlingua_qualification_lock.json)
- Full F training was skipped by explicit recorded decision. Scheduler/coverage implementation and tiny training qualification are not completed final LoRA training. Source: [results/week12/qbgf/v3/protocol/optional_phase_decisions.json](../repository/results/week12/qbgf/v3/protocol/optional_phase_decisions.json), [results/week12/qbgf/v3/protocol/training_execution_patch.json](../repository/results/week12/qbgf/v3/protocol/training_execution_patch.json)
- Full G LoRA evaluation was not run; missing adapter results remain unestablished rather than assigned zero. Source: [results/week12/qbgf/v3/protocol/optional_phase_decisions.json](../repository/results/week12/qbgf/v3/protocol/optional_phase_decisions.json)
- All51 aggregate validation conditions reproduce from141729 unique C/D rows after16674 matching duplicates are removed. The Part-I freeze retains FIXED_SENTENCE without LoRA; QBGF universal promotion was not established. Source: [results/week12/qbgf/v3/analysis/summary.csv](../repository/results/week12/qbgf/v3/analysis/summary.csv), [results/week12/qbgf/v3/analysis/primary_comparisons.csv](../repository/results/week12/qbgf/v3/analysis/primary_comparisons.csv)
- Both byte-identical Part-I freezes have SHA d0188a3582d6aead0a3a31f9f15bad9b51a88a6b475b05ac79ae38e58f05366b. FIXED_SENTENCE, no LoRA, five methods and fixed confirmation IDs were frozen. Source: [results/week12/W13_FINAL_METHOD_FREEZE.json](../repository/results/week12/W13_FINAL_METHOD_FREEZE.json), [results/week12/qbgf/v3/W13_FINAL_METHOD_FREEZE.json](../repository/results/week12/qbgf/v3/W13_FINAL_METHOD_FREEZE.json)
- A separate150-query/600-cell VAL attribution freeze exists. It compares QBGF and a VAL-selected comparator at both budgets, not fresh confirmation. Source: [results/week12/attribution/ATTRIBUTION_QUERY_FREEZE.json](../repository/results/week12/attribution/ATTRIBUTION_QUERY_FREEZE.json), [results/week12/attribution/v1/cost_plan.json](../repository/results/week12/attribution/v1/cost_plan.json)
- All600 cells completed, with16032 perturbation rows,9607 LOO units and13410 recorded physical calls. Across units687 are helpful,8311 neutral and609 harmful under the signed task-score criterion. Source: [results/week12/attribution/v1/status.json](../repository/results/week12/attribution/v1/status.json), [results/week12/attribution/v1/analysis/unit_importance.csv](../repository/results/week12/attribution/v1/analysis/unit_importance.csv)
- Ten of12 relevance/importance CIs include zero. Corrected finite retention has only6–34 eligible queries per curve; original curve_summary propagates NaN for undefined ratios. Original outputs remain preserved. Source: [results/week12/attribution/v1/analysis/relevance_utility.csv](../repository/results/week12/attribution/v1/analysis/relevance_utility.csv), [results/week12/attribution/v1/analysis/paired_harmful_effects.csv](../repository/results/week12/attribution/v1/analysis/paired_harmful_effects.csv)
- All2500 rows complete,2213 distinct cached generations. FIXED_SENTENCE exceeds NONE in all four cells after primary-family correction. SciFact256 sentence-minus-RAW_SKIP is+0.28762 [0.09709,0.47206]; at1024 passage point estimates are higher but paired intervals cross zero. QBGF wins HotpotQA1024 by0.03438 with secondary Holm p0.03160; no universal winner. Source: [results/week12/final_confirmation/v1/summary.csv](../repository/results/week12/final_confirmation/v1/summary.csv), [results/week12/final_confirmation/v1/contrasts.csv](../repository/results/week12/final_confirmation/v1/contrasts.csv)

## What did NOT work?

Fusion is not shown necessary beyond sentence-only at tight budgets; skipped LLMLingua/LoRA outcomes remain missing; numerous paired differences are uncertain.

## Limitations

VAL reused for model selection; post-hoc attribution;250-query two-task confirmation with43 SciFact groups and no fresh QASPER; no universal method, latency or internal-reasoning claim.

## Decision after this week

FIXED_SENTENCE remains frozen; QBGF universal promotion is not established. Confirmation wins in particular cells are reported without retroactive promotion.

## One-paragraph week takeaway

VAL counts are QASPER1005, HotpotQA7155 and SciFact177. Frozen confirmation is HotpotQA200, SciFact50, QASPER0. Historical QASPER TEST stays closed. Algorithm implementation supports exact-source sentences/passages, query-conditioned weights/mass and a hard additive token budget. Quality evidence belongs in C/D, not implementation tests. The qualified optional LLMLingua2 checkpoint is microsoft/llmlingua-2-bert-base-multilingual-cased-meetingbank @5f0c82792b7ea14c6484e015b6a072009496b7f2, not the XLM-R-large checkpoint. Qualification does not establish quality. QBGF lacks a robust universal VAL advantage. At256 QASPER QBGF0.235515 trails FIXED_SENTENCE0.263430; HotpotQA0.412068 slightly exceeds0.408247; SciFact0.674969 trails0.700062. At1024 passages are competitive or stronger in multiple tasks. The extension has33348 completed logical rows. At1024 HotpotQA SFR RAW_SKIP0.452133 exceeds BM250.435345; SciFact BM250.710716 exceeds SFR0.698979. No universal SFR claim follows. QBGF_FULL exceeds NO_QUERY in all six VAL cells by point estimate; e.g. HotpotQA2560.412068 vs0.308593. Sentence-only nearly duplicates FULL at256, so query conditioning evidence does not establish necessity of fusion. Optional-phase decisions explicitly mark E NOT_RUN_BY_USER_DECISION. A qualified checkpoint exists, but no full LLMLingua quality outcome is established. Full F training was skipped by explicit recorded decision. Scheduler/coverage implementation and tiny training qualification are not completed final LoRA training. Full G LoRA evaluation was not run; missing adapter results remain unestablished rather than assigned zero. All51 aggregate validation conditions reproduce from141729 unique C/D rows after16674 matching duplicates are removed. The Part-I freeze retains FIXED_SENTENCE without LoRA; QBGF universal promotion was not established. Both byte-identical Part-I freezes have SHA d0188a3582d6aead0a3a31f9f15bad9b51a88a6b475b05ac79ae38e58f05366b. FIXED_SENTENCE, no LoRA, five methods and fixed confirmation IDs were frozen. A separate150-query/600-cell VAL attribution freeze exists. It compares QBGF and a VAL-selected comparator at both budgets, not fresh confirmation. All600 cells completed, with16032 perturbation rows,9607 LOO units and13410 recorded physical calls. Across units687 are helpful,8311 neutral and609 harmful under the signed task-score criterion. Ten of12 relevance/importance CIs include zero. Corrected finite retention has only6–34 eligible queries per curve; original curve_summary propagates NaN for undefined ratios. Original outputs remain preserved. All2500 rows complete,2213 distinct cached generations. FIXED_SENTENCE exceeds NONE in all four cells after primary-family correction. SciFact256 sentence-minus-RAW_SKIP is+0.28762 [0.09709,0.47206]; at1024 passage point estimates are higher but paired intervals cross zero. QBGF wins HotpotQA1024 by0.03438 with secondary Holm p0.03160; no universal winner.

# Primary Sources Used

- [configs/week12/protocol.yaml](../repository/configs/week12/protocol.yaml)
- notebooks/week12/week12_0_protocol_and_split_audit.ipynb (`../../../notebooks/week12/week12_0_protocol_and_split_audit.ipynb`; source dependency not packaged)
- notebooks/week12/week12_A_qbgf_algorithm.ipynb (`../../../notebooks/week12/week12_A_qbgf_algorithm.ipynb`; source dependency not packaged)
- notebooks/week12/week12_B_baseline_qualification.ipynb (`../../../notebooks/week12/week12_B_baseline_qualification.ipynb`; source dependency not packaged)
- notebooks/week12/week12_C_EXT_baseline_extension.ipynb (`../../../notebooks/week12/week12_C_EXT_baseline_extension.ipynb`; source dependency not packaged)
- notebooks/week12/week12_C_validation_surface.ipynb (`../../../notebooks/week12/week12_C_validation_surface.ipynb`; source dependency not packaged)
- notebooks/week12/week12_D_qbgf_ablations.ipynb (`../../../notebooks/week12/week12_D_qbgf_ablations.ipynb`; source dependency not packaged)
- notebooks/week12/week12_E_llmlingua2.ipynb (`../../../notebooks/week12/week12_E_llmlingua2.ipynb`; source dependency not packaged)
- notebooks/week12/week12_F_lora_training.ipynb (`../../../notebooks/week12/week12_F_lora_training.ipynb`; source dependency not packaged)
- notebooks/week12/week12_G_lora_validation.ipynb (`../../../notebooks/week12/week12_G_lora_validation.ipynb`; source dependency not packaged)
- notebooks/week12/week12_H_validation_analysis.ipynb (`../../../notebooks/week12/week12_H_validation_analysis.ipynb`; source dependency not packaged)
- notebooks/week12/week12_I_week13_freeze.ipynb (`../../../notebooks/week12/week12_I_week13_freeze.ipynb`; source dependency not packaged)
- notebooks/week12/week12_J_attribution_setup.ipynb (`../../../notebooks/week12/week12_J_attribution_setup.ipynb`; source dependency not packaged)
- notebooks/week12/week12_K_causal_evidence_ablation.ipynb (`../../../notebooks/week12/week12_K_causal_evidence_ablation.ipynb`; source dependency not packaged)
- notebooks/week12/week12_L_attribution_analysis.ipynb (`../../../notebooks/week12/week12_L_attribution_analysis.ipynb`; source dependency not packaged)
- notebooks/week12/week12_M_final_confirmation.ipynb (`../../../notebooks/week12/week12_M_final_confirmation.ipynb`; source dependency not packaged)
- [results/week12/W13_FINAL_METHOD_FREEZE.json](../repository/results/week12/W13_FINAL_METHOD_FREEZE.json)
- [results/week12/attribution/ATTRIBUTION_QUERY_FREEZE.json](../repository/results/week12/attribution/ATTRIBUTION_QUERY_FREEZE.json)
- [results/week12/attribution/v1/analysis/CLOSEOUT_AUDIT.json](../repository/results/week12/attribution/v1/analysis/CLOSEOUT_AUDIT.json)
- [results/week12/attribution/v1/analysis/curve_summary.csv](../repository/results/week12/attribution/v1/analysis/curve_summary.csv)
- [results/week12/attribution/v1/analysis/finite_retention_summary.csv](../repository/results/week12/attribution/v1/analysis/finite_retention_summary.csv)
- [results/week12/attribution/v1/analysis/paired_harmful_effects.csv](../repository/results/week12/attribution/v1/analysis/paired_harmful_effects.csv)
- [results/week12/attribution/v1/analysis/relevance_utility.csv](../repository/results/week12/attribution/v1/analysis/relevance_utility.csv)
- [results/week12/attribution/v1/analysis/system_quality.csv](../repository/results/week12/attribution/v1/analysis/system_quality.csv)
- [results/week12/attribution/v1/analysis/unit_importance.csv](../repository/results/week12/attribution/v1/analysis/unit_importance.csv)
- [results/week12/attribution/v1/analysis/unit_summary.csv](../repository/results/week12/attribution/v1/analysis/unit_summary.csv)
- [results/week12/attribution/v1/cost_plan.json](../repository/results/week12/attribution/v1/cost_plan.json)
- [results/week12/attribution/v1/status.json](../repository/results/week12/attribution/v1/status.json)
- [results/week12/final_confirmation/v1/FINAL_CLOSEOUT_AUDIT.json](../repository/results/week12/final_confirmation/v1/FINAL_CLOSEOUT_AUDIT.json)
- [results/week12/final_confirmation/v1/complete.json](../repository/results/week12/final_confirmation/v1/complete.json)
- [results/week12/final_confirmation/v1/contrasts.csv](../repository/results/week12/final_confirmation/v1/contrasts.csv)
- [results/week12/final_confirmation/v1/figures/paired_contrasts.png](../repository/results/week12/final_confirmation/v1/figures/paired_contrasts.png)
- [results/week12/final_confirmation/v1/figures/quality_by_budget.png](../repository/results/week12/final_confirmation/v1/figures/quality_by_budget.png)
- [results/week12/final_confirmation/v1/summary.csv](../repository/results/week12/final_confirmation/v1/summary.csv)
- [results/week12/final_confirmation/v1/validation_comparison.csv](../repository/results/week12/final_confirmation/v1/validation_comparison.csv)
- [results/week12/qbgf/v3/W13_FINAL_METHOD_FREEZE.json](../repository/results/week12/qbgf/v3/W13_FINAL_METHOD_FREEZE.json)
- [results/week12/qbgf/v3/analysis/fusion_diagnostic_comparisons.csv](../repository/results/week12/qbgf/v3/analysis/fusion_diagnostic_comparisons.csv)
- [results/week12/qbgf/v3/analysis/primary_comparisons.csv](../repository/results/week12/qbgf/v3/analysis/primary_comparisons.csv)
- [results/week12/qbgf/v3/analysis/summary.csv](../repository/results/week12/qbgf/v3/analysis/summary.csv)
- [results/week12/qbgf/v3/c_extension/v1/analysis/merged_validation_summary.csv](../repository/results/week12/qbgf/v3/c_extension/v1/analysis/merged_validation_summary.csv)
- [results/week12/qbgf/v3/c_extension/v1/status.json](../repository/results/week12/qbgf/v3/c_extension/v1/status.json)
- [results/week12/qbgf/v3/protocol/llmlingua_qualification_lock.json](../repository/results/week12/qbgf/v3/protocol/llmlingua_qualification_lock.json)
- [results/week12/qbgf/v3/protocol/optional_phase_decisions.json](../repository/results/week12/qbgf/v3/protocol/optional_phase_decisions.json)
- [results/week12/qbgf/v3/protocol/training_execution_patch.json](../repository/results/week12/qbgf/v3/protocol/training_execution_patch.json)
- [results/week12/qbgf/v3/qualification/baselines.json](../repository/results/week12/qbgf/v3/qualification/baselines.json)
- [results/week12/qbgf/v3/validation/C/status.json](../repository/results/week12/qbgf/v3/validation/C/status.json)
- [results/week12/qbgf/v3/validation/D/status.json](../repository/results/week12/qbgf/v3/validation/D/status.json)
- [results/weekly_reports/week_12/OfflineValidationRecomputation.csv](../repository/results/weekly_reports/week_12/OfflineValidationRecomputation.csv)
- [results/weekly_reports/week_12/OfflineValidationRecomputation.json](../repository/results/weekly_reports/week_12/OfflineValidationRecomputation.json)
- [src/week12/algorithm.py](../repository/src/week12/algorithm.py)

# Existing Markdown Used as Evidence

NONE


---

## Week 13

Source: [results/weekly_reports/week_13/WeeklySummaryAnalysis.md](../repository/results/weekly_reports/week_13/WeeklySummaryAnalysis.md)

# Week 13 — Summary Analysis

## Objective

Disambiguate the historical Week13 confirmation wrapper from executed Week12 Part M.

## Experiments performed

| Part           | Question                                              | Status                  | Main_result                                                                                                                                                                                                            |
|:---------------|:------------------------------------------------------|:------------------------|:-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| LEGACY-WRAPPER | Was a distinct Week13 scientific experiment executed? | HISTORICAL / SUPERSEDED | A historical scripts/week13/run_confirmation.py entry point exists, but no separate results/week13 experiment directory was located. Executed final confirmation is Week12 M and is not duplicated as a Week13 result. |

## Key results

## Main scientific conclusions

- A historical scripts/week13/run_confirmation.py entry point exists, but no separate results/week13 experiment directory was located. Executed final confirmation is Week12 M and is not duplicated as a Week13 result. Source: scripts/week13/run_confirmation.py (`../../../scripts/week13/run_confirmation.py`; source dependency not packaged), [src/week12/confirmation.py](../repository/src/week12/confirmation.py)

## What did NOT work?

No completed separate Week13 result artifact was found.

## Limitations

Historical naming ambiguity only; no new outcome is inferred.

## Decision after this week

Use Week12 M for the final confirmation outcome; do not count it twice.

## One-paragraph week takeaway

A historical scripts/week13/run_confirmation.py entry point exists, but no separate results/week13 experiment directory was located. Executed final confirmation is Week12 M and is not duplicated as a Week13 result.

# Primary Sources Used

- scripts/week13/run_confirmation.py (`../../../scripts/week13/run_confirmation.py`; source dependency not packaged)
- [src/week12/confirmation.py](../repository/src/week12/confirmation.py)

# Existing Markdown Used as Evidence

NONE

