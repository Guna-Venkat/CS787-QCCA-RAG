# PPT source priority

Start with [FINAL_RESULTS_CHEATSHEET.md](FINAL_RESULTS_CHEATSHEET.md) and [RESEARCH_TIMELINE.md](RESEARCH_TIMELINE.md). These are source aids, not slides.

## MUST READ — 18 original sources

1. [results/FINAL_PROJECT_REPORT.md](../repository/results/FINAL_PROJECT_REPORT.md)
2. [results/PROJECT_GLOSSARY_AND_METRICS.md](../repository/results/PROJECT_GLOSSARY_AND_METRICS.md)
3. [results/weekly_reports/ProjectWideConsistencyAudit.csv](../repository/results/weekly_reports/ProjectWideConsistencyAudit.csv)
4. [results/weekly_reports/week_01/WeeklySummaryAnalysis.md](../repository/results/weekly_reports/week_01/WeeklySummaryAnalysis.md)
5. [results/week10/root_cause/v1/W10_FINAL_REPORT.md](../repository/results/week10/root_cause/v1/W10_FINAL_REPORT.md)
6. [results/weekly_reports/week_11/WeeklySummaryAnalysis.md](../repository/results/weekly_reports/week_11/WeeklySummaryAnalysis.md)
7. [results/week12/W12_C_AND_C_EXT_RESULTS.md](../repository/results/week12/W12_C_AND_C_EXT_RESULTS.md)
8. [results/week12/W12_D_ABLATION_RESULTS.md](../repository/results/week12/W12_D_ABLATION_RESULTS.md)
9. [results/week12/W12_H_FINAL_REVIEW.md](../repository/results/week12/W12_H_FINAL_REVIEW.md)
10. [results/week12/W12_I_FINAL_FREEZE_REPORT.md](../repository/results/week12/W12_I_FINAL_FREEZE_REPORT.md)
11. [results/week12/W13_FINAL_METHOD_FREEZE.json](../repository/results/week12/W13_FINAL_METHOD_FREEZE.json)
12. [results/week12/final_confirmation/v1/week12_M_final_confirmation_report.md](../repository/results/week12/final_confirmation/v1/week12_M_final_confirmation_report.md)
13. [results/week12/final_confirmation/v1/summary.csv](../repository/results/week12/final_confirmation/v1/summary.csv)
14. [results/week12/final_confirmation/v1/contrasts.csv](../repository/results/week12/final_confirmation/v1/contrasts.csv)
15. [results/week12/W12_K_L_ATTRIBUTION_REPORT.md](../repository/results/week12/W12_K_L_ATTRIBUTION_REPORT.md)
16. [demo/APPLICATION_GUIDE.md](../repository/demo/APPLICATION_GUIDE.md)
17. [demo/audit/FINAL_DEMO_CORRECTNESS_AUDIT.md](../repository/demo/audit/FINAL_DEMO_CORRECTNESS_AUDIT.md)
18. [demo/audit/qasper_frozen_splitter_impact.md](../repository/demo/audit/qasper_frozen_splitter_impact.md)

## SHOULD READ

- [All weeks summary](ALL_WEEKS_SUMMARY.md) and [95-part experiment register](ALL_EXPERIMENTS_REGISTER.csv).
- [Complete final table appendix](FINAL_TABLES_COMPLETE.md) and [table catalog](RESULT_TABLE_CATALOG.csv).
- [results/week12/qbgf/v3/analysis/summary.csv](../repository/results/week12/qbgf/v3/analysis/summary.csv)
- [results/week12/qbgf/v3/analysis/primary_comparisons.csv](../repository/results/week12/qbgf/v3/analysis/primary_comparisons.csv)
- [results/week12/qbgf/v3/analysis/fusion_diagnostic_comparisons.csv](../repository/results/week12/qbgf/v3/analysis/fusion_diagnostic_comparisons.csv)
- [results/week12/qbgf/v3/c_extension/v1/analysis/merged_validation_summary.csv](../repository/results/week12/qbgf/v3/c_extension/v1/analysis/merged_validation_summary.csv)
- [docs/week9/W9E_COMPLETE_RESULTS_ANALYSIS.md](../repository/docs/week9/W9E_COMPLETE_RESULTS_ANALYSIS.md)
- [demo/audit/qbgf_score_scale_audit.md](../repository/demo/audit/qbgf_score_scale_audit.md)
- [demo/audit/world_cup_correctness_v2/WORLD_CUP_12_CONDITION_REPORT.md](../repository/demo/audit/world_cup_correctness_v2/WORLD_CUP_12_CONDITION_REPORT.md)
- [demo/audit/demo_reproducibility_status.md](../repository/demo/audit/demo_reproducibility_status.md)

## OPTIONAL / HISTORICAL

- [Complete all-weeks part-wise volume](ALL_WEEKS_COMPLETE_RESULTS.md): every audited detailed report including negative findings, not a recommended main-slide dump.
- Archived smoke/prototype results and early reports: retain provenance labels.
- RECOMP/SARA papers and baseline READMEs: architecture/background, not proof locally reproduced scores.
- POST-W9 DAFiR: [current progress](POST_W9_PROGRESS.md), unfinished optional direction.
- Original project plans: proposed work, not evidence that all phases ran.
