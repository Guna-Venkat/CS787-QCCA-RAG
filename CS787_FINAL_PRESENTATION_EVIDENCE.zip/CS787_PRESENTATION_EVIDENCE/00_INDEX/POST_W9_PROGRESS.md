# POST-W9 DAFiR progress snapshot

This is optional, unfinished additional work. Retrieval artifacts and eligibility checks are not answer-quality results. Counts below are file-system metadata at packaging time; no final-role questions, labels or predictions are loaded by this progress check.

| Role | Eligible_queries | Technical_exclusions | SFR_retrieval_shards | BM25_retrieval_shards | Answer_shards |
| --- | --- | --- | --- | --- | --- |
| train_fit | 2054 | 13 | 563 | 563 | 0 |
| train_dev | 521 | 5 | 0 | 0 | 0 |
| final_test | Not audited / still locked | Not inspected | 0 | 0 | 0 |

[POST W9/audit/SHORT_PAPER_FIX.md](../repository/POST%20W9/audit/SHORT_PAPER_FIX.md)

No QA F1/EM conclusion is inferred from these counts. Full run/training was not started by this packaging task.
