# Research narrative timeline

Use research questions and controlled contrasts as the presentation narrative rather than titling slides Week 1, Week 2, etc. The exact original 95-part register is in [ALL_EXPERIMENTS_REGISTER.csv](ALL_EXPERIMENTS_REGISTER.csv).

## 1. Motivation

A fixed context budget cannot reflect heterogeneous questions; first ask how much explicit/latent evidence to expose.

Source: [results/weekly_reports/week_00/WeeklySummaryAnalysis.md](../repository/results/weekly_reports/week_00/WeeklySummaryAnalysis.md)

## 2. Baseline qualification

Reproduce SARA/plain RAG interfaces and training artifacts; distinguish RECOMP checkout from locally executed evidence.

Source: [results/weekly_reports/week_01/WeeklySummaryAnalysis.md](../repository/results/weekly_reports/week_01/WeeklySummaryAnalysis.md)

## 3. Adaptive-size hypothesis

Fixed k sweeps and retrospective oracles show headroom; learned budget controllers do not reliably recover it.

Source: [results/weekly_reports/week_05/WeeklySummaryAnalysis.md](../repository/results/weekly_reports/week_05/WeeklySummaryAnalysis.md)

## 4. Selection and drafts

Passage identity and draft-aware promotion show some signal, but added calls and HELP/HURT cancellation limit gains.

Source: [results/weekly_reports/week_08/WeeklySummaryAnalysis.md](../repository/results/weekly_reports/week_08/WeeklySummaryAnalysis.md)

## 5. Suppression versus extraction

Raw chunks and generative extraction fail to produce robust deployable gains; simple sentence suppression motivates better representation control.

Source: [docs/week9/W9E_COMPLETE_RESULTS_ANALYSIS.md](../repository/docs/week9/W9E_COMPLETE_RESULTS_ANALYSIS.md)

## 6. Retriever/reader diagnosis

Separate SFR, reader checkpoint, prompt/interface and evidence representation; no single latent-vector cause is isolated.

Source: [results/week10/root_cause/v1/W10_FINAL_REPORT.md](../repository/results/week10/root_cause/v1/W10_FINAL_REPORT.md)

## 7. Granularity pilot

Explore datasets, readers and budgets; sentence/whole-passage rankings depend on the setting, with important packing and output-format confounds.

Source: [results/weekly_reports/week_11/WeeklySummaryAnalysis.md](../repository/results/weekly_reports/week_11/WeeklySummaryAnalysis.md)

## 8. Propose QBGF

Use query-conditioned relevance and a shared budget to choose representation fidelity; compare to strong simple controls.

Source: [results/week12/W12_C_AND_C_EXT_RESULTS.md](../repository/results/week12/W12_C_AND_C_EXT_RESULTS.md)

## 9. Ablate allocation/fusion

Query conditioning helps allocation, while FULL versus SENTENCE_ONLY does not establish consistent fusion benefit.

Source: [results/week12/W12_D_ABLATION_RESULTS.md](../repository/results/week12/W12_D_ABLATION_RESULTS.md)

## 10. Freeze before confirmation

Reject universal QBGF promotion under registered gates; retain FIXED_SENTENCE with no final LoRA.

Source: [results/week12/W12_I_FINAL_FREEZE_REPORT.md](../repository/results/week12/W12_I_FINAL_FREEZE_REPORT.md)

## 11. Post-hoc explanation

Leave-one-out importance is often zero and relevance is weakly/contextually aligned; no internal reasoning or universal causal interpretation.

Source: [results/week12/W12_K_L_ATTRIBUTION_REPORT.md](../repository/results/week12/W12_K_L_ATTRIBUTION_REPORT.md)

## 12. Reserved confirmation

Strong evidence benefit repeats; tight-budget SciFact sentences help; 1024-token passages are competitive; QBGF wins a specific HotpotQA cell without changing the frozen decision.

Source: [results/week12/final_confirmation/v1/week12_M_final_confirmation_report.md](../repository/results/week12/final_confirmation/v1/week12_M_final_confirmation_report.md)

## 13. Demo and fidelity audits

Curated saved examples plus custom operational stages; compare two runs, inspect source units and input budget, retain custom-reference diagnostics separately.

Source: [demo/APPLICATION_GUIDE.md](../repository/demo/APPLICATION_GUIDE.md)

## 14. Optional unfinished DAFiR

Revisit stronger SFR with original SARA fidelity/promotion under a separate official-TRAIN/official-validation protocol; current cache progress is not a scientific result.

Source: [POST W9/README.md](../repository/POST%20W9/README.md)

