# Final results cheat sheet — exact saved values for presentation preparation

Snapshot: 4 November 2026, branch `gagan`. No new experiment or model evaluation was executed for this archive. Scores below are read from saved CSVs, not estimated from plots. Use each source’s cohort and task metric; no pooled cross-dataset quality score.

## Research question

Which retrieved evidence should a constrained reader see, at what granularity and fidelity, under a shared input-evidence token budget? The project evolved from adaptive explicit/latent SARA context size to evidence selection, representation and utilization.

## Final pipeline

`query → pinned SFR top-10 retrieval → FIXED_SENTENCE selection under 256/1024 evidence tokens → Qwen/Qwen3-8B BASE_FP16 → frozen task parser/evaluator`.

No final LoRA was retained. Budgets limit selected **input evidence**, not the generated answer or total prompt. Prompt tokens add query/instructions/framing. QBGF is the proposed method under study; FIXED_SENTENCE is the policy actually frozen by the validation gate.

## Datasets

| Dataset | Final VAL queries / groups | Fresh reserved confirmation queries / groups | Metric |
|---|---:|---:|---|
| QASPER | 1,005 / 281 | 0 / 0 | answer F1; EM secondary |
| HotpotQA | 7,155 / 7,155 | 200 / 200 | answer F1; EM secondary |
| SciFact | 177 / 157 | 50 / 43 | aggregate three-class macro-F1; accuracy secondary |

W11 is an exploratory 50-query/dataset pilot, not W12 full VAL. Early local QASPER DEV has 231 queries; Week8 FIT/INTERNAL-VAL has 1,746/342. These are not interchangeable cohorts. HotpotQA uses provided distractor paragraphs, not unrestricted Wikipedia retrieval. Historical QASPER TEST (1,309 queries) was consumed in W9 and is not fresh. Reserved confirmation is now consumed too.

## Retrievers

BM25 lexical, MiniLM compact semantic encoder (earlier weeks), and pinned Salesforce/SFR-Embedding-Mistral (final primary). SFR is strong, but BM25 remains competitive in some cells. SFR is not MiniLM; do not mislabel early MiniLM outcomes as SFR. Fine-grained LiveDemo controlled comparisons use common SFR downstream scoring after candidate retrieval.

## Readers

Early SARA uses adapted Mistral plus its learned latent projector. Later diagnosis compares Qwen, Mistral and Llama. Final matched C/D/confirmation uses Qwen3-8B BASE_FP16. SARA specialist results remain separate because checkpoint, adaptation and evidence interface differ. Qwen’s final SciFact parser compliance differs from format-failing earlier reader panels.

## Evidence methods

- NONE: no supplied evidence.
- RAW_SKIP: whole passages in candidate order, skipping those that do not fit. This is **budget-matched passage RAG**, not unrestricted RAG.
- FIXED_SENTENCE: query-selected exact sentence units packed under the budget with source order restored.
- C2: earlier query-ranked top-eight exact-sentence control; not confirmed in M.
- H3: fixed hierarchical representation control.
- QBGF_FULL: jointly choose DROP / selected-sentence fidelity / FULL per source under a shared token budget.
- QBGF_NO_QUERY: removes query conditioning **from allocation**, while retaining the query-dependent SFR pool.
- QBGF_SENTENCE_ONLY / PASSAGE_ONLY: remove the other representation options to test whether fusion is necessary.

MCKP/knapsack is an established optimization formulation, not a novel algorithm invented by this project. For full definitions and formulas use the packaged glossary and application guide.

## Main quantitative results — full validation

| Dataset | Budget | Metric | NONE | RAW_SKIP | FIXED_SENTENCE | H3 | QBGF_FULL |
| --- | --- | --- | --- | --- | --- | --- | --- |
| QASPER | 256 | answer F1 | 0.082157 | 0.169283 | 0.263430 | 0.254363 | 0.235515 |
| QASPER | 1024 | answer F1 | 0.082157 | 0.287957 | 0.298788 | 0.299487 | 0.295055 |
| HotpotQA | 256 | answer F1 | 0.165324 | 0.406974 | 0.408247 | 0.425311 | 0.412068 |
| HotpotQA | 1024 | answer F1 | 0.165324 | 0.452133 | 0.423310 | 0.436421 | 0.432344 |
| SciFact | 256 | macro-F1 | 0.420662 | 0.456378 | 0.700062 | 0.685627 | 0.674969 |
| SciFact | 1024 | macro-F1 | 0.420662 | 0.698979 | 0.670398 | 0.685904 | 0.660413 |

Source: [results/week12/qbgf/v3/analysis/summary.csv](../repository/results/week12/qbgf/v3/analysis/summary.csv)

Complete matched C/C-EXT/D validation includes 51 deduplicated core conditions / 141,729 rows, with C-EXT matched passage controls and separate specialist references. Do not count reused D FULL answers or the SFR RAW_SKIP extension alias as independent replications. C2 is not evaluated at every large-budget condition. Use the complete H report/merged source for all controls.

## Confirmation results — strongest final held-out evidence

| Dataset | Budget | Metric | NONE | RAW_SKIP | FIXED_SENTENCE | H3 | QBGF_FULL |
| --- | --- | --- | --- | --- | --- | --- | --- |
| HotpotQA | 256 | answer F1 | 0.139915 | 0.422667 | 0.437333 | 0.462229 | 0.440625 |
| HotpotQA | 1024 | answer F1 | 0.139915 | 0.458917 | 0.432860 | 0.456997 | 0.467244 |
| SciFact | 256 | macro-F1 | 0.368612 | 0.413803 | 0.701420 | 0.706667 | 0.687037 |
| SciFact | 1024 | macro-F1 | 0.368612 | 0.767959 | 0.744048 | 0.716822 | 0.634615 |

Source: [results/week12/final_confirmation/v1/summary.csv](../repository/results/week12/final_confirmation/v1/summary.csv)

Completion: 2,500 logical rows; five frozen systems × two budgets × 250 queries; 2,213 distinct cached generations. Every logical system retains its conceptual prompt/call cost. No rows were dropped or replaced in M.

### All predefined confirmation contrasts

| Dataset | Budget | Contrast | Family | Delta | CI_low | CI_high | Holm_p | Queries | Groups |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| HotpotQA | 256 | FIXED_SENTENCE − NONE | primary | 0.297417 | 0.242421 | 0.352422 | 0.000800 | 200 | 200 |
| HotpotQA | 1024 | FIXED_SENTENCE − NONE | primary | 0.292945 | 0.242142 | 0.345230 | 0.000800 | 200 | 200 |
| HotpotQA | 256 | FIXED_SENTENCE − RAW_SKIP | primary | 0.014665 | -0.035671 | 0.065005 | 1.000000 | 200 | 200 |
| HotpotQA | 1024 | FIXED_SENTENCE − RAW_SKIP | primary | -0.026057 | -0.056891 | 0.004897 | 0.284372 | 200 | 200 |
| HotpotQA | 256 | FIXED_SENTENCE − QBGF_FULL | secondary | -0.003293 | -0.043690 | 0.037329 | 1.000000 | 200 | 200 |
| HotpotQA | 1024 | FIXED_SENTENCE − QBGF_FULL | secondary | -0.034384 | -0.059710 | -0.010043 | 0.031597 | 200 | 200 |
| SciFact | 256 | FIXED_SENTENCE − NONE | primary | 0.332808 | 0.138637 | 0.514209 | 0.012599 | 50 | 43 |
| SciFact | 1024 | FIXED_SENTENCE − NONE | primary | 0.375436 | 0.190775 | 0.545490 | 0.012599 | 50 | 43 |
| SciFact | 256 | FIXED_SENTENCE − RAW_SKIP | primary | 0.287617 | 0.097089 | 0.472057 | 0.035596 | 50 | 43 |
| SciFact | 1024 | FIXED_SENTENCE − RAW_SKIP | primary | -0.023911 | -0.115391 | 0.061520 | 1.000000 | 50 | 43 |
| SciFact | 256 | FIXED_SENTENCE − QBGF_FULL | secondary | 0.014383 | -0.086263 | 0.109890 | 1.000000 | 50 | 43 |
| SciFact | 1024 | FIXED_SENTENCE − QBGF_FULL | secondary | 0.109432 | 0.019507 | 0.204423 | 0.128087 | 50 | 43 |


Source: [results/week12/final_confirmation/v1/contrasts.csv](../repository/results/week12/final_confirmation/v1/contrasts.csv)

Bootstrap intervals are nominal 95% paired cluster intervals, 10,000 resamples, seed 42; HotpotQA query groups and SciFact frozen document/claim groups. P-values use the registered paired cluster label-swap procedure and Holm families: eight primary, four secondary. Do not apply a new comparison family after looking at outcomes. H3 is descriptive/contextual here.

## Key ablations — VAL only

### FULL minus NO_QUERY

| Dataset | Budget | Delta | CI_low | CI_high | Joint_Holm_p |
| --- | --- | --- | --- | --- | --- |
| QASPER | 256 | 0.088213 | 0.071636 | 0.105356 | 0.005099 |
| QASPER | 1024 | 0.066681 | 0.051495 | 0.081844 | 0.005099 |
| HotpotQA | 256 | 0.103475 | 0.095397 | 0.111746 | 0.005099 |
| HotpotQA | 1024 | 0.020092 | 0.015356 | 0.024760 | 0.005099 |
| SciFact | 256 | 0.187002 | 0.103136 | 0.270973 | 0.007799 |
| SciFact | 1024 | 0.117784 | 0.055711 | 0.182024 | 0.011399 |


### Fusion restrictions

| Dataset | Budget | Contrast | Delta | CI_low | CI_high | Joint_Holm_p |
| --- | --- | --- | --- | --- | --- | --- |
| QASPER | 256 | QBGF_FULL − QBGF_SENTENCE_ONLY | -0.000069 | -0.000581 | 0.000367 | 1.000000 |
| QASPER | 256 | QBGF_FULL − QBGF_PASSAGE_ONLY | 0.066233 | 0.048862 | 0.083949 | 0.005099 |
| QASPER | 1024 | QBGF_FULL − QBGF_SENTENCE_ONLY | -0.002685 | -0.010267 | 0.004915 | 1.000000 |
| QASPER | 1024 | QBGF_FULL − QBGF_PASSAGE_ONLY | 0.005474 | -0.005031 | 0.015607 | 1.000000 |
| HotpotQA | 256 | QBGF_FULL − QBGF_SENTENCE_ONLY | -0.000121 | -0.000363 | 0.000000 | 1.000000 |
| HotpotQA | 256 | QBGF_FULL − QBGF_PASSAGE_ONLY | 0.018559 | 0.011475 | 0.025506 | 0.005099 |
| HotpotQA | 1024 | QBGF_FULL − QBGF_SENTENCE_ONLY | 0.000049 | -0.001157 | 0.001270 | 1.000000 |
| HotpotQA | 1024 | QBGF_FULL − QBGF_PASSAGE_ONLY | -0.020163 | -0.025042 | -0.015425 | 0.005099 |
| SciFact | 256 | QBGF_FULL − QBGF_SENTENCE_ONLY | 0.000000 | 0.000000 | 0.000000 | 1.000000 |
| SciFact | 256 | QBGF_FULL − QBGF_PASSAGE_ONLY | 0.217194 | 0.139681 | 0.298944 | 0.005099 |
| SciFact | 1024 | QBGF_FULL − QBGF_SENTENCE_ONLY | -0.024280 | -0.051337 | -0.004812 | 1.000000 |
| SciFact | 1024 | QBGF_FULL − QBGF_PASSAGE_ONLY | 0.057305 | -0.009679 | 0.127139 | 1.000000 |


Sources: [results/week12/W12_D_ABLATION_RESULTS.md](../repository/results/week12/W12_D_ABLATION_RESULTS.md); [results/week12/qbgf/v3/analysis/fusion_diagnostic_comparisons.csv](../repository/results/week12/qbgf/v3/analysis/fusion_diagnostic_comparisons.csv)

Query conditioning helps allocation versus NO_QUERY under the same retrieved pool. FULL does not establish a consistent benefit over sentence-only allocation. The NO_QUERY mechanism is not tested in M; do not turn a VAL mechanistic finding into an untouched-confirmation claim.

## Evidence utility / leave-one-out

150 VAL examples (50/dataset), 600 cells, 16,032 logical perturbations, 13,410 recorded physical calls. Of 9,607 tested units: 687 helpful (7.15%), 8,311 zero-effect (86.51%), 609 harmful (6.34%). Importance is original task score minus the score after deleting one exposed unit and regenerating.

Ten of twelve relevance–importance nominal intervals include zero. This is weak/context-dependent alignment, not proof relevance is useless. Zero deletion effect does not mean “unused” or “useless”: redundancy, interactions and metric insensitivity remain possible. Units have different granularities; do not interpret their pooled fractions as intrinsic method quality. Attribution is separate post-hoc VAL diagnosis and did not change M.

Source: [results/week12/W12_K_L_ATTRIBUTION_REPORT.md](../repository/results/week12/W12_K_L_ATTRIBUTION_REPORT.md)

## Final frozen method

FIXED_SENTENCE; SFR candidate width 10; Qwen3-8B BASE_FP16; budgets 256/1024; retain_lora=false. Immutable freeze SHA256: `d0188a3582d6aead0a3a31f9f15bad9b51a88a6b475b05ac79ae38e58f05366b`. Split SHA256: `78f5ace11f9080d05dda12716e634020711182f721ac562dc81d19bad6c1c117`.

The two freeze copies were verified byte-identical. Embedded legacy config requests for QASPER confirmation are not actual membership: actual frozen confirmation has **zero** QASPER queries. Use actual IDs and split summary, not stale requested-count fields.

## Strongest positive findings

1. Frozen evidence-assisted sentence policy exceeds NONE on all four confirmation cells after primary-family Holm correction.
2. SciFact @256 has a clear sentence-versus-RAW_SKIP gain: +0.287617 macro-F1, nominal CI [0.097089, 0.472057].
3. Query-conditioned allocation has substantial VAL benefit over the query-free allocation ablation.
4. QBGF beats FIXED_SENTENCE on HotpotQA @1024 in the predefined secondary family: sentence-minus-QBGF −0.034384, Holm p≈0.0316. Report this favorable cell despite universal promotion failing.
5. All twelve predefined contrast point-estimate directions repeat VAL. This is descriptive consistency, not twelve independent replications.

## Important negative findings

No universal QBGF advantage; no proof fusion is needed over optimized sentence-only allocation; early learned context-size policies often underperform fixed controls; generative extraction frequently fails mechanically; simple sentence suppression is modest; relevance and deletion utility are only weakly/contextually aligned. RECOMP code/bundled completion data do not establish a locally executed matched baseline. Final full LLMLingua/LoRA quality experiments E/F/G were skipped by user decision; implementation/qualification is not an outcome.

## Limitations

Only 250 fresh reserved confirmation queries, two datasets, 50 SciFact claims / 43 groups, no fresh QASPER confirmation. Two primary token budgets do not establish a phase transition. Reused DEV/VAL exploration, early mock outputs and incomplete provenance must be qualified. Passage packing affects small-budget comparisons; reader format violations confound earlier SciFact reader scores. Frozen historical segmentation is not rewritten after LiveDemo audits. Confirmation is in-distribution reserved data under this protocol, not automatically OOD.

## Claims that MUST NOT be made

- QBGF or FIXED_SENTENCE is universally superior; SFR universally wins; sentences/propositions are always better.
- MCKP/knapsack itself is novel, or QBGF establishes SOTA.
- A phase transition is established by 256 and 1024 alone.
- Query-free allocation means the whole pipeline is query-free.
- High cosine, source-grounded spans or zero deletion effects identify causal evidence or internal reasoning.
- W0 mock outputs or blank human-rating templates are empirical validation.
- Historical specialist SARA scores isolate the contribution of latent vectors.
- Qualified LLMLingua-2 or LoRA code means full final experiments ran.
- Confirmation is OOD, contains fresh QASPER, or authorizes retroactive method selection.
- W13 wrapper is a second completed confirmation.
- Custom World Cup LiveDemo/reference metrics are benchmark, validation or confirmation findings.

See [DISAGREEMENTS_AND_CAVEATS.md](DISAGREEMENTS_AND_CAVEATS.md) before making historical claims and [ALL_WEEKS_COMPLETE_RESULTS.md](ALL_WEEKS_COMPLETE_RESULTS.md) for every week’s detailed tables.
