# CS787 final presentation evidence

A single read-only evidence collection for preparing a rigorous 20-minute CS787 presentation. Collected on 4 November 2026, branch `gagan`; source commit `45782d94dc61fcc6b27a57cf98c52c34929e4f81`. The repository had existing uncommitted demo and POST-W9 work; this ZIP is a working-tree snapshot, not a claim that every included byte is in that commit.

**No source files, frozen results or existing reports were modified. No experiment, training, inference or new confirmation was run.** New summaries/indexes exist only in this archive. Original included files are byte-preserved under `repository/` with their original relative paths. Category labels below are logical groups recorded in MANIFEST; the original directory context is retained rather than duplicating files into several category folders.

## Start here

1. [PPT_SOURCE_PRIORITY.md](PPT_SOURCE_PRIORITY.md): smallest reading list, 18 original MUST READ sources.
2. [FINAL_RESULTS_CHEATSHEET.md](FINAL_RESULTS_CHEATSHEET.md): final pipeline, cohorts, all final quality/contrast tables, ablations and claim limits.
3. [RESEARCH_TIMELINE.md](RESEARCH_TIMELINE.md): question-driven narrative, not a week-numbered slide deck.
4. [ALL_WEEKS_SUMMARY.md](ALL_WEEKS_SUMMARY.md): every weekly summary.
5. [ALL_WEEKS_COMPLETE_RESULTS.md](ALL_WEEKS_COMPLETE_RESULTS.md): all original audited part-wise reports and numerical tables, W0–W13.
6. [ALL_EXPERIMENTS_REGISTER.csv](ALL_EXPERIMENTS_REGISTER.csv): 95 historical parts, questions, methods, execution status, results, decisions and detailed source paths.
7. [FINAL_TABLES_COMPLETE.md](FINAL_TABLES_COMPLETE.md) and [RESULT_TABLE_CATALOG.csv](RESULT_TABLE_CATALOG.csv): full-precision source locations for plots/tables.
8. [DISAGREEMENTS_AND_CAVEATS.md](DISAGREEMENTS_AND_CAVEATS.md): do not erase conflicting history or incomplete work.
9. [POST_W9_PROGRESS.md](POST_W9_PROGRESS.md): optional unfinished DAFiR, no invented performance.
10. [MANIFEST.csv](MANIFEST.csv), [EXCLUDED_FILES.csv](EXCLUDED_FILES.csv), [SHA256SUMS.txt](SHA256SUMS.txt): provenance and exact integrity.

## Authoritative sources by question

| Question | Source | How to use it |
|---|---|---|
| Final research question and project conclusions | [results/FINAL_PROJECT_REPORT.md](../repository/results/FINAL_PROJECT_REPORT.md) | Read with final CSVs and audit caveats |
| Final method and confirmation registry | [results/week12/W13_FINAL_METHOD_FREEZE.json](../repository/results/week12/W13_FINAL_METHOD_FREEZE.json) | Frozen FIXED_SENTENCE, no LoRA; actual membership overrides requested legacy counts |
| Final main validation | [results/week12/W12_H_FINAL_REVIEW.md](../repository/results/week12/W12_H_FINAL_REVIEW.md); [results/week12/qbgf/v3/analysis/summary.csv](../repository/results/week12/qbgf/v3/analysis/summary.csv) | VAL only, task metrics separate |
| Matched baseline extension | [results/week12/W12_C_AND_C_EXT_RESULTS.md](../repository/results/week12/W12_C_AND_C_EXT_RESULTS.md) | RAW_SKIP labels and specialist reader differences |
| Query conditioning / fusion ablations | [results/week12/W12_D_ABLATION_RESULTS.md](../repository/results/week12/W12_D_ABLATION_RESULTS.md) | Strong conditioning benefit, no consistent FULL-vs-sentence fusion benefit |
| Final reserved confirmation | [results/week12/final_confirmation/v1/week12_M_final_confirmation_report.md](../repository/results/week12/final_confirmation/v1/week12_M_final_confirmation_report.md); [results/week12/final_confirmation/v1/contrasts.csv](../repository/results/week12/final_confirmation/v1/contrasts.csv) | Actual W12 M; not another W13 experiment |
| Post-hoc evidence utility | [results/week12/W12_K_L_ATTRIBUTION_REPORT.md](../repository/results/week12/W12_K_L_ATTRIBUTION_REPORT.md) | VAL explanation, not a new selector or internal reasoning proof |
| Final limitations / contradictions | [results/weekly_reports/ProjectWideConsistencyAudit.csv](../repository/results/weekly_reports/ProjectWideConsistencyAudit.csv) | Separate model simulations, missing provenance, pilot limits, consumed TEST |
| Current demo behavior | [demo/APPLICATION_GUIDE.md](../repository/demo/APPLICATION_GUIDE.md) | Later history/reference UI updates supersede older operational snapshot wording |

## Research-order map

1. **Motivation:** A fixed context budget cannot reflect heterogeneous questions; first ask how much explicit/latent evidence to expose. Source: [results/weekly_reports/week_00/WeeklySummaryAnalysis.md](../repository/results/weekly_reports/week_00/WeeklySummaryAnalysis.md).

2. **Baseline qualification:** Reproduce SARA/plain RAG interfaces and training artifacts; distinguish RECOMP checkout from locally executed evidence. Source: [results/weekly_reports/week_01/WeeklySummaryAnalysis.md](../repository/results/weekly_reports/week_01/WeeklySummaryAnalysis.md).

3. **Adaptive-size hypothesis:** Fixed k sweeps and retrospective oracles show headroom; learned budget controllers do not reliably recover it. Source: [results/weekly_reports/week_05/WeeklySummaryAnalysis.md](../repository/results/weekly_reports/week_05/WeeklySummaryAnalysis.md).

4. **Selection and drafts:** Passage identity and draft-aware promotion show some signal, but added calls and HELP/HURT cancellation limit gains. Source: [results/weekly_reports/week_08/WeeklySummaryAnalysis.md](../repository/results/weekly_reports/week_08/WeeklySummaryAnalysis.md).

5. **Suppression versus extraction:** Raw chunks and generative extraction fail to produce robust deployable gains; simple sentence suppression motivates better representation control. Source: [docs/week9/W9E_COMPLETE_RESULTS_ANALYSIS.md](../repository/docs/week9/W9E_COMPLETE_RESULTS_ANALYSIS.md).

6. **Retriever/reader diagnosis:** Separate SFR, reader checkpoint, prompt/interface and evidence representation; no single latent-vector cause is isolated. Source: [results/week10/root_cause/v1/W10_FINAL_REPORT.md](../repository/results/week10/root_cause/v1/W10_FINAL_REPORT.md).

7. **Granularity pilot:** Explore datasets, readers and budgets; sentence/whole-passage rankings depend on the setting, with important packing and output-format confounds. Source: [results/weekly_reports/week_11/WeeklySummaryAnalysis.md](../repository/results/weekly_reports/week_11/WeeklySummaryAnalysis.md).

8. **Propose QBGF:** Use query-conditioned relevance and a shared budget to choose representation fidelity; compare to strong simple controls. Source: [results/week12/W12_C_AND_C_EXT_RESULTS.md](../repository/results/week12/W12_C_AND_C_EXT_RESULTS.md).

9. **Ablate allocation/fusion:** Query conditioning helps allocation, while FULL versus SENTENCE_ONLY does not establish consistent fusion benefit. Source: [results/week12/W12_D_ABLATION_RESULTS.md](../repository/results/week12/W12_D_ABLATION_RESULTS.md).

10. **Freeze before confirmation:** Reject universal QBGF promotion under registered gates; retain FIXED_SENTENCE with no final LoRA. Source: [results/week12/W12_I_FINAL_FREEZE_REPORT.md](../repository/results/week12/W12_I_FINAL_FREEZE_REPORT.md).

11. **Post-hoc explanation:** Leave-one-out importance is often zero and relevance is weakly/contextually aligned; no internal reasoning or universal causal interpretation. Source: [results/week12/W12_K_L_ATTRIBUTION_REPORT.md](../repository/results/week12/W12_K_L_ATTRIBUTION_REPORT.md).

12. **Reserved confirmation:** Strong evidence benefit repeats; tight-budget SciFact sentences help; 1024-token passages are competitive; QBGF wins a specific HotpotQA cell without changing the frozen decision. Source: [results/week12/final_confirmation/v1/week12_M_final_confirmation_report.md](../repository/results/week12/final_confirmation/v1/week12_M_final_confirmation_report.md).

13. **Demo and fidelity audits:** Curated saved examples plus custom operational stages; compare two runs, inspect source units and input budget, retain custom-reference diagnostics separately. Source: [demo/APPLICATION_GUIDE.md](../repository/demo/APPLICATION_GUIDE.md).

14. **Optional unfinished DAFiR:** Revisit stronger SFR with original SARA fidelity/promotion under a separate official-TRAIN/official-validation protocol; current cache progress is not a scientific result. Source: [POST W9/README.md](../repository/POST%20W9/README.md).

## Interpretation and completeness

FINAL means a completed final/reporting artifact within its scope; it does not mean every historical experiment is the final project result. FROZEN can include a frozen reconstruction with explicit gaps; it does not erase those gaps. EXPLORATORY includes earlier completed pilots. INTERMEDIATE covers smoke, invalidated/provisional or prototype work. AUDIT records provenance/integrity. FUTURE_WORK includes POST-W9, whose progress is not fabricated QA performance.

All important part-level outcomes are retained through the detailed weekly reports and compact original tables. Large raw predictions, model weights, embeddings, datasets, runtime shards and the curated ~100MB bundle are deliberately omitted. This is a presentation evidence pack, **not an executable reproduction of model experiments or a full dataset backup**. Scripts/notebooks referenced in original reports may intentionally be outside the pack; their relevant outputs and audit extracts are included. See SOURCE_LINK_DEPENDENCIES.csv for dependencies not available within this compact collection.

## Manifest convention

Each manifest row records the ZIP-relative path (inside CS787_PRESENTATION_EVIDENCE), original repository path where applicable, type, byte count, category, status, description and SHA256. Newly generated indexes use an empty original_repo_path. MANIFEST.csv excludes itself and SHA256SUMS.txt to avoid self-referential hashes; SHA256SUMS covers every other file including MANIFEST.csv and excludes only itself. ZIP CRC and every recorded hash were checked after construction. No credentials or model weights are allowed.

## All included important documents

The following map lists every included Markdown document, its source, status and purpose. All other included result/config/figure files have descriptions in MANIFEST.csv.

| Original path / packaged file | Category | Status | Contains / presentation use |
|---|---|---|---|
| [Baselines/SARA-main/CLAUDE.md](../repository/Baselines/SARA-main/CLAUDE.md) | 02_BASELINES_SARA_RECOMP | EXPLORATORY | Repository Engineering Rules |
| [Baselines/SARA-main/README.md](../repository/Baselines/SARA-main/README.md) | 02_BASELINES_SARA_RECOMP | EXPLORATORY | 🔍 SARA |
| [Baselines/SARA-main/src/rag_retrieval/train/colbert/README.md](../repository/Baselines/SARA-main/src/rag_retrieval/train/colbert/README.md) | 03_RETRIEVAL | EXPLORATORY | 安装环境 |
| [Baselines/SARA-main/src/rag_retrieval/train/reranker/README.md](../repository/Baselines/SARA-main/src/rag_retrieval/train/reranker/README.md) | 03_RETRIEVAL | EXPLORATORY | Setting Up the Environment |
| [Baselines/SARA-main/src/rag_retrieval/train/reranker/README_zh.md](../repository/Baselines/SARA-main/src/rag_retrieval/train/reranker/README_zh.md) | 03_RETRIEVAL | EXPLORATORY | 安装环境 |
| [Baselines/recomp-main/README.md](../repository/Baselines/recomp-main/README.md) | 02_BASELINES_SARA_RECOMP | EXPLORATORY | recomp |
| [POST W9/IMPLEMENTATION_REPORT.md](../repository/POST%20W9/IMPLEMENTATION_REPORT.md) | 10_FUTURE_DAFIR | FUTURE_WORK | POST-W9 implementation and readiness |
| [POST W9/README.md](../repository/POST%20W9/README.md) | 10_FUTURE_DAFIR | FUTURE_WORK | POST-W9 — DAFiR-SFR |
| [POST W9/audit/SHORT_PAPER_FIX.md](../repository/POST%20W9/audit/SHORT_PAPER_FIX.md) | 10_FUTURE_DAFIR | FUTURE_WORK | POST-W9 short-paper retrieval fix — 4 November 2026 |
| [configs/week12/README.md](../repository/configs/week12/README.md) | 05_QBGF | EXPLORATORY | Active Week12 protocol — v3 |
| [demo/APPLICATION_GUIDE.md](../repository/demo/APPLICATION_GUIDE.md) | 09_DEMO_AND_AUDITS | FINAL | Evidence Lab — complete application and method guide |
| [demo/FINAL_FREEZE_STATUS.md](../repository/demo/FINAL_FREEZE_STATUS.md) | 09_DEMO_AND_AUDITS | FROZEN | Final demo freeze status |
| [demo/IMPLEMENTATION_REPORT.md](../repository/demo/IMPLEMENTATION_REPORT.md) | 09_DEMO_AND_AUDITS | FINAL | Demo implementation closeout |
| [demo/README.md](../repository/demo/README.md) | 09_DEMO_AND_AUDITS | FINAL | Evidence Lab · CS787 research demo |
| [demo/audit/FINAL_DEMO_CORRECTNESS_AUDIT.md](../repository/demo/audit/FINAL_DEMO_CORRECTNESS_AUDIT.md) | 09_DEMO_AND_AUDITS | AUDIT | Final Evidence Lab correctness and methodology audit |
| [demo/audit/demo_reproducibility_status.md](../repository/demo/audit/demo_reproducibility_status.md) | 09_DEMO_AND_AUDITS | AUDIT | Demo reproducibility status — final freeze |
| [demo/audit/final_methodology_audit.md](../repository/demo/audit/final_methodology_audit.md) | 09_DEMO_AND_AUDITS | AUDIT | Final Evidence Lab correctness and methodology audit |
| [demo/audit/live_sentence_segmentation_audit.md](../repository/demo/audit/live_sentence_segmentation_audit.md) | 09_DEMO_AND_AUDITS | AUDIT | LiveDemo sentence-segmentation audit |
| [demo/audit/qasper_frozen_splitter_impact.md](../repository/demo/audit/qasper_frozen_splitter_impact.md) | 09_DEMO_AND_AUDITS | AUDIT | Read-only historical QASPER splitter impact audit |
| [demo/audit/qbgf_score_scale_audit.md](../repository/demo/audit/qbgf_score_scale_audit.md) | 09_DEMO_AND_AUDITS | AUDIT | LiveDemo QBGF score-scale audit |
| [demo/audit/world_cup_correctness_v2/WORLD_CUP_12_CONDITION_REPORT.md](../repository/demo/audit/world_cup_correctness_v2/WORLD_CUP_12_CONDITION_REPORT.md) | 09_DEMO_AND_AUDITS | AUDIT | World Cup LiveDemo corrective regression — 12 conditions |
| [demo/releases/README.md](../repository/demo/releases/README.md) | 09_DEMO_AND_AUDITS | FINAL | Immutable curated archive |
| [docs/week9/FULL_SARA_MODEL_REPLACEMENT_FEASIBILITY.md](../repository/docs/week9/FULL_SARA_MODEL_REPLACEMENT_FEASIBILITY.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | Full SARA generator replacement — future work only |
| [docs/week9/W9A_DUPLICATE_EVIDENCE_FIX.md](../repository/docs/week9/W9A_DUPLICATE_EVIDENCE_FIX.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | W9-A duplicate-question evidence alignment fix |
| [docs/week9/W9A_STORAGE_OPTIMIZATION.md](../repository/docs/week9/W9A_STORAGE_OPTIMIZATION.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | W9-A storage and runtime repair |
| [docs/week9/W9E3_SENTTOPK.md](../repository/docs/week9/W9E3_SENTTOPK.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | W9-E3 — Semantic Sentence Suppression |
| [docs/week9/W9E_COMPLETE_RESULTS_ANALYSIS.md](../repository/docs/week9/W9E_COMPLETE_RESULTS_ANALYSIS.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | W9-E complete results analysis, including E3 |
| [docs/week9/W9E_GROUNDED_IMPLEMENTATION.md](../repository/docs/week9/W9E_GROUNDED_IMPLEMENTATION.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | W9-E v1 — compact, mechanically grounded evidence |
| [docs/week9/W9F_UTILIZATION.md](../repository/docs/week9/W9F_UTILIZATION.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | W9-F — Utilization of frozen E3-k3 evidence |
| [docs/week9/W9G_ACTION_VERIFICATION.md](../repository/docs/week9/W9G_ACTION_VERIFICATION.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | W9-G-PRE — Action-specific verification: implementation and results |
| [docs/week9/W9G_CONTROLLER_RESULTS_SHORT.md](../repository/docs/week9/W9G_CONTROLLER_RESULTS_SHORT.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | W9-G controller results — short interpretation |
| [docs/week9/W9G_PRE_FINAL_TRAINING_AUDIT.md](../repository/docs/week9/W9G_PRE_FINAL_TRAINING_AUDIT.md) | 01_PROJECT_EVOLUTION | AUDIT | W9G_PRE_FINAL_TRAINING_AUDIT |
| [docs/week9/W9H_EXECUTION.md](../repository/docs/week9/W9H_EXECUTION.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | W9-H execution and remaining prerequisites |
| [docs/week9/W9H_IMPLEMENTATION_HANDOFF.md](../repository/docs/week9/W9H_IMPLEMENTATION_HANDOFF.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | W9-H implementation handoff |
| [docs/week9/W9PRE_MODEL_AUDIT.md](../repository/docs/week9/W9PRE_MODEL_AUDIT.md) | 01_PROJECT_EVOLUTION | AUDIT | W9-PRE measured feasibility audit |
| [docs/week9/W9PRE_MODEL_RESEARCH.md](../repository/docs/week9/W9PRE_MODEL_RESEARCH.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | W9-PRE model research (2026-10-20) |
| [docs/week9/WEEK9_IMPLEMENTATION_AUDIT.md](../repository/docs/week9/WEEK9_IMPLEMENTATION_AUDIT.md) | 01_PROJECT_EVOLUTION | AUDIT | Week 9 implementation audit |
| [docs/week9/WEEK9_LIVE_TRACKER.md](../repository/docs/week9/WEEK9_LIVE_TRACKER.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | Week 9 live tracker |
| [docs/week9/WEEK9_PATCH_AUDIT.md](../repository/docs/week9/WEEK9_PATCH_AUDIT.md) | 01_PROJECT_EVOLUTION | AUDIT | Week 9 patch audit — before implementation (2026-10-20) |
| [docs/week9/WEEK9_PATCH_IMPLEMENTATION_AUDIT.md](../repository/docs/week9/WEEK9_PATCH_IMPLEMENTATION_AUDIT.md) | 01_PROJECT_EVOLUTION | AUDIT | Week 9 patch implementation audit |
| [docs/week9/WEEK9_REFERENCE_AUDIT.md](../repository/docs/week9/WEEK9_REFERENCE_AUDIT.md) | 01_PROJECT_EVOLUTION | AUDIT | Week 9 reference audit |
| [docs/week9/WEEK9_RUNBOOK.md](../repository/docs/week9/WEEK9_RUNBOOK.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | Week 9 manual runbook |
| [results/FINAL_PROJECT_REPORT.md](../repository/results/FINAL_PROJECT_REPORT.md) | 01_PROJECT_EVOLUTION | FINAL | Final project report: choosing useful evidence for retrieval-augmented language models |
| [results/PROJECT_GLOSSARY_AND_METRICS.md](../repository/results/PROJECT_GLOSSARY_AND_METRICS.md) | 01_PROJECT_EVOLUTION | FINAL | Project glossary: methods, metrics and formulas |
| [results/week0/dataset_analysis/dataset_analysis_report.md](../repository/results/week0/dataset_analysis/dataset_analysis_report.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | Part A — Dataset and retrieved-evidence characterization |
| [results/week0/evidence_analysis/evidence_analysis_report.md](../repository/results/week0/evidence_analysis/evidence_analysis_report.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | Week 0: Retrieved Passage Utilization Diagnostics Report |
| [results/week0/final40/final40_report.md](../repository/results/week0/final40/final40_report.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | Part FINAL40 — Forty-paper input-sensitivity study |
| [results/week0/gpu_pilot/intervention_validation/validation_report.md](../repository/results/week0/gpu_pilot/intervention_validation/validation_report.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | Part INTERVENTION-VALIDATION — Removal versus length-controlled replacement |
| [results/week0/gpu_pilot/pilot_report.md](../repository/results/week0/gpu_pilot/pilot_report.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | Part GPU-PILOT — Ten-query real GPU probe |
| [results/week0/layer_analysis/layer_analysis_report.md](../repository/results/week0/layer_analysis/layer_analysis_report.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | Week 0: Mistral Hidden-State & Representation Evolution Report |
| [results/week0/repository_audit.md](../repository/results/week0/repository_audit.md) | 01_PROJECT_EVOLUTION | AUDIT | Repository Audit: Week 0 Preparation |
| [results/week0/sara_motivation/week0_synthesis.md](../repository/results/week0/sara_motivation/week0_synthesis.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | Week 0 Synthesis: Connecting Evidence Structure to SARA |
| [results/week0/scientific_audit.md](../repository/results/week0/scientific_audit.md) | 01_PROJECT_EVOLUTION | AUDIT | Week 0 Scientific & Implementation Audit |
| [results/week0/week0_report.md](../repository/results/week0/week0_report.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | Week 0 — Understanding Evidence Utilization in RAG |
| [results/week10/root_cause/v1/SARA_REPRODUCTION_AUDIT.md](../repository/results/week10/root_cause/v1/SARA_REPRODUCTION_AUDIT.md) | 03_RETRIEVAL | AUDIT | SARA reproduction audit |
| [results/week10/root_cause/v1/W10_FINAL_REPORT.md](../repository/results/week10/root_cause/v1/W10_FINAL_REPORT.md) | 03_RETRIEVAL | EXPLORATORY | Week 10 — Final root-cause study report |
| [results/week10/root_cause/v1/W10_ROOT_CAUSE_PREFLIGHT.md](../repository/results/week10/root_cause/v1/W10_ROOT_CAUSE_PREFLIGHT.md) | 03_RETRIEVAL | EXPLORATORY | W10 root-cause preflight |
| [results/week10/root_cause/v1/audit/sources/sara_readme.md](../repository/results/week10/root_cause/v1/audit/sources/sara_readme.md) | 03_RETRIEVAL | AUDIT | 🔍 SARA |
| [results/week10/root_cause/v1/audit/sources/selecom_readme.md](../repository/results/week10/root_cause/v1/audit/sources/selecom_readme.md) | 03_RETRIEVAL | AUDIT | SeleCom |
| [results/week10/root_cause/v1/audit/sources/sfr_card.md](../repository/results/week10/root_cause/v1/audit/sources/sfr_card.md) | 03_RETRIEVAL | AUDIT | Ethical Considerations |
| [results/week10/root_cause/v1/dataset_confirmation_plan.md](../repository/results/week10/root_cause/v1/dataset_confirmation_plan.md) | 06_VALIDATION_CONFIRMATION | EXPLORATORY | Fresh confirmation plan |
| [results/week10/root_cause/v1/execution_plan.md](../repository/results/week10/root_cause/v1/execution_plan.md) | 03_RETRIEVAL | EXPLORATORY | Manual execution and resume |
| [results/week11/PROGRESS.md](../repository/results/week11/PROGRESS.md) | 04_GRANULARITY | EXPLORATORY | Week 11 progress |
| [results/week11/multigranular/v1/compressor_reader/INTERPRETATION.md](../repository/results/week11/multigranular/v1/compressor_reader/INTERPRETATION.md) | 04_GRANULARITY | EXPLORATORY | Week 11 E — audited pilot results |
| [results/week11/multigranular/v1/compressor_reader/REPORT.md](../repository/results/week11/multigranular/v1/compressor_reader/REPORT.md) | 04_GRANULARITY | EXPLORATORY | Week 11 phase E |
| [results/week11/multigranular/v1/compressor_reader/RESEARCH_REVIEW.md](../repository/results/week11/multigranular/v1/compressor_reader/RESEARCH_REVIEW.md) | 04_GRANULARITY | EXPLORATORY | Week 11 E — compressor × reader: full research review |
| [results/week11/multigranular/v1/final_report/INTERPRETATION.md](../repository/results/week11/multigranular/v1/final_report/INTERPRETATION.md) | 04_GRANULARITY | EXPLORATORY | Week 11 I — saved-result analysis |
| [results/week11/multigranular/v1/final_report/REPORT.md](../repository/results/week11/multigranular/v1/final_report/REPORT.md) | 04_GRANULARITY | EXPLORATORY | Week 11 phase I |
| [results/week11/multigranular/v1/final_report/RESEARCH_REVIEW.md](../repository/results/week11/multigranular/v1/final_report/RESEARCH_REVIEW.md) | 04_GRANULARITY | EXPLORATORY | Week 11 — completed multigranular evidence pilot |
| [results/week11/multigranular/v1/granularity_budget/INTERPRETATION.md](../repository/results/week11/multigranular/v1/granularity_budget/INTERPRETATION.md) | 04_GRANULARITY | EXPLORATORY | Week 11 C — granularity and budget pilot |
| [results/week11/multigranular/v1/granularity_budget/REPORT.md](../repository/results/week11/multigranular/v1/granularity_budget/REPORT.md) | 04_GRANULARITY | EXPLORATORY | Week 11 phase C |
| [results/week11/multigranular/v1/hierarchical/INTERPRETATION.md](../repository/results/week11/multigranular/v1/hierarchical/INTERPRETATION.md) | 04_GRANULARITY | EXPLORATORY | Week 11 G — audited pilot results |
| [results/week11/multigranular/v1/hierarchical/REPORT.md](../repository/results/week11/multigranular/v1/hierarchical/REPORT.md) | 04_GRANULARITY | EXPLORATORY | Week 11 phase G |
| [results/week11/multigranular/v1/hierarchical/RESEARCH_REVIEW.md](../repository/results/week11/multigranular/v1/hierarchical/RESEARCH_REVIEW.md) | 04_GRANULARITY | EXPLORATORY | Week 11 G — deterministic hierarchical exposure: research review |
| [results/week11/multigranular/v1/oracle/INTERPRETATION.md](../repository/results/week11/multigranular/v1/oracle/INTERPRETATION.md) | 04_GRANULARITY | EXPLORATORY | Week 11 H — saved-result analysis |
| [results/week11/multigranular/v1/oracle/REPORT.md](../repository/results/week11/multigranular/v1/oracle/REPORT.md) | 04_GRANULARITY | EXPLORATORY | Week 11 phase H |
| [results/week11/multigranular/v1/oracle/RESEARCH_REVIEW.md](../repository/results/week11/multigranular/v1/oracle/RESEARCH_REVIEW.md) | 04_GRANULARITY | EXPLORATORY | Week 11 H — oracle and interactions: research interpretation |
| [results/week11/multigranular/v1/passage_representation/INTERPRETATION.md](../repository/results/week11/multigranular/v1/passage_representation/INTERPRETATION.md) | 04_GRANULARITY | EXPLORATORY | W11-B completed passage-representation pilot |
| [results/week11/multigranular/v1/passage_representation/REPORT.md](../repository/results/week11/multigranular/v1/passage_representation/REPORT.md) | 04_GRANULARITY | EXPLORATORY | Week 11 phase B |
| [results/week11/multigranular/v1/reader_granularity/INTERPRETATION.md](../repository/results/week11/multigranular/v1/reader_granularity/INTERPRETATION.md) | 04_GRANULARITY | EXPLORATORY | Week 11 D — audited pilot results |
| [results/week11/multigranular/v1/reader_granularity/PARTIAL_PROGRESS_REVIEW.md](../repository/results/week11/multigranular/v1/reader_granularity/PARTIAL_PROGRESS_REVIEW.md) | 04_GRANULARITY | EXPLORATORY | Partial Week 11 D progress and blockers |
| [results/week11/multigranular/v1/reader_granularity/REPORT.md](../repository/results/week11/multigranular/v1/reader_granularity/REPORT.md) | 04_GRANULARITY | EXPLORATORY | Week 11 phase D |
| [results/week11/multigranular/v1/reader_granularity/RESEARCH_REVIEW.md](../repository/results/week11/multigranular/v1/reader_granularity/RESEARCH_REVIEW.md) | 04_GRANULARITY | EXPLORATORY | Week 11 D — reader × evidence granularity: full research review |
| [results/week11/multigranular/v1/retrieval/INTERPRETATION.md](../repository/results/week11/multigranular/v1/retrieval/INTERPRETATION.md) | 04_GRANULARITY | EXPLORATORY | W11-A completed retrieval pilot — interpretation |
| [results/week11/multigranular/v1/retrieval/REPORT.md](../repository/results/week11/multigranular/v1/retrieval/REPORT.md) | 04_GRANULARITY | EXPLORATORY | Week 11 phase A |
| [results/week11/multigranular/v1/retriever_robustness/INTERPRETATION.md](../repository/results/week11/multigranular/v1/retriever_robustness/INTERPRETATION.md) | 04_GRANULARITY | EXPLORATORY | Week 11 F — audited pilot results |
| [results/week11/multigranular/v1/retriever_robustness/REPORT.md](../repository/results/week11/multigranular/v1/retriever_robustness/REPORT.md) | 04_GRANULARITY | EXPLORATORY | Week 11 phase F |
| [results/week11/multigranular/v1/retriever_robustness/RESEARCH_REVIEW.md](../repository/results/week11/multigranular/v1/retriever_robustness/RESEARCH_REVIEW.md) | 04_GRANULARITY | EXPLORATORY | Week 11 F — retriever robustness: research review |
| [results/week11/multigranular/v1/setup/IMPLEMENTATION_REPORT.md](../repository/results/week11/multigranular/v1/setup/IMPLEMENTATION_REPORT.md) | 04_GRANULARITY | EXPLORATORY | Week 11 — multi-granular selective-fidelity laboratory |
| [results/week11/multigranular/v1/setup/REPORT.md](../repository/results/week11/multigranular/v1/setup/REPORT.md) | 04_GRANULARITY | EXPLORATORY | Week 11 phase 0 |
| [results/week12/W12_ATTRIBUTION_READINESS.md](../repository/results/week12/W12_ATTRIBUTION_READINESS.md) | 07_UTILITY_ANALYSIS | EXPLORATORY | Week 12 J/K/L — attribution implementation readiness |
| [results/week12/W12_CORE_D_FUSION_PATCH.md](../repository/results/week12/W12_CORE_D_FUSION_PATCH.md) | 05_QBGF | EXPLORATORY | Final CORE D fusion-control patch |
| [results/week12/W12_CORRECTED_PROTOCOL_REPORT.md](../repository/results/week12/W12_CORRECTED_PROTOCOL_REPORT.md) | 05_QBGF | EXPLORATORY | Week12 corrected final development protocol — implemented |
| [results/week12/W12_C_AND_C_EXT_RESULTS.md](../repository/results/week12/W12_C_AND_C_EXT_RESULTS.md) | 05_QBGF | FINAL | Week 12 — Complete Part C and C-EXT validation results |
| [results/week12/W12_C_EXTENSION_REPORT.md](../repository/results/week12/W12_C_EXTENSION_REPORT.md) | 05_QBGF | EXPLORATORY | Week 12 C-EXT baseline completion |
| [results/week12/W12_DATA_EXPOSURE_AUDIT.md](../repository/results/week12/W12_DATA_EXPOSURE_AUDIT.md) | 05_QBGF | AUDIT | Week12 data exposure audit — active v3 |
| [results/week12/W12_D_ABLATION_RESULTS.md](../repository/results/week12/W12_D_ABLATION_RESULTS.md) | 05_QBGF | FINAL | Week 12 Part D — completed ablation results |
| [results/week12/W12_H_FINAL_REVIEW.md](../repository/results/week12/W12_H_FINAL_REVIEW.md) | 08_FINAL_METHOD | FINAL | Week 12 H — final validation interpretation and Part I recommendation |
| [results/week12/W12_IMPLEMENTATION_REPORT.md](../repository/results/week12/W12_IMPLEMENTATION_REPORT.md) | 05_QBGF | EXPLORATORY | Week 12 implementation and smoke report |
| [results/week12/W12_I_FINAL_FREEZE_REPORT.md](../repository/results/week12/W12_I_FINAL_FREEZE_REPORT.md) | 08_FINAL_METHOD | FROZEN | Week 12 Part I — final method freeze closeout |
| [results/week12/W12_K_L_ATTRIBUTION_REPORT.md](../repository/results/week12/W12_K_L_ATTRIBUTION_REPORT.md) | 07_UTILITY_ANALYSIS | FINAL | Week12 K/L — completed evidence-attribution diagnostic |
| [results/week12/W12_M_IMPLEMENTATION_READINESS.md](../repository/results/week12/W12_M_IMPLEMENTATION_READINESS.md) | 05_QBGF | EXPLORATORY | Week12 M — implementation and untouched-confirmation readiness |
| [results/week12/W12_SCHEDULER_CORE_REPORT.md](../repository/results/week12/W12_SCHEDULER_CORE_REPORT.md) | 05_QBGF | EXPLORATORY | W12-QBGF-v3 scheduler, CORE_FINAL and LLMLingua qualification patch |
| [results/week12/W12_SPLIT_AUDIT.md](../repository/results/week12/W12_SPLIT_AUDIT.md) | 05_QBGF | AUDIT | Week 12 split and leakage audit |
| [results/week12/attribution/v1/analysis/REPORT.md](../repository/results/week12/attribution/v1/analysis/REPORT.md) | 07_UTILITY_ANALYSIS | EXPLORATORY | Evidence input-ablation diagnostic |
| [results/week12/final_confirmation/v1/week12_M_final_confirmation_report.md](../repository/results/week12/final_confirmation/v1/week12_M_final_confirmation_report.md) | 06_VALIDATION_CONFIRMATION | FINAL | Week12 M — final untouched confirmation |
| [results/week12/qbgf/v2/SUPERSEDED.md](../repository/results/week12/qbgf/v2/SUPERSEDED.md) | 05_QBGF | EXPLORATORY | Metadata-only audit draft — superseded before any model run |
| [results/week12/qbgf/v3/analysis/REPORT.md](../repository/results/week12/qbgf/v3/analysis/REPORT.md) | 05_QBGF | FINAL | Week12 development analysis |
| [results/week2/week2_scientific_validation_report.md](../repository/results/week2/week2_scientific_validation_report.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | Week-2 Scientific Validation Checkpoint Report |
| [results/week3/human_audit/human_audit_report.md](../repository/results/week3/human_audit/human_audit_report.md) | 01_PROJECT_EVOLUTION | AUDIT | Blinded Human Audit Report (N=50 Development Questions) |
| [results/week3/processed/methodology_audit.md](../repository/results/week3/processed/methodology_audit.md) | 01_PROJECT_EVOLUTION | AUDIT | Methodological Audit: Dual Oracle Definitions & Epsilon Target Formulation |
| [results/week3/processed/week3_scientific_report.md](../repository/results/week3/processed/week3_scientific_report.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | Week 3 Scientific Report: Oracle, Epsilon Target, Heterogeneity & Human Validation |
| [results/week3/week3_final_scientific_report.md](../repository/results/week3/week3_final_scientific_report.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | Week 3 Scientific Report: Oracle, Epsilon Target, Heterogeneity & Human Validation |
| [results/week4/feature_discovery/feature_discovery_report.md](../repository/results/week4/feature_discovery/feature_discovery_report.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | Feature Discovery Report: Pre-Generation Observable Signals for Evidence Allocation |
| [results/week4/feature_validation/feature_validation_report.md](../repository/results/week4/feature_validation/feature_validation_report.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | Week 4-B Scientific Report: Feature Validation, Redundancy Analysis & Transition Modeling |
| [results/week4/model_benchmark/model_benchmark_report.md](../repository/results/week4/model_benchmark/model_benchmark_report.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | Week 5: Nonlinear Stage-2 ML Modeling Benchmark Report |
| [results/week4/model_benchmark/week5_modeling_report.md](../repository/results/week4/model_benchmark/week5_modeling_report.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | Week 5: Nonlinear Stage-2 ML Modeling Benchmark Report |
| [results/week4/processed/week4_scientific_report.md](../repository/results/week4/processed/week4_scientific_report.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | Week 4 Scientific Report: Learning Query-Conditioned Evidence Allocation (QCCA) |
| [results/week4/qcca_v2/qcca_v2_report.md](../repository/results/week4/qcca_v2/qcca_v2_report.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | QCCA-V2 Scientific Report: Sequential Transition-Aware Evidence Allocation |
| [results/week4/qcca_v2_diagnostic/qcca_v2_diagnostic_report.md](../repository/results/week4/qcca_v2_diagnostic/qcca_v2_diagnostic_report.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | QCCA-V2 Diagnostic and Policy-Refinement Report |
| [results/week4/qcca_v2_final_validation/final_validation_report.md](../repository/results/week4/qcca_v2_final_validation/final_validation_report.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | QCCA-V2 Final Validation Report: Stage-2 Selective Evidence Allocation (Policy C1) |
| [results/week5/README.md](../repository/results/week5/README.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | Week 5: Content-Aware Adaptive Representation Allocation |
| [results/week5/content_allocator/diagnostics/artifact_inventory.md](../repository/results/week5/content_allocator/diagnostics/artifact_inventory.md) | 01_PROJECT_EVOLUTION | AUDIT | Week 5 Content Allocator: Artifact Inventory |
| [results/week5/content_allocator/diagnostics/checkpoint_selection_audit.md](../repository/results/week5/content_allocator/diagnostics/checkpoint_selection_audit.md) | 01_PROJECT_EVOLUTION | AUDIT | Week 5: Checkpoint-Selection Rule Audit |
| [results/week5/content_allocator/diagnostics/i3_semantic_pipeline_audit.md](../repository/results/week5/content_allocator/diagnostics/i3_semantic_pipeline_audit.md) | 01_PROJECT_EVOLUTION | AUDIT | Week 5: I3 Semantic Pipeline Integrity Audit |
| [results/week5/content_allocator/diagnostics/t1_class_weight_audit.md](../repository/results/week5/content_allocator/diagnostics/t1_class_weight_audit.md) | 01_PROJECT_EVOLUTION | AUDIT | Week 5: T1 Class Weighting Audit |
| [results/week5/content_allocator/diagnostics/week5_postrun_diagnostic_report.md](../repository/results/week5/content_allocator/diagnostics/week5_postrun_diagnostic_report.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | Week 5 Post-Run Diagnostic Audit: Why Did Models Collapse Toward k=8? |
| [results/week5/content_allocator/w5b/w5b_live_tracker.md](../repository/results/week5/content_allocator/w5b/w5b_live_tracker.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | Week 5-B Content-Aware Allocator Live Tracking |
| [results/week5/content_allocator/w5b/week5b_report.md](../repository/results/week5/content_allocator/w5b/week5b_report.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | Week 5-B: Corrected Content-Aware Allocation via Multi-Label Epsilon-Admissibility |
| [results/week5/content_allocator/w5c_encoder_adaptation/MIGRATION_MANIFEST.md](../repository/results/week5/content_allocator/w5c_encoder_adaptation/MIGRATION_MANIFEST.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | Migration Manifest: Week 6 to Week 5-C (Encoder Adaptation) |
| [results/week5/content_allocator/w5c_encoder_adaptation/week5c_report.md](../repository/results/week5/content_allocator/w5c_encoder_adaptation/week5c_report.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | Week 5-C: Semantic Encoder Adaptation and Capacity Study |
| [results/week5/preflight/model_architecture_plan.md](../repository/results/week5/preflight/model_architecture_plan.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | Week 5 Preflight: Semantic Encoder Model Architecture Plan |
| [results/week5/preflight/repository_audit.md](../repository/results/week5/preflight/repository_audit.md) | 01_PROJECT_EVOLUTION | AUDIT | Week 5 Preflight: Repository & Path Audit Report |
| [results/week5/preflight/w4_feature_reuse.md](../repository/results/week5/preflight/w4_feature_reuse.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | Week 5 Preflight: Week 4 Feature Reuse & Pre-Generation Audit |
| [results/week5/preflight/week5_preflight_report.md](../repository/results/week5/preflight/week5_preflight_report.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | Week 5: Content-Aware Allocation Preflight Report |
| [results/week5/train_response_surface/response_surface_report.md](../repository/results/week5/train_response_surface/response_surface_report.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | Week 5 TRAIN Response-Surface & Canonical Supervision Report |
| [results/week5/train_surface_validation/validation_report.md](../repository/results/week5/train_surface_validation/validation_report.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | Week-5 Response-Surface Validation Report |
| [results/week6/README.md](../repository/results/week6/README.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | Week 6 — Reserved for Query-Conditioned Passage Fidelity Routing |
| [results/week7/w7b_semantic_budget/diagnostics/smoke/smoke_diagnostics_report.md](../repository/results/week7/w7b_semantic_budget/diagnostics/smoke/smoke_diagnostics_report.md) | 01_PROJECT_EVOLUTION | INTERMEDIATE | Week 7-B Smoke Test Diagnostics Report |
| [results/week7/w7c2_utility_ranking/diagnostics/w7c1_selection_audit.md](../repository/results/week7/w7c2_utility_ranking/diagnostics/w7c1_selection_audit.md) | 01_PROJECT_EVOLUTION | AUDIT | W7-C1 Model and Feature Selection Audit |
| [results/week8/WEEK8_LIVE_TRACKER.md](../repository/results/week8/WEEK8_LIVE_TRACKER.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | Week 8 DAFiR Live Experiment Tracker |
| [results/week8/archive_gate_input_prototypes/README.md](../repository/results/week8/archive_gate_input_prototypes/README.md) | 01_PROJECT_EVOLUTION | INTERMEDIATE | Project documentation |
| [results/week8/archive_invalid_w8c_agent_run/README.md](../repository/results/week8/archive_invalid_w8c_agent_run/README.md) | 01_PROJECT_EVOLUTION | INTERMEDIATE | Invalidated W8-C agent-run comparison |
| [results/week8/archive_provisional_invalidated/README.md](../repository/results/week8/archive_provisional_invalidated/README.md) | 01_PROJECT_EVOLUTION | INTERMEDIATE | Archive: Provisional / Invalidated W8-A Outputs |
| [results/week8/archive_w8d_question_normalization/README.md](../repository/results/week8/archive_w8d_question_normalization/README.md) | 01_PROJECT_EVOLUTION | INTERMEDIATE | Project documentation |
| [results/week8/archive_w8d_question_normalization/closeout_v1/CLOSEOUT.md](../repository/results/week8/archive_w8d_question_normalization/closeout_v1/CLOSEOUT.md) | 01_PROJECT_EVOLUTION | INTERMEDIATE | W8-D cached-feature closeout — 18 October 2026 |
| [results/week8/w8d_closeout/CLOSEOUT.md](../repository/results/week8/w8d_closeout/CLOSEOUT.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | W8-D cached-feature closeout — 18 October 2026 |
| [results/week8/w8e_controller/RESULTS.md](../repository/results/week8/w8e_controller/RESULTS.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | W8-E frozen controller results — 18 October 2026 |
| [results/week8/w8f_qcla/initial_measured_smoke_before_latency_reporting/NOTE.md](../repository/results/week8/w8f_qcla/initial_measured_smoke_before_latency_reporting/NOTE.md) | 01_PROJECT_EVOLUTION | INTERMEDIATE | Project documentation |
| [results/week9/README.md](../repository/results/week9/README.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | Week 9 artifacts |
| [results/week9/diagnostics/w9c_k2/README.md](../repository/results/week9/diagnostics/w9c_k2/README.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | W9-C K=2 selector diagnostic |
| [results/week9/diagnostics/w9c_k2/extraction/fit/W9D_REPORT.md](../repository/results/week9/diagnostics/w9c_k2/extraction/fit/W9D_REPORT.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | W9-D |
| [results/week9/diagnostics/w9c_k2/extraction/fit/smoke/W9D_REPORT.md](../repository/results/week9/diagnostics/w9c_k2/extraction/fit/smoke/W9D_REPORT.md) | 01_PROJECT_EVOLUTION | INTERMEDIATE | W9-D |
| [results/week9/diagnostics/w9c_k2/grounded_faithfulness/v1/budget_128/fit/REPORT.md](../repository/results/week9/diagnostics/w9c_k2/grounded_faithfulness/v1/budget_128/fit/REPORT.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | W9-E compact grounded evidence |
| [results/week9/diagnostics/w9c_k2/grounded_faithfulness/v1/budget_128/preflight/REPORT.md](../repository/results/week9/diagnostics/w9c_k2/grounded_faithfulness/v1/budget_128/preflight/REPORT.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | W9-E compact grounded evidence |
| [results/week9/diagnostics/w9c_k2/selection/fit/W9C_REPORT.md](../repository/results/week9/diagnostics/w9c_k2/selection/fit/W9C_REPORT.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | W9-C |
| [results/week9/diagnostics/w9c_k2/selection/fit/smoke/W9C_REPORT.md](../repository/results/week9/diagnostics/w9c_k2/selection/fit/smoke/W9C_REPORT.md) | 01_PROJECT_EVOLUTION | INTERMEDIATE | W9-C |
| [results/week9/implementation_verification/retrieval/fit/smoke/W9A_REPORT.md](../repository/results/week9/implementation_verification/retrieval/fit/smoke/W9A_REPORT.md) | 03_RETRIEVAL | INTERMEDIATE | W9-A |
| [results/week9/ke_surface/fit/W9B_REPORT.md](../repository/results/week9/ke_surface/fit/W9B_REPORT.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | W9-B |
| [results/week9/patch_verification/w9c_readiness/README.md](../repository/results/week9/patch_verification/w9c_readiness/README.md) | 01_PROJECT_EVOLUTION | INTERMEDIATE | W9-C readiness audit |
| [results/week9/patch_verification/w9d_readiness/README.md](../repository/results/week9/patch_verification/w9d_readiness/README.md) | 01_PROJECT_EVOLUTION | INTERMEDIATE | W9-D readiness |
| [results/week9/retrieval/fit/W9A_REPORT.md](../repository/results/week9/retrieval/fit/W9A_REPORT.md) | 03_RETRIEVAL | EXPLORATORY | W9-A |
| [results/week9/retrieval/fit/freeze_audit/W9A_FREEZE_AUDIT.md](../repository/results/week9/retrieval/fit/freeze_audit/W9A_FREEZE_AUDIT.md) | 03_RETRIEVAL | AUDIT | W9-A FIT freeze audit |
| [results/week9/retrieval/fit/smoke/W9A_REPORT.md](../repository/results/week9/retrieval/fit/smoke/W9A_REPORT.md) | 03_RETRIEVAL | INTERMEDIATE | W9-A |
| [results/week9/w9e3_senttopk/v1/fit/REPORT.md](../repository/results/week9/w9e3_senttopk/v1/fit/REPORT.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | E3-SentTopK FIT diagnostic |
| [results/week9/w9e3_senttopk/v1/smoke/REPORT.md](../repository/results/week9/w9e3_senttopk/v1/smoke/REPORT.md) | 01_PROJECT_EVOLUTION | INTERMEDIATE | Project documentation |
| [results/week9/w9f_utilization/v1/fit/REPORT.md](../repository/results/week9/w9f_utilization/v1/fit/REPORT.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | W9-F FIT utilization diagnostic |
| [results/week9/w9f_utilization/v1/smoke/REPORT.md](../repository/results/week9/w9f_utilization/v1/smoke/REPORT.md) | 01_PROJECT_EVOLUTION | INTERMEDIATE | Project documentation |
| [results/week9/w9g_action_verification/v1/audit_pre_final/REPORT.md](../repository/results/week9/w9g_action_verification/v1/audit_pre_final/REPORT.md) | 01_PROJECT_EVOLUTION | AUDIT | W9G_PRE_FINAL_TRAINING_AUDIT |
| [results/week9/w9g_action_verification/v1/preflight/REPORT.md](../repository/results/week9/w9g_action_verification/v1/preflight/REPORT.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | W9-G-PRE — Saved-output action-space preflight |
| [results/week9/w9h_final/v1/audit_report.md](../repository/results/week9/w9h_final/v1/audit_report.md) | 01_PROJECT_EVOLUTION | AUDIT | W9-H H0 audit |
| [results/week9/w9h_final/v2/W9H_H05_READINESS_AUDIT.md](../repository/results/week9/w9h_final/v2/W9H_H05_READINESS_AUDIT.md) | 01_PROJECT_EVOLUTION | AUDIT | W9-H H0.5 readiness/provenance audit |
| [results/week9/w9h_final/v2/audit_report.md](../repository/results/week9/w9h_final/v2/audit_report.md) | 01_PROJECT_EVOLUTION | AUDIT | W9-H H0.5 readiness/provenance audit |
| [results/week9/w9h_final/v2/report/FINAL_W9_REPORT.md](../repository/results/week9/w9h_final/v2/report/FINAL_W9_REPORT.md) | 01_PROJECT_EVOLUTION | EXPLORATORY | Final Week 9 report |
| [results/weekly_reports/week_00/WeeklyPartWiseAnalysis.md](../repository/results/weekly_reports/week_00/WeeklyPartWiseAnalysis.md) | 01_PROJECT_EVOLUTION | FROZEN | Week 0 — Part-Wise Analysis |
| [results/weekly_reports/week_00/WeeklySummaryAnalysis.md](../repository/results/weekly_reports/week_00/WeeklySummaryAnalysis.md) | 01_PROJECT_EVOLUTION | FROZEN | Week 0 — Summary Analysis |
| [results/weekly_reports/week_01/WeeklyPartWiseAnalysis.md](../repository/results/weekly_reports/week_01/WeeklyPartWiseAnalysis.md) | 02_BASELINES_SARA_RECOMP | FROZEN | Week 1 — Part-Wise Analysis |
| [results/weekly_reports/week_01/WeeklySummaryAnalysis.md](../repository/results/weekly_reports/week_01/WeeklySummaryAnalysis.md) | 02_BASELINES_SARA_RECOMP | FROZEN | Week 1 — Summary Analysis |
| [results/weekly_reports/week_02/WeeklyPartWiseAnalysis.md](../repository/results/weekly_reports/week_02/WeeklyPartWiseAnalysis.md) | 01_PROJECT_EVOLUTION | FROZEN | Week 2 — Part-Wise Analysis |
| [results/weekly_reports/week_02/WeeklySummaryAnalysis.md](../repository/results/weekly_reports/week_02/WeeklySummaryAnalysis.md) | 01_PROJECT_EVOLUTION | FROZEN | Week 2 — Summary Analysis |
| [results/weekly_reports/week_03/WeeklyPartWiseAnalysis.md](../repository/results/weekly_reports/week_03/WeeklyPartWiseAnalysis.md) | 01_PROJECT_EVOLUTION | FROZEN | Week 3 — Part-Wise Analysis |
| [results/weekly_reports/week_03/WeeklySummaryAnalysis.md](../repository/results/weekly_reports/week_03/WeeklySummaryAnalysis.md) | 01_PROJECT_EVOLUTION | FROZEN | Week 3 — Summary Analysis |
| [results/weekly_reports/week_04/WeeklyPartWiseAnalysis.md](../repository/results/weekly_reports/week_04/WeeklyPartWiseAnalysis.md) | 01_PROJECT_EVOLUTION | FROZEN | Week 4 — Part-Wise Analysis |
| [results/weekly_reports/week_04/WeeklySummaryAnalysis.md](../repository/results/weekly_reports/week_04/WeeklySummaryAnalysis.md) | 01_PROJECT_EVOLUTION | FROZEN | Week 4 — Summary Analysis |
| [results/weekly_reports/week_05/WeeklyPartWiseAnalysis.md](../repository/results/weekly_reports/week_05/WeeklyPartWiseAnalysis.md) | 01_PROJECT_EVOLUTION | FROZEN | Week 5 — Part-Wise Analysis |
| [results/weekly_reports/week_05/WeeklySummaryAnalysis.md](../repository/results/weekly_reports/week_05/WeeklySummaryAnalysis.md) | 01_PROJECT_EVOLUTION | FROZEN | Week 5 — Summary Analysis |
| [results/weekly_reports/week_06/WeeklyPartWiseAnalysis.md](../repository/results/weekly_reports/week_06/WeeklyPartWiseAnalysis.md) | 01_PROJECT_EVOLUTION | FROZEN | Week 6 — Part-Wise Analysis |
| [results/weekly_reports/week_06/WeeklySummaryAnalysis.md](../repository/results/weekly_reports/week_06/WeeklySummaryAnalysis.md) | 01_PROJECT_EVOLUTION | FROZEN | Week 6 — Summary Analysis |
| [results/weekly_reports/week_07/WeeklyPartWiseAnalysis.md](../repository/results/weekly_reports/week_07/WeeklyPartWiseAnalysis.md) | 01_PROJECT_EVOLUTION | FROZEN | Week 7 — Part-Wise Analysis |
| [results/weekly_reports/week_07/WeeklySummaryAnalysis.md](../repository/results/weekly_reports/week_07/WeeklySummaryAnalysis.md) | 01_PROJECT_EVOLUTION | FROZEN | Week 7 — Summary Analysis |
| [results/weekly_reports/week_08/WeeklyPartWiseAnalysis.md](../repository/results/weekly_reports/week_08/WeeklyPartWiseAnalysis.md) | 01_PROJECT_EVOLUTION | FROZEN | Week 8 — Part-Wise Analysis |
| [results/weekly_reports/week_08/WeeklySummaryAnalysis.md](../repository/results/weekly_reports/week_08/WeeklySummaryAnalysis.md) | 01_PROJECT_EVOLUTION | FROZEN | Week 8 — Summary Analysis |
| [results/weekly_reports/week_09/WeeklyPartWiseAnalysis.md](../repository/results/weekly_reports/week_09/WeeklyPartWiseAnalysis.md) | 01_PROJECT_EVOLUTION | FROZEN | Week 9 — Part-Wise Analysis |
| [results/weekly_reports/week_09/WeeklySummaryAnalysis.md](../repository/results/weekly_reports/week_09/WeeklySummaryAnalysis.md) | 01_PROJECT_EVOLUTION | FROZEN | Week 9 — Summary Analysis |
| [results/weekly_reports/week_10/WeeklyPartWiseAnalysis.md](../repository/results/weekly_reports/week_10/WeeklyPartWiseAnalysis.md) | 01_PROJECT_EVOLUTION | FROZEN | Week 10 — Part-Wise Analysis |
| [results/weekly_reports/week_10/WeeklySummaryAnalysis.md](../repository/results/weekly_reports/week_10/WeeklySummaryAnalysis.md) | 01_PROJECT_EVOLUTION | FROZEN | Week 10 — Summary Analysis |
| [results/weekly_reports/week_11/WeeklyPartWiseAnalysis.md](../repository/results/weekly_reports/week_11/WeeklyPartWiseAnalysis.md) | 01_PROJECT_EVOLUTION | FROZEN | Week 11 — Part-Wise Analysis |
| [results/weekly_reports/week_11/WeeklySummaryAnalysis.md](../repository/results/weekly_reports/week_11/WeeklySummaryAnalysis.md) | 01_PROJECT_EVOLUTION | FROZEN | Week 11 — Summary Analysis |
| [results/weekly_reports/week_12/WeeklyPartWiseAnalysis.md](../repository/results/weekly_reports/week_12/WeeklyPartWiseAnalysis.md) | 01_PROJECT_EVOLUTION | FROZEN | Week 12 — Part-Wise Analysis |
| [results/weekly_reports/week_12/WeeklySummaryAnalysis.md](../repository/results/weekly_reports/week_12/WeeklySummaryAnalysis.md) | 01_PROJECT_EVOLUTION | FROZEN | Week 12 — Summary Analysis |
| [results/weekly_reports/week_13/WeeklyPartWiseAnalysis.md](../repository/results/weekly_reports/week_13/WeeklyPartWiseAnalysis.md) | 01_PROJECT_EVOLUTION | FROZEN | Week 13 — Part-Wise Analysis |
| [results/weekly_reports/week_13/WeeklySummaryAnalysis.md](../repository/results/weekly_reports/week_13/WeeklySummaryAnalysis.md) | 01_PROJECT_EVOLUTION | FROZEN | Week 13 — Summary Analysis |
